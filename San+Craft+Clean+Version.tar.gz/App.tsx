import React, { useEffect, useMemo, useRef, useState } from "react";
import "./index.css";

// ===== MODO LOCAL — SEM BANCO, SEM REDE =====
// Este jogo é intencionalmente local e em memória: não há banco, conta
// persistente, sincronização ou envio. O progresso vive nesta sessão;
// guardar é baixar um arquivo JSON ou copiar o Pacote do San.
// Contas (Nome + Senha) também vivem só nesta sessão, em useState —
// nenhum dado é gravado no navegador (sem localStorage / IndexedDB).
// Nenhum script externo é carregado.
const DATABASE_ENABLED = false;
// Config futura do banco. Hoje DATABASE_ENABLED = false, então ela não é usada.
const FIREBASE_CONFIG = null as unknown as Record<string, string> | null;
// ADM: o NOME exato (case-sensitive) é "san123". Quem registra/entrar com
// esse nome vira ADM e abre o Laboratório do Criador. A senha é a que a
// pessoa escolhe ao registrar — não há senha fixa no código.
const NOME_ADM = "san123";
// ==========================================
// Modo infinito: não há meta fixa de descobertas.
// Temperatura da IA: 0.6 — mais criativa ("alucinada pode ser 0.6"),
// ainda plausível: nunca inventa um personagem/coisa existente que não combina.
const TEMPERATURA_IA = 0.6;
const TEMPERATURA_ALUCINATORIA = 0.9;
// ===== FILTRO +18 — BLOQUEIO RÍGIDO, EM QUALQUER MODO =====
// Termos e fragmentos em PT-BR / EN / ES / FR / JA (romanizado). A checagem
// usa a forma sem acento e limites de palavra quando o termo é curto, para
// não bloquear palavras inocentes. Nenhum nome gerado, digitado ou colado
// passa por este filtro sem ser rejeitado e substituído por alternativa segura.
const TERMOS_PROIBIDOS_18 = [
  "porn", "porno", "xxx", "sexo", "sexual", "transa", "tesao", "tesuda",
  "punheta", "boquete", "chupar", "siririca", "gozar", "gozo", "orgasmo",
  "penis", "pene", "vagina", "vulva", "clitoris", "bunda", "cuzao", "caralho",
  "foder", "foda", "fodido", "krl", "p0rn", "hentai", "ecchi", "ero", "nude",
  "nudes", "onlyfans", "camgirl", "escort", "prostituta", "puta", "puto",
  "bitch", "slut", "whore", "dick", "cock", "pussy", "tits", "boobs",
  "sex", "sexy", "fuck", "fucking", "blowjob", "handjob", "masturbat",
  "orgasm", "pornografia", "pornographic", "erotico", "erotica",
  "coito", "cojer", "coger", "chingar", "verga", "polla", "tetas", "culo",
  "mierda", "puta", "cabron", "baiser", "bite", "queue", "sexe", "cul",
];
function conteudoProibido18(nome: string): boolean {
  const texto = ` ${semAcento(nome).replace(/[^a-z0-9]+/g, " ")} `;
  return TERMOS_PROIBIDOS_18.some((t) => texto.includes(` ${t} `) || texto.includes(` ${t}`) && t.length >= 5 || (t.length >= 6 && texto.includes(t)));
}
// ===== MODO ALUCINATÓRIO — PALAVRAS / SÍMBOLOS / NÚMEROS DO MUNDO =====
const SIMBOLOS_MUNDO: Array<{ simbolo: string; palavra: string; emoji: string }> = [
  { simbolo: "龍", palavra: "Dragão", emoji: "🐉" }, { simbolo: "桜", palavra: "Sakura", emoji: "🌸" },
  { simbolo: "Ω", palavra: "Ômega", emoji: "🌀" }, { simbolo: "∞", palavra: "Infinito", emoji: "♾️" },
  { simbolo: "Æ", palavra: "Aurora", emoji: "🌌" }, { simbolo: "Ø", palavra: "Norte", emoji: "❄️" },
  { simbolo: "Ñ", palavra: "Noite", emoji: "🌙" }, { simbolo: "Ç", palavra: "Céu", emoji: "☁️" },
  { simbolo: "雪", palavra: "Neve", emoji: "❄️" }, { simbolo: "火", palavra: "Fogo", emoji: "🔥" },
  { simbolo: "水", palavra: "Água", emoji: "💧" }, { simbolo: "風", palavra: "Vento", emoji: "💨" },
  { simbolo: "土", palavra: "Terra", emoji: "🌍" }, { simbolo: "★", palavra: "Estrela", emoji: "⭐" },
  { simbolo: "☯", palavra: "Equilíbrio", emoji: "☯️" }, { simbolo: "☀", palavra: "Sol", emoji: "☀️" },
];
const NUMEROS_MUNDO = ["7", "42", "007", "51", "100", "3", "9", "2026"];
const ADJETIVOS_ALUCINATORIOS = ["Místico", "Cósmico", "Neon", "Voador", "Dourado", "Prateado", "Lunar", "Solar", "Encantado", "Gigante", "Minúsculo", "Brilhante"];
function criarAlucinatorio(a: Elemento, b: Elemento, jaTem: (nome: string) => boolean): ResultadoIA | null {
  const essA = essenciaDe(a); const essB = essenciaDe(b);
  const metaA = metadadosDe(a); const metaB = metadadosDe(b);
  const candidatos: Array<{ nome: string; emoji: string }> = [];
  const embaralhar = <T,>(lista: T[]): T[] => [...lista].sort(() => Math.random() - 0.5);
  embaralhar(SIMBOLOS_MUNDO).slice(0, 4).forEach((s) => {
    candidatos.push({ nome: `${s.simbolo} ${essB}`, emoji: s.emoji });
    candidatos.push({ nome: `${s.simbolo} ${essA}`, emoji: s.emoji });
    candidatos.push({ nome: `${s.palavra} ${essB}`, emoji: s.emoji });
  });
  embaralhar(NUMEROS_MUNDO).slice(0, 3).forEach((n) => {
    candidatos.push({ nome: `${n} ${essB}`, emoji: b.emoji || "✨" });
    candidatos.push({ nome: `${essA} ${n}`, emoji: a.emoji || "✨" });
    candidatos.push({ nome: `Área ${n}`, emoji: "🗺️" });
  });
  embaralhar(ADJETIVOS_ALUCINATORIOS).slice(0, 5).forEach((adj) => {
    candidatos.push({ nome: `${adj} ${essB}`, emoji: b.emoji || "✨" });
    candidatos.push({ nome: `${essA} ${adj}`, emoji: a.emoji || "✨" });
  });
  candidatos.push({ nome: `Sakura ${essB}`, emoji: "🌸" }, { nome: `Taco ${essB}`, emoji: "🌮" }, { nome: `${essA} Voador`, emoji: "🪁" });
  for (const cand of embaralhar(candidatos)) {
    const nome = limitarNomeIA(cand.nome);
    if (!nome || nome === a.nome || nome === b.nome) continue;
    if (jaTem(nome)) continue;
    if (conteudoProibido18(nome) || nomeProibido(nome, a, b)) continue;
    return { nome, emoji: cand.emoji, categoria: "Vida Real", universo: "Modo Alucinatório 🌌", tags: [...new Set([...metaA.tags, ...metaB.tags])], original: true, motivo: `Modo Alucinatório 🌌 (temperatura 0.9): ${a.nome} + ${b.nome} vira ${nome} — uma invenção inesperada que mistura línguas, símbolos e números do mundo. Não é um elemento oficial; é uma ideia do jogo, sempre sem conteúdo +18.` };
  }
  return null;
}
// IA simulada refinada: nunca devolve "Mistura de...". Sempre 1 emoji + 1 nome.
const FRASES_PROIBIDAS_IA = ["mistura de", "combinação de", "combinação de", "mistura de elemento"];
// ===== ANTI-RECURSÃO: BANIDO "X de X" =====
// Nunca gerar "Água de Água", "Fogo de Fogo", "Água de Água de Água",
// "Pata de Pata" ou qualquer nome que repita um insumo. Se o fallback
// produzir isso, ele é descartado e outro nome é escolhido.
function palavraBase(nome: string): string {
  // "Banho de Cachorro" / "Banho-de-Cachorro" -> "Banho". Nunca reutilizar o nome composto inteiro.
  const semDe = normalizar(nome).replace(/-/g, " ").split(" de ")[0].trim();
  const primeira = semDe.split(/[^a-z]+/).filter(Boolean)[0] || semDe;
  return primeira;
}
function palavrasDe(nome: string): string[] {
  return normalizar(nome).split(/[^a-z]+/).filter(Boolean);
}
function nomeProibido(nome: string, a: Elemento, b: Elemento): boolean {
  // Nomes novos usam hífen ("Praia-do-San"); as checagens abaixo usam espaço.
  const n = normalizar(nome).replace(/-/g, " ");
  if (!n) return true;
  if (conteudoProibido18(nome)) return true;
  if (FRASES_PROIBIDAS_IA.some((f) => n.includes(f))) return true;
  // Concordância: "Novo Terra", "Novo Água", "Novo Praia", "Terra Novo"...
  // são proibidos — o correto é Nova Terra / Nova Água / Nova Praia.
  if (temErroDeConcordancia(nome)) return true;
  if (/\bnovo (terra|agua|praia|lagoa|flor|chuva|nuvem|lua|pedra)\b/.test(n)) return true;
  // ===== ANTI-"do San Oceano": preposição no começo é sempre ordem invertida =====
  // Em português, o correto é "Praia do San" / "Oceano do San" / "Brisa do Mar"
  // (Substantivo + do/da + Substantivo), NUNCA "do San Oceano" / "de Água Flor".
  // "Oceano do San" é permitido (preposição no meio); "do San Oceano" não é.
  if (/^(do|de|da|dos|das|no|na|nos|nas|em|ao|aos)\s/.test(n)) return true;
  if (n.startsWith("do san") || n.startsWith("de san") || n.startsWith("da san")) return true;
  if (n.includes("do san oceano") || n.includes("de san oceano") || n.includes("da san oceano")) return true;
  // Dois substantivos colados sem conector nem adjetivo: "San Oceano" / "Oceano San".
  // Preferir "Praia do San" ou "San Surfista" — nunca dois nomes grudados.
  if (n === "san oceano" || n === "oceano san") return true;
  if (
    (n === `${normalizar(a.nome)} ${normalizar(b.nome)}` || n === `${normalizar(b.nome)} ${normalizar(a.nome)}`) &&
    n.split(" ").length === 2 &&
    normalizar(a.nome).split(" ").length === 1 &&
    normalizar(b.nome).split(" ").length === 1
  ) {
    // Só rejeita o caso genérico quando um dos lados é "San" (nome próprio):
    // "San Oceano", "San Pedra", "San Nuvem"... soam como dois nomes grudados.
    if (normalizar(a.nome) === "san" || normalizar(b.nome) === "san") return true;
  }
  // Mesma palavra repetida com "de": "água de água", "pata de pata".
  if (/\b([a-z]+) de \1\b/.test(n)) return true;
  // "de X de X": "água de água de água", "de água de água".
  if (/ de ([a-z]+) de \1\b/.test(n)) return true;
  // Nome que é só "A de B" com A == B, ou que já contém um insumo duas vezes.
  for (const insumo of [a, b]) {
    const base = palavraBase(insumo.nome);
    if (base && n.split(base).length - 1 >= 2) return true;
    const completo = normalizar(insumo.nome);
    if (completo.includes(" ") && n.split(completo).length - 1 >= 2) return true;
    if (n === `${normalizar(a.nome)} de ${normalizar(b.nome)}`) return true;
  }
  // Qualquer palavra repetida dentro do nome gerado (ex.: "Banho de Banho").
  const palavras = palavrasDe(nome);
  if (new Set(palavras).size !== palavras.length) return true;
  // Nome gerado idêntico a um insumo composto já existente.
  if (n === normalizar(a.nome) || n === normalizar(b.nome)) return true;
  return false;
}
// Versão intensificada para qualquer A+A que não esteja na tabela curada:
// "Super / Mega / Grande [A]" — nunca "A de A". Determinístico pelo hash.
function versaoIntensificada(a: Elemento): ResultadoIA {
  const base = palavraBase(a.nome);
  // Nunca deixar o rótulo começar com preposição ("do San Oceano" herdado
  // de um save antigo): "Super do San..." seria o mesmo bug invertido.
  const rotuloBruto = a.nome.includes(" de ") ? a.nome.split(" de ")[0].trim() : a.nome;
  const rotulo = rotuloBruto.replace(/^(do|de|da|dos|das)\s+/i, "").trim() || "Invenção";
  const prefixos = ["Super", "Mega", "Grande"];
  const prefixo = prefixos[hashTexto(chave(a.nome, a.nome)) % prefixos.length];
  const nome = limitarNomeIA(`${prefixo} ${rotulo}`);
  return {
    nome, emoji: a.emoji || "✨", categoria: (a.categoria as CategoriaIA) || "Vida Real",
    universo: "Criação Original", tags: [...new Set([...(a.tags || []), ...tagsDeNome(a.nome)])], original: true,
    motivo: `Criação Original: ${a.nome} + ${a.nome} não é "${a.nome} de ${a.nome}". É tanto ${base} junto que vira ${nome} — uma versão maior e mais forte, não uma repetição.`,
  };
}
type CategoriaIA = "Vida Real" | "Anime" | "Série" | "Filme" | "Mitologia";
type ResultadoIA = { nome: string; emoji: string; categoria: CategoriaIA; motivo: string; universo?: string; tags?: string[]; original?: boolean; dicionario?: string; significado?: string; pais?: string; idioma?: string };

type Elemento = {
  nome: string;
  emoji: string;
  dica: string;
  receita?: string;
  categoria?: CategoriaIA | string;
  motivo?: string;
  universo?: string;
  tags?: string[];
  pais?: string;
  idioma?: string;
};

const INICIAIS: Elemento[] = [
  { nome: "Água", emoji: "💧", dica: "Base: cai, molha e refresca.", universo: "Neutro", tags: ["agua"] },
  { nome: "Fogo", emoji: "🔥", dica: "Base: esquenta e ilumina.", universo: "Neutro", tags: ["fogo"] },
  { nome: "Vento", emoji: "💨", dica: "Base: empurra as nuvens.", universo: "Neutro", tags: ["vento"] },
  { nome: "Terra", emoji: "🌍", dica: "Base: onde tudo cresce.", universo: "Neutro", tags: ["terra"] },
  { nome: "San", emoji: "🧪", dica: "Base: o criador curioso.", universo: "San Craft", tags: ["criador"] },
  { nome: "Meg", emoji: "🐶", dica: "Base: a cachorrinha do San.", universo: "San Craft", tags: ["cachorro", "animal"] },
];

const RECEITAS_BASE: Record<string, Elemento> = {
  "Água|Fogo": { nome: "Vapor", emoji: "♨️", dica: "Sobe quando Água encontra Fogo." },
  "Água|Terra": { nome: "Lama", emoji: "🟤", dica: "Água + Terra vira uma meleca boa." },
  "Fogo|Terra": { nome: "Lava", emoji: "🌋", dica: "Fogo + Terra derrete tudo." },
  "Vento|Água": { nome: "Chuva", emoji: "🌧️", dica: "Vento leva a Água para o céu." },
  "Fogo|Vento": { nome: "Faísca", emoji: "✨", dica: "Vento espalha o Fogo." },
  "Terra|Vento": { nome: "Poeira", emoji: "🌪️", dica: "Terra leve voando com o Vento." },
  "San|Água": { nome: "Poção", emoji: "🧪", dica: "San mistura Água e testa uma poção." },
  "Fogo|San": { nome: "Ideia", emoji: "💡", dica: "San perto do Fogo tem uma ideia." },
  "Meg|Água": { nome: "Banho", emoji: "🛁", dica: "Meg + Água: hora do banho." },
  "Meg|Terra": { nome: "Pata", emoji: "🐾", dica: "Meg deixa uma patinha na Terra." },
  "Meg|San": { nome: "Amizade", emoji: "💛", dica: "San + Meg: amizade verdadeira." },
  "Terra|Vapor": { nome: "Nuvem", emoji: "☁️", dica: "Vapor encontra Terra e vira Nuvem." },
  "Lava|Água": { nome: "Pedra", emoji: "🪨", dica: "Lava esfria na Água e vira Pedra." },
  "Chuva|Terra": { nome: "Flor", emoji: "🌸", dica: "Chuva na Terra faz Flor nascer." },
  "Faísca|Vento": { nome: "Tempestade", emoji: "⛈️", dica: "Faísca + Vento vira Tempestade." },
  "Fogo|Nuvem": { nome: "Arco-íris", emoji: "🌈", dica: "Sol na Nuvem pinta o céu." },
  "Fogo|Pedra": { nome: "Cristal", emoji: "💎", dica: "Pedra no Fogo vira Cristal." },
  "Arco-íris|San": { nome: "Magia", emoji: "🪄", dica: "San toca o Arco-íris e faz Magia." },
  "Cristal|Magia": { nome: "Tesouro", emoji: "👑", dica: "Cristal + Magia guardam um Tesouro." },
};

function chave(a: string, b: string) {
  return [a, b].sort((x, y) => x.localeCompare(y, "pt-BR")).join("|");
}
function normalizar(nome: string) {
  return nome.trim().toLowerCase();
}

// ===== ORTOGRAFIA BRASILEIRA — CONCORDÂNCIA DE GÊNERO =====
// Terra é FEMININO: o certo é "Nova Terra" / "Terra Nova", nunca "Novo Terra".
// O mesmo vale para Água, Praia, Lagoa, Flor... (femininas) e para
// Fogo, Vento, Oceano, Lago... (masculinos). A IA só monta
// "[Adjetivo] + [Substantivo]" ou "[Substantivo] + [Adjetivo]" depois de
// flexionar o adjetivo para o gênero do substantivo.
type Genero = "f" | "m";
function semAcento(palavra: string): string {
  return palavra.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
// Gênero do dicionário PT-BR (substantivo -> gênero). Chaves sem acento.
const GENERO_SUBSTANTIVO: Record<string, Genero> = {
  terra: "f", agua: "f", lagoa: "f", praia: "f", flor: "f", planta: "f", chuva: "f", neve: "f",
  nuvem: "f", lua: "f", estrela: "f", montanha: "f", serra: "f", pedra: "f", rocha: "f",
  ilha: "f", baia: "f", enseada: "f", fonte: "f", nascente: "f", duna: "f", gruta: "f",
  caverna: "f", cachoeira: "f", mare: "f", onda: "f", espuma: "f", concha: "f", perola: "f",
  vela: "f", tocha: "f", lamparina: "f", panela: "f", churrasqueira: "f", casa: "f",
  cabana: "f", ponte: "f", estrada: "f", trilha: "f", vila: "f", cidade: "f", praca: "f",
  feira: "f", escola: "f", biblioteca: "f", historia: "f", poesia: "f", cancao: "f",
  danca: "f", pipa: "f", canoa: "f", rede: "f", corda: "f", bussola: "f", ancora: "f",
  moeda: "f", coroa: "f", joia: "f", coleira: "f", pata: "f", amizade: "f", alegria: "f",
  tristeza: "f", esperanca: "f", liberdade: "f", paz: "f", festa: "f", vida: "f", morte: "f",
  invencao: "f", ideia: "f", magia: "f", aventura: "f", descoberta: "f", lenda: "f",
  criatividade: "f", imaginacao: "f", tempestade: "f", brisa: "f", neblina: "f", nevoa: "f",
  geada: "f", chama: "f", brasa: "f", fumaça: "f", fumaca: "f", cinza: "f", folha: "f",
  raiz: "f", semente: "f", fruta: "f", rosa: "f", margarida: "f", lotus: "f", alga: "f",
  samambaia: "f", arara: "f", coruja: "f", borboleta: "f", abelha: "f", formiga: "f",
  baleia: "f", tartaruga: "f", cobra: "f", onca: "f", capivara: "f",
  fogo: "m", vento: "m", oceano: "m", lago: "m", mar: "m", rio: "m", sol: "m", ceu: "m",
  vulcao: "m", deserto: "m", jardim: "m", campo: "m", cristal: "m", diamante: "m", rubi: "m",
  ouro: "m", tesouro: "m", castelo: "m", porto: "m", farol: "m", barco: "m", navio: "m",
  trem: "m", aviao: "m", helicoptero: "m", carro: "m", cachorro: "m", gato: "m", cavalo: "m",
  sapo: "m", jacare: "m", peixe: "m", golfinho: "m", polvo: "m", caranguejo: "m", dragao: "m",
  monstro: "m", heroi: "m", vilao: "m", mago: "m", feitico: "m", encanto: "m", segredo: "m",
  misterio: "m", mito: "m", livro: "m", mapa: "m", espelho: "m", prisma: "m", laser: "m",
  martelo: "m", machado: "m", sino: "m", tambor: "m", violao: "m", apito: "m", cesto: "m",
  bolo: "m", pao: "m", suco: "m", caldo: "m", cafe: "m", sorvete: "m", brigadeiro: "m",
  churrasco: "m", pato: "m", vapor: "m", gelo: "m", granizo: "m", raio: "m",
  trovao: "m", relampago: "m", furacao: "m", tornado: "m", tufao: "m", vendaval: "m",
  horizonte: "m", arco: "m", amanhecer: "m", entardecer: "m", verao: "m", outono: "m",
  inverno: "m", primavera: "f",
};
// Adjetivos flexionáveis: forma masculina -> forma feminina.
// Invariáveis NÃO entram aqui e nunca mudam: Grande, Brilhante, Quente,
// Forte, Doce, Leve, Verde, Azul, Feliz, Livre, Elétrico, Lunar, etc.
const ADJETIVO_FLEXIVEL: Record<string, string> = {
  novo: "nova", velho: "velha", pequeno: "pequena", bonito: "bonita", lindo: "linda",
  alto: "alta", baixo: "baixa", frio: "fria", seco: "seca", molhado: "molhada",
  pesado: "pesada", duro: "dura", macio: "macia", branco: "branca", preto: "preta",
  vermelho: "vermelha", dourado: "dourada", prateado: "prateada", magico: "magica",
  encantado: "encantada", misterioso: "misteriosa", primeiro: "primeira", ultimo: "ultima",
  bom: "boa", criativo: "criativa", draconico: "draconica", monstruoso: "monstruosa",
  florido: "florida", rochoso: "rochosa", gelado: "gelada", mistico: "mistica",
  precioso: "preciosa", sombrio: "sombria", voador: "voadora", fofo: "fofa",
  capturador: "capturadora", redondo: "redonda", esferico: "esferica",
  desejado: "desejada", afiado: "afiada", elastico: "elastica", energetico: "energetica",
  frutado: "frutada", ensolarado: "ensolarada", estrelado: "estrelada",
  afetuoso: "afetuosa", psiquico: "psiquica", fantasmagorico: "fantasmagorica",
  venenoso: "venenosa", lutador: "lutadora", metalico: "metalica", arenoso: "arenosa",
  observador: "observadora", curativo: "curativa", preciso: "precisa",
  robotico: "robotica", heroico: "heroica", prehistorico: "prehistorica",
  caseiro: "caseira", labirintico: "labirintica", alado: "alada", astuto: "astuta",
  brasileiro: "brasileira", turistico: "turistica", praiano: "praiana", urbano: "urbana",
  festivo: "festiva", capitalino: "capitalina", minusculo: "minuscula",
  gostoso: "gostosa", quentinho: "quentinha",
};
const ADJETIVO_FLEXIVEL_REVERSO: Record<string, string> = Object.fromEntries(
  Object.entries(ADJETIVO_FLEXIVEL).map(([m, f]) => [f, m]),
);
function generoDe(palavra: string): Genero | undefined {
  return GENERO_SUBSTANTIVO[semAcento(palavra)];
}
function flexionarAdjetivo(adjetivo: string, genero: Genero): string {
  const base = semAcento(adjetivo);
  // Masculino usa a chave (ex.: novo), feminino usa o valor (ex.: nova).
  const correta = genero === "f" ? (ADJETIVO_FLEXIVEL[base] || base) : (ADJETIVO_FLEXIVEL_REVERSO[base] || base);
  if (correta === base) return adjetivo;
  return /^[A-ZÀ-Ú]/.test(adjetivo) ? correta.charAt(0).toUpperCase() + correta.slice(1) : correta;
}
function ehAdjetivoFlexivel(palavra: string): boolean {
  const base = semAcento(palavra);
  return base in ADJETIVO_FLEXIVEL || base in ADJETIVO_FLEXIVEL_REVERSO;
}
// Corrige "Novo Terra" -> "Nova Terra", "Terra Novo" -> "Terra Nova",
// "Novo Água" -> "Nova Água", "Oceano Nova" -> "Oceano Novo".
// Nomes já corretos passam intactos. Invariáveis (Grande, Brilhante...)
// nunca são alterados.
function corrigirConcordancia(nome: string): string {
  const partes = nome.split(" ");
  for (let i = 0; i < partes.length; i++) {
    if (!ehAdjetivoFlexivel(partes[i])) continue;
    const vizinhoAntes = i > 0 ? partes[i - 1] : null;
    const vizinhoDepois = i < partes.length - 1 ? partes[i + 1] : null;
    const generoAntes = vizinhoAntes ? generoDe(vizinhoAntes) : undefined;
    const generoDepois = vizinhoDepois ? generoDe(vizinhoDepois) : undefined;
    // "Terra Nova": o substantivo vem antes; "Nova Terra": vem depois.
    // Se os dois lados forem substantivos, o da direita manda (ordem
    // Adjetivo + Substantivo é a mais comum na IA).
    const genero = generoDepois || generoAntes;
    if (genero) partes[i] = flexionarAdjetivo(partes[i], genero);
  }
  return partes.join(" ");
}
function temErroDeConcordancia(nome: string): boolean {
  return semAcento(corrigirConcordancia(nome)) !== semAcento(nome);
}

// ===== IA GENERATIVA REFINADA =====
// Regra de ouro: nome com no máximo 50 caracteres, 1 emoji, e algo que
// existe na vida real ou na cultura (anime, série, filme, jogo, mitologia).
// ===== FORMATO NOVO — MÁX. 50 CARACTERES, SÍMBOLOS NO COMEÇO + HÍFEN =====
// Regra: [Símbolos] - [Palavra1-Palavra2-Palavra3], no máximo 50 caracteres
// no total (símbolos + hífens + palavras). Símbolos/emoji só no começo,
// no máximo 3, nunca espalhados no meio ("Sakura Ø Guarda" é proibido).
// Depois dos símbolos vem hífen e as palavras ligadas por hífen, não por
// espaço. Números vão para o fim ("Æ-Orvalho-9-Infinito").
// Se o nome passar de 50, corta: primeiro descarta palavras do fim, depois
// encurta a última palavra — nunca devolve nome com mais de 50.
const MAX_NOME = 50;
const SIMBOLOS_DO_MUNDO = new Set(SIMBOLOS_MUNDO.map((s) => s.simbolo));
function formatarNome50(nome: string): string {
  const paraCorrecao = nome.trim().replace(/-/g, " ").replace(/\s+/g, " ").trim();
  if (!paraCorrecao) return "Invenção";
  const corrigido = corrigirConcordancia(paraCorrecao);
  const simbolos: string[] = [];
  const palavras: string[] = [];
  const numeros: string[] = [];
  const pedacos = corrigido.split(" ");
  for (const pedaco of pedacos) {
    if (!pedaco) continue;
    if (SIMBOLOS_DO_MUNDO.has(pedaco)) { simbolos.push(pedaco); continue; }
    const subpedacos = pedaco.split("-").filter(Boolean);
    for (const sub of subpedacos) {
      if (SIMBOLOS_DO_MUNDO.has(sub)) { simbolos.push(sub); continue; }
      let letras = "";
      let simbolo = "";
      for (const ch of Array.from(sub)) {
        if (/[A-Za-zÀ-ÿ0-9'’]/.test(ch)) letras += ch;
        else if (ch === "." || ch === "," || ch === ";" || ch === ":" || ch === "(" || ch === ")" || ch === '"') { /* descarta pontuação */ }
        else simbolo += ch;
      }
      if (simbolo) simbolos.push(simbolo);
      if (letras) {
        if (/^[0-9]+$/.test(letras)) numeros.push(letras);
        else palavras.push(letras);
      }
    }
  }
  const simbolosCortados = simbolos.slice(0, 3);
  const cauda = [...palavras];
  const nums = [...numeros];
  const montar = () => [...simbolosCortados, ...cauda, ...nums].join("-");
  let resultado = montar();
  while (resultado.length > MAX_NOME && (cauda.length + nums.length > 1)) {
    if (nums.length) nums.pop();
    else cauda.pop();
    resultado = montar();
  }
  if (resultado.length > MAX_NOME) {
    const prefixo = simbolosCortados.length ? `${simbolosCortados.join("-")}-` : "";
    const resto = resultado.slice(prefixo.length);
    const maxResto = Math.max(1, MAX_NOME - prefixo.length);
    resultado = prefixo + Array.from(resto).slice(0, maxResto).join("");
  }
  if (resultado.length > MAX_NOME) resultado = Array.from(resultado).slice(0, MAX_NOME).join("");
  resultado = resultado.replace(/-+$/, "").trim();
  return resultado || "Invenção";
}
function limitarNomeIA(nome: string): string {
  const formatado = formatarNome50(nome);
  // Contador / corte garantido: nunca devolve mais de 50 caracteres.
  if (formatado.length > MAX_NOME) return Array.from(formatado).slice(0, MAX_NOME).join("").replace(/-+$/, "");
  return formatado;
}
function hashTexto(texto: string): number {
  return texto.split("").reduce((s, c) => s + c.charCodeAt(0) * 7, 0);
}
// ===== UNIVERSOS + TAGS — A REGRA QUE FAZ SENTIDO =====
// Cada elemento tem universo + tags. A combinação NUNCA sorteia um pool
// aleatório: primeiro procura dentro do universo do Elemento A algo que
// combine com as tags do Elemento B; só depois tenta o universo de B e,
// por último, outros universos — sempre exigindo pelo menos 1 tag em comum.
// Tags sem acento, em minúsculas, para comparar sem erro.
type EntradaUniverso = { nome: string; emoji: string; tags: string[]; categoria: CategoriaIA };
type MetaElemento = { universo: string; tags: string[]; categoria: CategoriaIA };
// Atalho para os bancos grandes: [nome, emoji, tags]. Mantém cada
// entrada em 1 linha, sem repetir { nome, emoji, tags, categoria }.
type TuplaBanco = [string, string, string[]];
function banco(lista: TuplaBanco[], categoria: CategoriaIA): EntradaUniverso[] {
  return lista.map(([nome, emoji, tags]) => ({ nome, emoji, tags, categoria }));
}
// ===== POKÉMON — 1ª geração completa + populares depois =====
const POKEMON_LISTA: TuplaBanco[] = [
  ["Pikachu", "⚡", ["eletrico", "rato"]], ["Raichu", "⚡", ["eletrico", "rato"]],
  ["Charizard", "🔥", ["fogo", "dragao", "voador"]], ["Blastoise", "🌊", ["agua", "tartaruga"]],
  ["Venusaur", "🌸", ["planta", "veneno"]], ["Gengar", "👻", ["fantasma", "veneno"]],
  ["Dragonite", "🐉", ["dragao", "voador"]], ["Mewtwo", "🧠", ["psiquico"]], ["Mew", "✨", ["psiquico"]],
  ["Gyarados", "🐉", ["agua", "dragao", "monstro"]], ["Lapras", "🌊", ["agua", "gelo"]],
  ["Eevee", "🐶", ["normal", "cachorro"]], ["Snorlax", "😴", ["normal"]],
  ["Lugia", "🌊", ["psiquico", "voador", "agua"]], ["Pokébola", "🔴", ["captura", "bola"]],
  ["Bulbasaur", "🌱", ["planta", "veneno"]], ["Ivysaur", "🌱", ["planta", "veneno"]],
  ["Charmander", "🔥", ["fogo"]], ["Charmeleon", "🔥", ["fogo"]],
  ["Squirtle", "🐢", ["agua", "tartaruga"]], ["Wartortle", "🐢", ["agua", "tartaruga"]],
  ["Caterpie", "🐛", ["inseto"]], ["Metapod", "🐛", ["inseto"]], ["Butterfree", "🦋", ["inseto", "voador"]],
  ["Weedle", "🐛", ["inseto", "veneno"]], ["Kakuna", "🐛", ["inseto", "veneno"]], ["Beedrill", "🐝", ["inseto", "veneno"]],
  ["Pidgey", "🐦", ["normal", "voador", "passaro"]], ["Pidgeotto", "🐦", ["normal", "voador", "passaro"]],
  ["Pidgeot", "🐦", ["normal", "voador", "passaro"]], ["Rattata", "🐭", ["normal", "rato"]],
  ["Raticate", "🐭", ["normal", "rato"]], ["Spearow", "🐦", ["normal", "voador", "passaro"]],
  ["Fearow", "🐦", ["normal", "voador", "passaro"]], ["Ekans", "🐍", ["veneno"]], ["Arbok", "🐍", ["veneno"]],
  ["Sandshrew", "🦔", ["terra"]], ["Sandslash", "🦔", ["terra"]],
  ["Nidoran♀", "🐭", ["veneno"]], ["Nidorina", "🐭", ["veneno"]], ["Nidoqueen", "🐭", ["veneno", "terra"]],
  ["Nidoran♂", "🐭", ["veneno"]], ["Nidorino", "🐭", ["veneno"]], ["Nidoking", "🐭", ["veneno", "terra"]],
  ["Clefairy", "🧚", ["fada", "normal"]], ["Clefable", "🧚", ["fada", "normal"]],
  ["Vulpix", "🦊", ["fogo", "raposa"]], ["Ninetales", "🦊", ["fogo", "raposa"]],
  ["Jigglypuff", "🎤", ["normal", "fada"]], ["Wigglytuff", "🎤", ["normal", "fada"]],
  ["Zubat", "🦇", ["veneno", "voador"]], ["Golbat", "🦇", ["veneno", "voador"]],
  ["Oddish", "🌱", ["planta", "veneno"]], ["Gloom", "🌸", ["planta", "veneno"]], ["Vileplume", "🌸", ["planta", "veneno"]],
  ["Paras", "🍄", ["inseto", "planta"]], ["Parasect", "🍄", ["inseto", "planta"]],
  ["Venonat", "🐛", ["inseto", "veneno"]], ["Venomoth", "🦋", ["inseto", "veneno"]],
  ["Diglett", "⛏️", ["terra"]], ["Dugtrio", "⛏️", ["terra"]],
  ["Meowth", "🐱", ["normal", "gato"]], ["Persian", "🐱", ["normal", "gato"]],
  ["Psyduck", "🦆", ["agua", "passaro"]], ["Golduck", "🦆", ["agua"]],
  ["Poliwag", "🐸", ["agua"]], ["Poliwhirl", "🐸", ["agua"]], ["Poliwrath", "🐸", ["agua", "lutador"]],
  ["Abra", "🧠", ["psiquico"]], ["Kadabra", "🧠", ["psiquico"]], ["Alakazam", "🧠", ["psiquico"]],
  ["Machop", "💪", ["lutador"]], ["Machoke", "💪", ["lutador"]], ["Machamp", "💪", ["lutador"]],
  ["Bellsprout", "🌱", ["planta", "veneno"]], ["Weepinbell", "🌱", ["planta", "veneno"]], ["Victreebel", "🌱", ["planta", "veneno"]],
  ["Tentacool", "🦑", ["agua", "veneno"]], ["Tentacruel", "🦑", ["agua", "veneno"]],
  ["Geodude", "🪨", ["pedra", "terra"]], ["Graveler", "🪨", ["pedra", "terra"]], ["Golem", "🗿", ["pedra", "terra"]],
  ["Ponyta", "🐴", ["fogo", "cavalo"]], ["Rapidash", "🐴", ["fogo", "cavalo"]],
  ["Slowpoke", "🦛", ["agua", "psiquico"]], ["Slowbro", "🦛", ["agua", "psiquico"]],
  ["Magnemite", "🧲", ["eletrico", "metal"]], ["Magneton", "🧲", ["eletrico", "metal"]],
  ["Farfetch'd", "🦆", ["normal", "voador", "passaro"]], ["Doduo", "🐦", ["normal", "voador", "passaro"]],
  ["Dodrio", "🐦", ["normal", "voador", "passaro"]], ["Seel", "🦭", ["agua"]], ["Dewgong", "🦭", ["agua", "gelo"]],
  ["Grimer", "🟣", ["veneno"]], ["Muk", "🟣", ["veneno"]],
  ["Shellder", "🐚", ["agua"]], ["Cloyster", "🐚", ["agua", "gelo"]],
  ["Gastly", "👻", ["fantasma", "veneno"]], ["Haunter", "👻", ["fantasma", "veneno"]],
  ["Onix", "🪨", ["pedra", "terra"]], ["Drowzee", "🧠", ["psiquico"]], ["Hypno", "🧠", ["psiquico"]],
  ["Krabby", "🦀", ["agua"]], ["Kingler", "🦀", ["agua"]],
  ["Voltorb", "🔴", ["eletrico", "bola"]], ["Electrode", "🔴", ["eletrico", "bola"]],
  ["Exeggcute", "🥚", ["planta", "psiquico"]], ["Exeggutor", "🌴", ["planta", "psiquico"]],
  ["Cubone", "🦴", ["terra"]], ["Marowak", "🦴", ["terra"]],
  ["Hitmonlee", "🥋", ["lutador"]], ["Hitmonchan", "🥊", ["lutador"]], ["Lickitung", "👅", ["normal"]],
  ["Koffing", "💨", ["veneno"]], ["Weezing", "💨", ["veneno"]],
  ["Rhyhorn", "🦏", ["terra", "pedra"]], ["Rhydon", "🦏", ["terra", "pedra"]],
  ["Chansey", "🥚", ["normal"]], ["Tangela", "🌿", ["planta"]], ["Kangaskhan", "🦘", ["normal"]],
  ["Horsea", "🐴", ["agua"]], ["Seadra", "🐴", ["agua"]],
  ["Goldeen", "🐟", ["agua"]], ["Seaking", "🐟", ["agua"]],
  ["Staryu", "⭐", ["agua"]], ["Starmie", "⭐", ["agua", "psiquico"]],
  ["Mr. Mime", "🤡", ["psiquico", "fada"]], ["Scyther", "🪲", ["inseto", "voador"]],
  ["Jynx", "❄️", ["gelo", "psiquico"]], ["Electabuzz", "⚡", ["eletrico"]], ["Magmar", "🔥", ["fogo"]],
  ["Pinsir", "🪲", ["inseto"]], ["Tauros", "🐂", ["normal"]], ["Magikarp", "🐟", ["agua"]],
  ["Ditto", "🟣", ["normal"]], ["Vaporeon", "💧", ["agua", "cachorro"]],
  ["Jolteon", "⚡", ["eletrico", "cachorro"]], ["Flareon", "🔥", ["fogo", "cachorro"]],
  ["Porygon", "💻", ["normal"]], ["Omanyte", "🐚", ["pedra", "agua"]], ["Omastar", "🐚", ["pedra", "agua"]],
  ["Kabuto", "🦐", ["pedra", "agua"]], ["Kabutops", "🦐", ["pedra", "agua"]],
  ["Aerodactyl", "🦖", ["pedra", "voador"]], ["Articuno", "❄️", ["gelo", "voador", "passaro"]],
  ["Zapdos", "⚡", ["eletrico", "voador", "passaro"]], ["Moltres", "🔥", ["fogo", "voador", "passaro"]],
  ["Dratini", "🐉", ["dragao"]], ["Dragonair", "🐉", ["dragao"]],
  ["Chikorita", "🌱", ["planta"]], ["Cyndaquil", "🔥", ["fogo"]], ["Totodile", "🐊", ["agua"]],
  ["Togepi", "🥚", ["fada", "normal"]], ["Ampharos", "⚡", ["eletrico"]],
  ["Marill", "💧", ["agua", "fada"]], ["Sudowoodo", "🌳", ["pedra", "planta"]],
  ["Wooper", "🐟", ["agua", "terra"]], ["Murkrow", "🐦", ["sombra", "voador", "passaro"]],
  ["Misdreavus", "👻", ["fantasma"]], ["Steelix", "🪨", ["metal", "terra"]],
  ["Scizor", "🪲", ["inseto", "metal"]], ["Heracross", "🪲", ["inseto", "lutador"]],
  ["Typhlosion", "🔥", ["fogo"]], ["Feraligatr", "🐊", ["agua"]], ["Ho-Oh", "🔥", ["fogo", "voador", "passaro"]],
  ["Treecko", "🦎", ["planta"]], ["Torchic", "🐥", ["fogo", "passaro"]], ["Mudkip", "🐟", ["agua"]],
  ["Gardevoir", "🧠", ["psiquico", "fada"]], ["Aggron", "🪨", ["metal", "pedra"]],
  ["Flygon", "🐉", ["dragao", "terra"]], ["Milotic", "🐍", ["agua"]], ["Absol", "🐺", ["sombra"]],
  ["Metagross", "🧠", ["metal", "psiquico"]], ["Rayquaza", "🐉", ["dragao", "voador"]],
  ["Piplup", "🐧", ["agua", "passaro"]], ["Lucario", "🐺", ["lutador", "metal"]],
  ["Garchomp", "🦈", ["dragao", "terra"]], ["Blaziken", "🔥", ["fogo", "lutador"]],
  ["Swampert", "💧", ["agua", "terra"]], ["Sceptile", "🦎", ["planta"]],
  ["Greninja", "🐸", ["agua", "sombra"]], ["Sylveon", "🎀", ["fada"]], ["Mimikyu", "👻", ["fantasma", "fada"]],
  ["Umbreon", "🌑", ["sombra"]], ["Espeon", "☀️", ["psiquico"]], ["Leafeon", "🍃", ["planta"]],
  ["Glaceon", "❄️", ["gelo"]], ["Tyranitar", "🦖", ["pedra", "sombra"]], ["Blissey", "🥚", ["normal"]],
  ["Togekiss", "🕊️", ["fada", "voador"]], ["Luxray", "⚡", ["eletrico"]], ["Staraptor", "🦅", ["normal", "voador", "passaro"]],
  ["Infernape", "🔥", ["fogo", "lutador"]], ["Empoleon", "🐧", ["agua", "metal"]],
  ["Torterra", "🐢", ["planta", "terra"]], ["Darkrai", "🌑", ["sombra"]], ["Zoroark", "🦊", ["sombra", "raposa"]],
];
// ===== PONTOS TURÍSTICOS DO MUNDO TODO =====
const PONTOS_LISTA: TuplaBanco[] = [
  ["Turismo", "✈️", ["turismo", "viagem", "mundo", "monumento"]],
  ["Cristo Redentor", "🇧🇷", ["turismo", "monumento", "brasil", "rio", "mundo"]],
  ["Torre Eiffel", "🗼", ["turismo", "monumento", "mundo", "paris", "ferro"]],
  ["Coliseu", "🏛️", ["turismo", "monumento", "mundo", "roma", "pedra", "historia"]],
  ["Machu Picchu", "⛰️", ["turismo", "monumento", "mundo", "montanha", "pedra", "historia"]],
  ["Estátua da Liberdade", "🗽", ["turismo", "monumento", "mundo", "nova", "liberdade"]],
  ["Torre de Pisa", "🗼", ["turismo", "monumento", "mundo", "pisa", "torre"]],
  ["Muralha da China", "🧱", ["turismo", "monumento", "mundo", "china", "pedra", "historia"]],
  ["Pirâmides de Gizé", "🔺", ["turismo", "monumento", "mundo", "egito", "pedra", "deserto"]],
  ["Taj Mahal", "🕌", ["turismo", "monumento", "mundo", "india", "pedra", "amor"]],
  ["Big Ben", "🕰️", ["turismo", "monumento", "mundo", "londres", "torre"]],
  ["Cataratas do Iguaçu", "🌊", ["turismo", "brasil", "agua", "cachoeira", "mundo", "natureza"]],
  ["Lençóis Maranhenses", "🏜️", ["turismo", "brasil", "areia", "agua", "natureza", "praia"]],
  ["Pão de Açúcar", "🚡", ["turismo", "brasil", "rio", "montanha", "mar"]],
  ["Pelourinho", "🏘️", ["turismo", "brasil", "bahia", "historia", "festa"]],
  ["Fernando de Noronha", "🏝️", ["turismo", "brasil", "praia", "mar", "ilha"]],
  ["Chapada Diamantina", "⛰️", ["turismo", "brasil", "bahia", "montanha", "cachoeira"]],
  ["Pantanal", "🐊", ["turismo", "brasil", "natureza", "animal", "agua"]],
  ["Amazônia", "🌳", ["turismo", "brasil", "natureza", "floresta", "rio", "planta"]],
  ["Ouro Preto", "⛪", ["turismo", "brasil", "minas", "historia", "pedra", "ouro"]],
  ["Gramado", "🌸", ["turismo", "brasil", "frio", "flor", "festa"]],
  ["Jericoacoara", "🏖️", ["turismo", "brasil", "praia", "vento", "mar", "sol"]],
  ["Porto de Galinhas", "🏖️", ["turismo", "brasil", "praia", "mar", "sol"]],
  ["Bonito", "🐠", ["turismo", "brasil", "agua", "rio", "natureza"]],
  ["Foz do Iguaçu", "🌊", ["turismo", "brasil", "agua", "cachoeira"]],
  ["Salvador", "🎶", ["turismo", "brasil", "bahia", "praia", "festa"]],
  ["Arco do Triunfo", "🏛️", ["turismo", "monumento", "mundo", "paris"]],
  ["Sagrada Família", "⛪", ["turismo", "monumento", "mundo", "barcelona"]],
  ["Alhambra", "🏰", ["turismo", "monumento", "mundo", "espanha", "castelo"]],
  ["Castelo de Neuschwanstein", "🏰", ["turismo", "monumento", "mundo", "alemanha", "castelo"]],
  ["Kremlin", "🏰", ["turismo", "monumento", "mundo", "moscou", "castelo"]],
  ["Basílica de São Pedro", "⛪", ["turismo", "monumento", "mundo", "roma"]],
  ["Museu do Louvre", "🖼️", ["turismo", "monumento", "mundo", "paris", "arte"]],
  ["Times Square", "🌆", ["turismo", "mundo", "nova", "cidade", "luz"]],
  ["Central Park", "🌳", ["turismo", "mundo", "nova", "parque", "planta"]],
  ["Golden Gate", "🌉", ["turismo", "monumento", "mundo", "california", "ponte"]],
  ["Grand Canyon", "🏜️", ["turismo", "mundo", "natureza", "pedra", "deserto"]],
  ["Niagara Falls", "🌊", ["turismo", "mundo", "agua", "cachoeira", "natureza"]],
  ["Chichen Itza", "🛕", ["turismo", "monumento", "mundo", "mexico", "pedra", "historia"]],
  ["Petra", "🏜️", ["turismo", "monumento", "mundo", "pedra", "deserto", "historia"]],
  ["Hagia Sophia", "🕌", ["turismo", "monumento", "mundo", "turquia", "historia"]],
  ["Angkor Wat", "🛕", ["turismo", "monumento", "mundo", "pedra", "historia"]],
  ["Sydney Opera House", "🎭", ["turismo", "monumento", "mundo", "sydney", "musica"]],
  ["Monte Fuji", "🗻", ["turismo", "mundo", "japao", "montanha", "neve"]],
  ["Templo de Kyoto", "⛩️", ["turismo", "monumento", "mundo", "japao", "historia"]],
  ["Palácio de Versalhes", "👑", ["turismo", "monumento", "mundo", "paris", "castelo", "tesouro"]],
  ["Acropole", "🏛️", ["turismo", "monumento", "mundo", "grecia", "pedra", "historia"]],
  ["Santorini", "🏝️", ["turismo", "mundo", "grecia", "ilha", "mar", "sol"]],
  ["Pirâmide do Sol", "🔺", ["turismo", "monumento", "mundo", "mexico", "pedra"]],
  ["Burj Khalifa", "🏙️", ["turismo", "monumento", "mundo", "dubai", "torre", "cidade"]],
];
// ===== TODOS OS ESTADOS DO BRASIL + regiões e marcos =====
const ESTADOS_LISTA: TuplaBanco[] = [
  ["Brasil", "🇧🇷", ["brasil", "pais", "turismo", "praia", "festa", "floresta", "estado"]],
  ["Acre", "🌳", ["brasil", "estado", "floresta", "amazonia", "rio"]],
  ["Alagoas", "🏖️", ["brasil", "estado", "praia", "mar", "sol"]],
  ["Amapá", "🌳", ["brasil", "estado", "floresta", "amazonia", "rio"]],
  ["Amazonas", "🌳", ["brasil", "estado", "floresta", "amazonia", "rio", "natureza"]],
  ["Bahia", "🎶", ["brasil", "estado", "praia", "festa", "sol", "mar", "carnaval"]],
  ["Ceará", "🏖️", ["brasil", "estado", "praia", "vento", "sol", "mar"]],
  ["Distrito Federal", "🏛️", ["brasil", "estado", "cidade", "capital", "brasilia"]],
  ["Espírito Santo", "🏖️", ["brasil", "estado", "praia", "mar", "montanha"]],
  ["Goiás", "🌾", ["brasil", "estado", "cerrado", "terra", "comida"]],
  ["Maranhão", "🏜️", ["brasil", "estado", "areia", "praia", "lencois", "festa"]],
  ["Mato Grosso", "🌾", ["brasil", "estado", "cerrado", "pantanal", "terra"]],
  ["Mato Grosso do Sul", "🐊", ["brasil", "estado", "pantanal", "agua", "animal"]],
  ["Minas Gerais", "🧀", ["brasil", "estado", "montanha", "pedra", "comida", "ouro", "historia"]],
  ["Pará", "🌳", ["brasil", "estado", "floresta", "amazonia", "rio", "comida"]],
  ["Paraíba", "🏖️", ["brasil", "estado", "praia", "sol", "mar"]],
  ["Paraná", "🌊", ["brasil", "estado", "cachoeira", "agua", "frio"]],
  ["Pernambuco", "🎶", ["brasil", "estado", "praia", "festa", "mar", "carnaval"]],
  ["Piauí", "🏜️", ["brasil", "estado", "sertão", "terra", "sol"]],
  ["Rio de Janeiro", "🏖️", ["brasil", "estado", "praia", "mar", "sol", "festa", "cidade", "turismo"]],
  ["Rio Grande do Norte", "🏖️", ["brasil", "estado", "praia", "vento", "sol", "mar"]],
  ["Rio Grande do Sul", "🧉", ["brasil", "estado", "frio", "campo", "terra", "festa"]],
  ["Rondônia", "🌳", ["brasil", "estado", "floresta", "amazonia", "rio"]],
  ["Roraima", "⛰️", ["brasil", "estado", "montanha", "floresta", "fronteira"]],
  ["Santa Catarina", "🏖️", ["brasil", "estado", "praia", "frio", "flor", "mar"]],
  ["São Paulo", "🏙️", ["brasil", "estado", "cidade", "comida", "trabalho"]],
  ["Sergipe", "🏖️", ["brasil", "estado", "praia", "rio", "mar", "sol"]],
  ["Tocantins", "🏜️", ["brasil", "estado", "cerrado", "rio", "terra"]],
  ["Região Norte", "🌳", ["brasil", "regiao", "floresta", "amazonia", "rio"]],
  ["Região Nordeste", "☀️", ["brasil", "regiao", "praia", "festa", "sol", "mar"]],
  ["Região Centro-Oeste", "🌾", ["brasil", "regiao", "cerrado", "pantanal", "terra"]],
  ["Região Sudeste", "🏙️", ["brasil", "regiao", "cidade", "montanha", "mar"]],
  ["Região Sul", "❄️", ["brasil", "regiao", "frio", "campo", "praia"]],
  ["Amazônia", "🌳", ["brasil", "floresta", "rio", "natureza", "planta"]],
  ["Pantanal", "🐊", ["brasil", "natureza", "agua", "animal"]],
  ["Cerrado", "🌾", ["brasil", "terra", "planta", "natureza"]],
  ["Caatinga", "🌵", ["brasil", "sertão", "terra", "sol", "planta"]],
  ["Mata Atlântica", "🌿", ["brasil", "floresta", "planta", "natureza"]],
  ["Pampas", "🐎", ["brasil", "campo", "terra", "cavalo"]],
  ["Sertão", "☀️", ["brasil", "sertão", "sol", "terra"]],
  ["Brasília", "🏛️", ["brasil", "cidade", "capital", "brasilia"]],
  ["Manaus", "🌳", ["brasil", "cidade", "amazonia", "rio", "floresta"]],
];
// ===== CIDADES DO MUNDO — grandes capitais + cidades do Brasil =====
const CIDADES_LISTA: TuplaBanco[] = [
  ["São Paulo", "🏙️", ["cidade", "brasil", "mundo"]],
  ["Rio de Janeiro", "🏖️", ["cidade", "brasil", "mundo", "praia", "mar", "turismo"]],
  ["Teófilo Otoni", "💎", ["cidade", "brasil", "minas", "pedra", "terra"]],
  ["Belo Horizonte", "⛰️", ["cidade", "brasil", "minas", "montanha", "comida"]],
  ["Salvador", "🎶", ["cidade", "brasil", "bahia", "praia", "festa"]],
  ["Fortaleza", "🏖️", ["cidade", "brasil", "praia", "vento", "sol", "mar"]],
  ["Brasília", "🏛️", ["cidade", "brasil", "capital"]],
  ["Curitiba", "🌲", ["cidade", "brasil", "frio", "parque"]],
  ["Porto Alegre", "🧉", ["cidade", "brasil", "frio", "campo"]],
  ["Recife", "🏖️", ["cidade", "brasil", "praia", "mar", "festa"]],
  ["Manaus", "🌳", ["cidade", "brasil", "amazonia", "rio", "floresta"]],
  ["Belém", "🌳", ["cidade", "brasil", "amazonia", "rio", "comida"]],
  ["Goiânia", "🌾", ["cidade", "brasil", "cerrado"]],
  ["Campinas", "🏙️", ["cidade", "brasil"]],
  ["Florianópolis", "🏖️", ["cidade", "brasil", "praia", "ilha", "mar"]],
  ["Natal", "🏖️", ["cidade", "brasil", "praia", "sol", "mar"]],
  ["João Pessoa", "🏖️", ["cidade", "brasil", "praia", "sol", "mar"]],
  ["Maceió", "🏖️", ["cidade", "brasil", "praia", "mar"]],
  ["Aracaju", "🏖️", ["cidade", "brasil", "praia", "rio"]],
  ["Vitória", "🏖️", ["cidade", "brasil", "praia", "ilha", "mar"]],
  ["Cuiabá", "☀️", ["cidade", "brasil", "pantanal", "sol"]],
  ["Campo Grande", "🐊", ["cidade", "brasil", "pantanal"]],
  ["São Luís", "🏖️", ["cidade", "brasil", "praia", "festa", "historia"]],
  ["Teresina", "☀️", ["cidade", "brasil", "sol", "rio"]],
  ["Ouro Preto", "⛪", ["cidade", "brasil", "minas", "historia", "ouro"]],
  ["Gramado", "🌸", ["cidade", "brasil", "frio", "flor"]],
  ["Tokyo", "🗼", ["cidade", "mundo", "japao", "tecnologia"]],
  ["Paris", "🗼", ["cidade", "mundo", "turismo", "arte"]],
  ["Londres", "🎡", ["cidade", "mundo", "turismo", "rio"]],
  ["Nova York", "🗽", ["cidade", "mundo", "turismo", "liberdade"]],
  ["Los Angeles", "🎬", ["cidade", "mundo", "filme", "sol", "praia"]],
  ["Pequim", "🏯", ["cidade", "mundo", "china", "historia"]],
  ["Moscou", "🏰", ["cidade", "mundo", "frio", "castelo"]],
  ["Cairo", "🔺", ["cidade", "mundo", "egito", "deserto", "historia"]],
  ["Sydney", "🎭", ["cidade", "mundo", "praia", "mar"]],
  ["Berlim", "🧱", ["cidade", "mundo", "historia", "arte"]],
  ["Madri", "⚽", ["cidade", "mundo", "espanha", "festa"]],
  ["Roma", "🏛️", ["cidade", "mundo", "historia", "turismo"]],
  ["Lisboa", "🚋", ["cidade", "mundo", "mar", "historia"]],
  ["Amsterdã", "🌷", ["cidade", "mundo", "flor", "rio"]],
  ["Toronto", "🍁", ["cidade", "mundo", "frio"]],
  ["Cidade do México", "🌮", ["cidade", "mundo", "mexico", "comida"]],
  ["Buenos Aires", "💃", ["cidade", "mundo", "musica", "festa"]],
  ["Santiago", "⛰️", ["cidade", "mundo", "montanha"]],
  ["Lima", "🌊", ["cidade", "mundo", "mar", "comida"]],
  ["Bogotá", "⛰️", ["cidade", "mundo", "montanha"]],
  ["Seul", "🏙️", ["cidade", "mundo", "coreia", "tecnologia"]],
  ["Xangai", "🏙️", ["cidade", "mundo", "china"]],
  ["Mumbai", "🎬", ["cidade", "mundo", "india", "filme"]],
  ["Nova Délhi", "🕌", ["cidade", "mundo", "india", "historia"]],
  ["Bangkok", "🛕", ["cidade", "mundo", "historia"]],
  ["Jacarta", "🌋", ["cidade", "mundo", "ilha"]],
  ["Dubai", "🏙️", ["cidade", "mundo", "deserto", "torre"]],
  ["Istambul", "🕌", ["cidade", "mundo", "turquia", "historia"]],
  ["Atenas", "🏛️", ["cidade", "mundo", "grecia", "historia"]],
  ["Viena", "🎻", ["cidade", "mundo", "musica"]],
  ["Praga", "🏰", ["cidade", "mundo", "castelo", "historia"]],
  ["Estocolmo", "❄️", ["cidade", "mundo", "frio", "ilha"]],
  ["Oslo", "❄️", ["cidade", "mundo", "frio"]],
  ["Dublin", "☘️", ["cidade", "mundo", "planta", "musica"]],
  ["Edimburgo", "🏰", ["cidade", "mundo", "castelo"]],
  ["Zurique", "🏔️", ["cidade", "mundo", "montanha", "frio"]],
  ["Genebra", "⌚", ["cidade", "mundo"]],
  ["Cidade do Cabo", "🏔️", ["cidade", "mundo", "montanha", "mar"]],
  ["Marrakech", "🏜️", ["cidade", "mundo", "deserto", "festa"]],
  ["Montreal", "🍁", ["cidade", "mundo", "frio"]],
  ["Chicago", "🌬️", ["cidade", "mundo", "vento"]],
  ["San Francisco", "🌉", ["cidade", "mundo", "ponte"]],
  ["Las Vegas", "🎰", ["cidade", "mundo", "festa", "luz"]],
  ["Seattle", "🌧️", ["cidade", "mundo", "chuva"]],
  ["Miami", "🏖️", ["cidade", "mundo", "praia", "sol", "mar"]],
  ["Houston", "🚀", ["cidade", "mundo", "espaco"]],
];
const BANCO_UNIVERSOS: Record<string, EntradaUniverso[]> = {
  "Pokémon": banco(POKEMON_LISTA, "Anime"),
  "Pontos Turísticos do Mundo": banco(PONTOS_LISTA, "Vida Real"),
  "Estados do Brasil": banco(ESTADOS_LISTA, "Vida Real"),
  "Cidades do Mundo": banco(CIDADES_LISTA, "Vida Real"),
  "Naruto": [
    { nome: "Naruto", emoji: "🍥", tags: ["vento", "chakra", "raposa"], categoria: "Anime" },
    { nome: "Sasuke", emoji: "⚡", tags: ["eletrico", "fogo", "espada"], categoria: "Anime" },
    { nome: "Kakashi", emoji: "⚡", tags: ["eletrico", "chakra"], categoria: "Anime" },
    { nome: "Sakura", emoji: "🌸", tags: ["forca", "cura"], categoria: "Anime" },
    { nome: "Kurama", emoji: "🦊", tags: ["fogo", "raposa", "chakra"], categoria: "Anime" },
    { nome: "Sharingan", emoji: "👁️", tags: ["olho", "chakra", "fogo"], categoria: "Anime" },
    { nome: "Rasengan", emoji: "🌪️", tags: ["vento", "chakra"], categoria: "Anime" },
    { nome: "Chidori", emoji: "⚡", tags: ["eletrico", "raio", "jutsu"], categoria: "Anime" },
    { nome: "Hinata", emoji: "👁️", tags: ["olho", "chakra"], categoria: "Anime" },
    { nome: "Gaara", emoji: "🏜️", tags: ["areia", "terra"], categoria: "Anime" },
    { nome: "Jiraiya", emoji: "🐸", tags: ["sapo", "chakra"], categoria: "Anime" },
    { nome: "Itachi", emoji: "👁️", tags: ["olho", "fogo"], categoria: "Anime" },
    { nome: "Suna", emoji: "🏜️", tags: ["areia", "vento", "terra"], categoria: "Anime" },
    { nome: "Mokuton", emoji: "🌳", tags: ["planta", "terra", "chakra"], categoria: "Anime" },
  ],
  "Dragon Ball": [
    { nome: "Goku", emoji: "🐉", tags: ["lutador", "saiyajin"], categoria: "Anime" },
    { nome: "Vegeta", emoji: "👑", tags: ["lutador", "saiyajin"], categoria: "Anime" },
    { nome: "Frieza", emoji: "❄️", tags: ["gelo", "lutador", "vilao"], categoria: "Anime" },
    { nome: "Gohan", emoji: "📚", tags: ["lutador", "saiyajin"], categoria: "Anime" },
    { nome: "Piccolo", emoji: "🟢", tags: ["lutador"], categoria: "Anime" },
    { nome: "Esfera do Dragão", emoji: "🐉", tags: ["esfera", "desejo", "dragao"], categoria: "Anime" },
    { nome: "Shenron", emoji: "🐉", tags: ["dragao", "desejo"], categoria: "Anime" },
    { nome: "Trunks", emoji: "⚔️", tags: ["espada", "lutador"], categoria: "Anime" },
    { nome: "Cell", emoji: "🟢", tags: ["lutador", "vilao"], categoria: "Anime" },
    { nome: "Majin Boo", emoji: "🍬", tags: ["doce", "lutador"], categoria: "Anime" },
    { nome: "Kamehameha", emoji: "💥", tags: ["energia", "lutador"], categoria: "Anime" },
  ],
  "One Piece": [
    { nome: "Luffy", emoji: "👒", tags: ["borracha", "pirata", "lutador"], categoria: "Anime" },
    { nome: "Zoro", emoji: "⚔️", tags: ["espada", "pirata", "lutador"], categoria: "Anime" },
    { nome: "Nami", emoji: "🌦️", tags: ["vento", "clima", "pirata"], categoria: "Anime" },
    { nome: "Sanji", emoji: "🍳", tags: ["fogo", "cozinha", "pirata"], categoria: "Anime" },
    { nome: "Chopper", emoji: "🦌", tags: ["animal", "cura", "pirata"], categoria: "Anime" },
    { nome: "Usopp", emoji: "🎯", tags: ["atirador", "pirata"], categoria: "Anime" },
    { nome: "Robin", emoji: "🌸", tags: ["flor", "pirata"], categoria: "Anime" },
    { nome: "Brook", emoji: "💀", tags: ["musica", "pirata"], categoria: "Anime" },
    { nome: "Franky", emoji: "🤖", tags: ["robo", "pirata"], categoria: "Anime" },
    { nome: "Ace", emoji: "🔥", tags: ["fogo", "pirata"], categoria: "Anime" },
    { nome: "Shanks", emoji: "🏴‍☠️", tags: ["pirata", "espada"], categoria: "Anime" },
    { nome: "Devil Fruit", emoji: "🍎", tags: ["fruta", "mar", "pirata"], categoria: "Anime" },
    { nome: "Luffy Gear 5", emoji: "🔥", tags: ["borracha", "fogo", "pirata"], categoria: "Anime" },
  ],
  "Mitologia": [
    { nome: "Hidra", emoji: "🐲", tags: ["agua", "dragao", "monstro"], categoria: "Mitologia" },
    { nome: "Fênix", emoji: "🔥", tags: ["fogo", "passaro"], categoria: "Mitologia" },
    { nome: "Kraken", emoji: "🦑", tags: ["agua", "monstro", "mar"], categoria: "Mitologia" },
    { nome: "Minotauro", emoji: "🐂", tags: ["monstro", "labirinto", "terra"], categoria: "Mitologia" },
    { nome: "Excalibur", emoji: "🗡️", tags: ["espada", "magia", "pedra"], categoria: "Mitologia" },
    { nome: "Pégaso", emoji: "🦄", tags: ["voador", "cavalo", "vento"], categoria: "Mitologia" },
    { nome: "Medusa", emoji: "🐍", tags: ["pedra", "monstro"], categoria: "Mitologia" },
    { nome: "Golem", emoji: "🗿", tags: ["terra", "pedra", "magia"], categoria: "Mitologia" },
    { nome: "Thor", emoji: "⚡", tags: ["eletrico", "raio", "martelo"], categoria: "Mitologia" },
    { nome: "Zeus", emoji: "⚡", tags: ["eletrico", "raio", "ceu"], categoria: "Mitologia" },
    { nome: "Poseidon", emoji: "🌊", tags: ["agua", "mar"], categoria: "Mitologia" },
    { nome: "Pote de Ouro", emoji: "🪙", tags: ["tesouro", "ouro"], categoria: "Mitologia" },
    { nome: "Homem de Barro", emoji: "🗿", tags: ["terra", "lama", "magia"], categoria: "Mitologia" },
    { nome: "Dragão de Fogo", emoji: "🐉", tags: ["fogo", "dragao"], categoria: "Mitologia" },
    { nome: "Golem de Barro", emoji: "🗿", tags: ["terra", "lama", "magia"], categoria: "Mitologia" },
  ],
  "Filme": [
    { nome: "Hogwarts", emoji: "🏰", tags: ["magia", "escola"], categoria: "Filme" },
    { nome: "Sabre de Luz", emoji: "🗡️", tags: ["espada", "luz", "energia"], categoria: "Filme" },
    { nome: "Varinha Mágica", emoji: "🪄", tags: ["magia"], categoria: "Filme" },
    { nome: "Vingadores", emoji: "🦸", tags: ["heroi", "lutador"], categoria: "Filme" },
    { nome: "Jurassic Park", emoji: "🦖", tags: ["dinossauro", "terra"], categoria: "Filme" },
    { nome: "Casa do Hobbit", emoji: "🏡", tags: ["casa", "terra"], categoria: "Filme" },
    { nome: "Portal do Doutor Estranho", emoji: "🌀", tags: ["portal", "magia"], categoria: "Filme" },
    { nome: "Portal", emoji: "🌀", tags: ["portal", "magia"], categoria: "Filme" },
    { nome: "Demogorgon", emoji: "👹", tags: ["monstro", "sombra"], categoria: "Série" },
    { nome: "Mundo Invertido", emoji: "🌀", tags: ["sombra", "portal"], categoria: "Série" },
    { nome: "Feitiço", emoji: "✨", tags: ["magia"], categoria: "Filme" },
    { nome: "Baú Mágico", emoji: "🎁", tags: ["tesouro", "magia"], categoria: "Filme" },
    { nome: "Pedra do Infinito", emoji: "💎", tags: ["pedra", "energia", "magia"], categoria: "Filme" },
    { nome: "Balrog", emoji: "🔥", tags: ["fogo", "monstro", "magia"], categoria: "Filme" },
    { nome: "Patrono", emoji: "🦌", tags: ["animal", "magia"], categoria: "Filme" },
    { nome: "Flor Mágica", emoji: "🌸", tags: ["flor", "magia"], categoria: "Filme" },
    { nome: "Vassoura Voadora", emoji: "🧹", tags: ["voador", "magia"], categoria: "Filme" },
    { nome: "Dragão de Game of Thrones", emoji: "🐉", tags: ["fogo", "dragao"], categoria: "Série" },
    { nome: "Pedra Filosofal", emoji: "🪨", tags: ["pedra", "magia"], categoria: "Filme" },
  ],
  "Vida Real": [
    { nome: "Praia", emoji: "🏖️", tags: ["agua", "mar", "sol"], categoria: "Vida Real" },
    { nome: "Onda", emoji: "🌊", tags: ["agua", "mar"], categoria: "Vida Real" },
    { nome: "Cachoeira", emoji: "🌊", tags: ["agua"], categoria: "Vida Real" },
    { nome: "Piscina", emoji: "🏊", tags: ["agua"], categoria: "Vida Real" },
    { nome: "Suco de Laranja", emoji: "🍊", tags: ["fruta", "doce", "agua"], categoria: "Vida Real" },
    { nome: "Água de Coco", emoji: "🥥", tags: ["fruta", "agua"], categoria: "Vida Real" },
    { nome: "Churrasco", emoji: "🔥", tags: ["fogo", "comida"], categoria: "Vida Real" },
    { nome: "Fogueira", emoji: "🔥", tags: ["fogo"], categoria: "Vida Real" },
    { nome: "Pão de Queijo", emoji: "🧀", tags: ["comida", "queijo"], categoria: "Vida Real" },
    { nome: "Pipoca", emoji: "🍿", tags: ["comida", "fogo"], categoria: "Vida Real" },
    { nome: "Café Coado", emoji: "☕", tags: ["comida", "agua", "fogo"], categoria: "Vida Real" },
    { nome: "Marshmallow", emoji: "🍡", tags: ["doce", "fogo"], categoria: "Vida Real" },
    { nome: "Montanha", emoji: "⛰️", tags: ["terra", "pedra"], categoria: "Vida Real" },
    { nome: "Jardim", emoji: "🌷", tags: ["flor", "planta", "terra"], categoria: "Vida Real" },
    { nome: "Horta", emoji: "🥕", tags: ["planta", "terra", "comida"], categoria: "Vida Real" },
    { nome: "Trilha", emoji: "🥾", tags: ["terra"], categoria: "Vida Real" },
    { nome: "Caverna", emoji: "🕳️", tags: ["terra", "pedra"], categoria: "Vida Real" },
    { nome: "Campo de Girassóis", emoji: "🌻", tags: ["flor", "planta"], categoria: "Vida Real" },
    { nome: "Pipa", emoji: "🪁", tags: ["vento"], categoria: "Vida Real" },
    { nome: "Cata-vento", emoji: "🌪️", tags: ["vento"], categoria: "Vida Real" },
    { nome: "Brisa do Mar", emoji: "🌬️", tags: ["vento", "mar", "agua"], categoria: "Vida Real" },
    { nome: "Balão", emoji: "🎈", tags: ["vento", "voador"], categoria: "Vida Real" },
    { nome: "Parapente", emoji: "🪂", tags: ["vento", "voador"], categoria: "Vida Real" },
    { nome: "Dente-de-leão", emoji: "🌼", tags: ["flor", "vento"], categoria: "Vida Real" },
    { nome: "Pão", emoji: "🍞", tags: ["comida"], categoria: "Vida Real" },
    { nome: "Pizza", emoji: "🍕", tags: ["comida", "fogo"], categoria: "Vida Real" },
    { nome: "Café", emoji: "☕", tags: ["comida"], categoria: "Vida Real" },
    { nome: "Brigadeiro", emoji: "🍫", tags: ["doce", "comida"], categoria: "Vida Real" },
    { nome: "Neve", emoji: "❄️", tags: ["agua", "gelo", "frio"], categoria: "Vida Real" },
    { nome: "Bolo de Chocolate", emoji: "🍰", tags: ["doce", "comida", "chocolate"], categoria: "Vida Real" },
    { nome: "Arco-íris", emoji: "🌈", tags: ["luz", "agua"], categoria: "Vida Real" },
    { nome: "Gelo", emoji: "❄️", tags: ["agua", "gelo", "frio"], categoria: "Vida Real" },
    { nome: "Rio", emoji: "🌊", tags: ["agua", "terra"], categoria: "Vida Real" },
    // ===== TERRA REAL PRIMEIRO — correções dos exemplos errados =====
    // Vitória Régia / Alga / Planta Aquática: Água + Planta é planta de água,
    // nunca Gyarados (Água/Dragão, sem planta). Gelo Brilhante: Diamante/Cristal
    // + Água não tem tag elétrica, então nunca é Jolteon. Cachorro Quente:
    // Fogo + Cachorro é comida/cachorro quente, nunca Vaporeon (Água).
    { nome: "Vitória Régia", emoji: "🌸", tags: ["agua", "planta", "flor"], categoria: "Vida Real" },
    { nome: "Alga", emoji: "🌿", tags: ["agua", "planta"], categoria: "Vida Real" },
    { nome: "Planta Aquática", emoji: "🌱", tags: ["agua", "planta"], categoria: "Vida Real" },
    { nome: "Gelo Brilhante", emoji: "💎", tags: ["agua", "gelo", "pedra", "brilho"], categoria: "Vida Real" },
    { nome: "Diamante Molhado", emoji: "💎", tags: ["agua", "pedra", "brilho"], categoria: "Vida Real" },
    { nome: "Cachorro Quente", emoji: "🌭", tags: ["cachorro", "fogo", "comida"], categoria: "Vida Real" },
    { nome: "Pata Quente", emoji: "🐾", tags: ["cachorro", "fogo"], categoria: "Vida Real" },
    { nome: "Banho de Cachorro", emoji: "🐶", tags: ["cachorro", "agua"], categoria: "Vida Real" },
  ],
  "San Craft": [
    { nome: "San", emoji: "🧪", tags: ["criador"], categoria: "Vida Real" },
    { nome: "Meg", emoji: "🐶", tags: ["cachorro", "animal"], categoria: "Vida Real" },
    { nome: "Amizade", emoji: "💛", tags: ["amizade", "cachorro", "criador"], categoria: "Vida Real" },
    { nome: "Carinho", emoji: "❤️", tags: ["amizade", "cachorro"], categoria: "Vida Real" },
    { nome: "Passeio no Parque", emoji: "🌳", tags: ["cachorro", "animal", "vento"], categoria: "Vida Real" },
    { nome: "Soneca", emoji: "💤", tags: ["cachorro", "animal"], categoria: "Vida Real" },
    { nome: "Petisco", emoji: "🦴", tags: ["cachorro", "comida"], categoria: "Vida Real" },
    { nome: "Coleira Brilhante", emoji: "💎", tags: ["cachorro", "brilho"], categoria: "Vida Real" },
    { nome: "Invenção", emoji: "💡", tags: ["criador", "ideia"], categoria: "Vida Real" },
    { nome: "Experimento", emoji: "🧪", tags: ["criador", "magia"], categoria: "Vida Real" },
    { nome: "Laboratório", emoji: "🧪", tags: ["criador"], categoria: "Vida Real" },
    { nome: "Banho de Cachorro", emoji: "🐶", tags: ["cachorro", "agua"], categoria: "Vida Real" },
    { nome: "Pata", emoji: "🐾", tags: ["cachorro", "animal"], categoria: "Vida Real" },
    { nome: "Pata Molhada", emoji: "🐾", tags: ["cachorro", "agua"], categoria: "Vida Real" },
  ],
  "Neutro": [
    { nome: "Água", emoji: "💧", tags: ["agua"], categoria: "Vida Real" },
    { nome: "Fogo", emoji: "🔥", tags: ["fogo"], categoria: "Vida Real" },
    { nome: "Vento", emoji: "💨", tags: ["vento"], categoria: "Vida Real" },
    { nome: "Terra", emoji: "🌍", tags: ["terra"], categoria: "Vida Real" },
    { nome: "Vapor", emoji: "♨️", tags: ["agua", "fogo"], categoria: "Vida Real" },
    { nome: "Lava", emoji: "🌋", tags: ["fogo", "terra"], categoria: "Vida Real" },
    { nome: "Chuva", emoji: "🌧️", tags: ["agua", "vento"], categoria: "Vida Real" },
    { nome: "Lama", emoji: "🟤", tags: ["agua", "terra"], categoria: "Vida Real" },
    { nome: "Poeira", emoji: "🌪️", tags: ["terra", "vento"], categoria: "Vida Real" },
    { nome: "Faísca", emoji: "✨", tags: ["fogo", "vento"], categoria: "Vida Real" },
    { nome: "Pedra", emoji: "🪨", tags: ["terra", "pedra"], categoria: "Vida Real" },
    { nome: "Flor", emoji: "🌸", tags: ["planta", "flor", "terra"], categoria: "Vida Real" },
    { nome: "Nuvem", emoji: "☁️", tags: ["agua", "vento"], categoria: "Vida Real" },
    { nome: "Tempestade", emoji: "⛈️", tags: ["vento", "agua", "eletrico", "raio"], categoria: "Vida Real" },
    { nome: "Cristal", emoji: "💎", tags: ["pedra", "terra"], categoria: "Vida Real" },
    { nome: "Magia", emoji: "🪄", tags: ["magia"], categoria: "Filme" },
    { nome: "Tesouro", emoji: "👑", tags: ["tesouro", "ouro"], categoria: "Filme" },
    { nome: "Ideia", emoji: "💡", tags: ["ideia"], categoria: "Vida Real" },
  ],
  "Anime": [
    { nome: "Bankai", emoji: "⚔️", tags: ["espada", "energia"], categoria: "Anime" },
    { nome: "Pokébola", emoji: "🔴", tags: ["captura", "bola"], categoria: "Anime" },
  ],
};
const ORDEM_UNIVERSOS = ["Pokémon", "Naruto", "Dragon Ball", "One Piece", "Mitologia", "Filme", "Vida Real", "San Craft", "Anime", "Neutro", "Pontos Turísticos do Mundo", "Estados do Brasil", "Cidades do Mundo"];
// Palavras do nome -> tags, para elementos que ainda não estão no banco
// (ex.: um elemento criado pelo Criador ou vindo de um save antigo).
const PALAVRA_PARA_TAGS: Record<string, string[]> = {
  fogo: ["fogo"], agua: ["agua"], vento: ["vento"], terra: ["terra"], eletrico: ["eletrico"], raio: ["eletrico", "raio"], trovao: ["eletrico", "raio"],
  dragao: ["dragao"], monstro: ["monstro"], captura: ["captura"], bola: ["bola"], esfera: ["esfera", "desejo"], desejo: ["desejo"],
  espada: ["espada"], pirata: ["pirata"], borracha: ["borracha"], chakra: ["chakra"], jutsu: ["jutsu"], magia: ["magia"],
  cachorro: ["cachorro", "animal"], animal: ["animal"], gato: ["animal"], criador: ["criador"], doce: ["doce"], comida: ["comida"],
  flor: ["flor", "planta"], planta: ["planta"], pedra: ["pedra"], mar: ["mar", "agua"], gelo: ["gelo", "frio"], portal: ["portal", "magia"],
  tesouro: ["tesouro", "ouro"], ouro: ["ouro"], luz: ["luz"], sombra: ["sombra"], voador: ["voador"], chuva: ["agua", "vento"],
  brasil: ["brasil"], turismo: ["turismo", "viagem"], praia: ["praia", "mar", "sol"], cidade: ["cidade"], estado: ["estado", "brasil"], monumento: ["monumento", "turismo"], viagem: ["turismo", "viagem"], cachoeira: ["cachoeira", "agua"], festa: ["festa"], capital: ["cidade", "capital"],
  diamante: ["pedra", "brilho", "cristal"], cristal: ["pedra", "brilho"], brilho: ["brilho"], planta: ["planta"], vitoria: ["planta", "agua", "flor"], alga: ["planta", "agua"],
};
function tagsDeNome(nome: string): string[] {
  const palavras = normalizar(nome).split(/[^a-z]+/).filter(Boolean);
  const tags: string[] = [];
  palavras.forEach((p) => (PALAVRA_PARA_TAGS[p] || []).forEach((t) => { if (!tags.includes(t)) tags.push(t); }));
  return tags;
}
function metadadosDe(e: Elemento): MetaElemento {
  if (e.universo && e.tags && e.tags.length) return { universo: e.universo, tags: e.tags, categoria: (e.categoria as CategoriaIA) || "Vida Real" };
  for (const universo of ORDEM_UNIVERSOS) {
    const achado = (BANCO_UNIVERSOS[universo] || []).find((x) => normalizar(x.nome) === normalizar(e.nome));
    if (achado) return { universo, tags: achado.tags, categoria: achado.categoria };
  }
  const tags = tagsDeNome(e.nome);
  return { universo: "San Craft", tags, categoria: (e.categoria as CategoriaIA) || "Vida Real" };
}
function tagsEmComum(a: string[], b: string[]): string[] { return a.filter((t) => b.includes(t)); }
function buscarNoUniverso(universo: string, tagsAlvo: string[], excluir: Set<string>, jaTem: (nome: string) => boolean): { entrada: EntradaUniverso; compartilhadas: string[] } | null {
  let melhor: { entrada: EntradaUniverso; compartilhadas: string[] } | null = null;
  for (const entrada of BANCO_UNIVERSOS[universo] || []) {
    if (excluir.has(entrada.nome) || jaTem(entrada.nome)) continue;
    const compartilhadas = tagsEmComum(entrada.tags, tagsAlvo);
    if (!compartilhadas.length) continue;
    if (!melhor || compartilhadas.length > melhor.compartilhadas.length) melhor = { entrada, compartilhadas };
  }
  return melhor;
}
function montarResultado(candidato: EntradaUniverso, universo: string, a: Elemento, b: Elemento, compartilhadas: string[], predominancia: string): ResultadoIA {
  const tagTexto = compartilhadas.length ? `tag em comum: ${compartilhadas.join(", ")}` : "sem tag em comum, então fica no universo de quem manda";
  const dic = dicionarioDe(candidato.nome);
  return {
    nome: limitarNomeIA(candidato.nome), emoji: candidato.emoji, categoria: candidato.categoria, universo, tags: candidato.tags,
    dicionario: dic?.dicionario, significado: dic?.significado, pais: dic?.pais, idioma: dic?.idioma,
    motivo: `Porque ${a.nome} é do universo ${metadadosDe(a).universo} e ${b.nome} ${predominancia} (${tagTexto}), então no universo ${universo} o resultado é ${candidato.nome}.`,
  };
}
// ===== DICIONÁRIO PRIMEIRO — PALAVRAS REAIS, NÃO INVENÇÕES =====
// Ordem da IA: 1) receita curada exata · 2) DICIONÁRIO PT-BR (Aurélio/Houaiss,
// uso brasileiro) · 3) Brasil (dicionário + lugares) · 4) DICIONÁRIOS DO MUNDO
// · 5) ficcional só com match forte nos dois insumos · 6) Criação Original, só
// com palavras que já existem no dicionário (ex.: Coleira + Brilhante).
// Formato: [nome, emoji, tags, significado, dicionário/origem]
type TuplaDicionario = [string, string, string[], string, string];
type EntradaDicionario = EntradaUniverso & { significado: string; dicionario: string; pais?: string; idioma?: string };
function dicionario(lista: TuplaDicionario[], categoria: CategoriaIA): EntradaDicionario[] {
  return lista.map(([nome, emoji, tags, significado, dicionario]) => ({ nome, emoji, tags, categoria, significado, dicionario }));
}
// ===== MODO MUNDO =====
// Idioma Base = Português do Brasil. A interface, as descrições e a
// concordância continuam em PT-BR. O dicionário do mundo só amplia o que
// pode ser descoberto: cada palavra guarda o país e o idioma de origem.
const IDIOMA_BASE = "Português do Brasil";
type TuplaMundo = [string, string, string[], string, string, string];
function dicionarioMundo(lista: TuplaMundo[], categoria: CategoriaIA): EntradaDicionario[] {
  return lista.map(([nome, emoji, tags, significado, idioma, pais]) => ({ nome, emoji, tags, categoria, significado, dicionario: idioma, idioma, pais }));
}
// País de origem das palavras antigas do dicionário do mundo, que só
// guardavam o idioma. Mantém o filtro de país funcionando para elas.
const PAIS_POR_PALAVRA_MUNDO: Record<string, string> = {
  Tsunami: "Japão", Sakura: "Japão", Samurai: "Japão", Katana: "Japão", Sushi: "Japão", Origami: "Japão", Karaokê: "Japão", Karaoke: "Japão", Ninja: "Japão", Sensei: "Japão", Zen: "Japão",
  Fiesta: "México", Siesta: "Espanha", Playa: "México", Sombrero: "México", Taco: "México", Piñata: "México", Salsa: "México", Tomate: "México", Tornado: "EUA",
  "Château": "França", Croissant: "França", Baguette: "França", Ballet: "França", "Déjà vu": "França", Parapluie: "França",
  Pizza: "Itália", Pasta: "Itália", Gelato: "Itália", Bravo: "Itália", Vulcano: "Itália",
  Blitz: "Alemanha", Wunderkind: "Alemanha", Kindergarten: "Alemanha", Poltergeist: "Alemanha",
  Samba: "Brasil", Capoeira: "Brasil", Aloha: "EUA", Ohana: "EUA", Safari: "Quênia", Jambo: "Quênia",
  Ocean: "EUA", Lake: "EUA", Thunder: "EUA", Rainbow: "EUA", Sunshine: "EUA", Snowflake: "EUA", Fireworks: "EUA", Butterfly: "EUA", Waterfall: "EUA", Moonlight: "EUA", Mango: "Índia", Coconut: "Índia", Volcano: "EUA", Hurricane: "EUA", Eclipse: "Grécia", Coffee: "EUA", Tea: "Inglaterra",
  Aurora: "Grécia", Terra: "Brasil", Aqua: "Itália", Ignis: "Itália", Ventus: "Itália", Luna: "Itália", Sol: "Brasil", Flora: "Itália", Fauna: "Itália",
  Yoga: "Índia", Karma: "Índia", Guru: "Índia", Chai: "Índia", Bazaar: "Turquia", Chocolate: "México",
};
const PAIS_POR_IDIOMA: Record<string, string> = { "Japonês": "Japão", "Espanhol": "México", "Francês": "França", "Italiano": "Itália", "Alemão": "Alemanha", "Inglês": "EUA", "Havaiano": "EUA", "Suaíli": "Quênia", "Sânscrito": "Índia", "Hindi": "Índia", "Persa": "Turquia", "Latim": "Itália", "Português": "Brasil" };
function paisDePalavraMundo(nome: string, idioma: string): string {
  return PAIS_POR_PALAVRA_MUNDO[nome] || PAIS_POR_IDIOMA[idioma] || "Mundo";
}
// Sementes de país: não são o prêmio da fusão, são o ponto de partida para
// fundir com países. Ex.: colocar Japão na Lousa e fundir com Água = Tsunami.
// Cada semente guarda a chave do país nas tags (ex.: "japao"), para o
// dicionário do mundo reconhecer a dupla país + elemento.
const PAISES_SEMENTES: Elemento[] = [
  { nome: "Japão", emoji: "🇯🇵", dica: "País das cerejeiras. Funda com Água, Flor, Montanha ou Pedra.", universo: "Mundo", tags: ["japao", "ilha"], pais: "Japão", idioma: "Japonês" },
  { nome: "México", emoji: "🇲🇽", dica: "País do sol e da pimenta. Funda com Fogo, Água, Terra ou Vento.", universo: "Mundo", tags: ["mexico", "sol"], pais: "México", idioma: "Espanhol" },
  { nome: "França", emoji: "🇫🇷", dica: "País da Torre Eiffel. Funda com Terra ou Fogo.", universo: "Mundo", tags: ["franca", "cidade"], pais: "França", idioma: "Francês" },
  { nome: "Itália", emoji: "🇮🇹", dica: "País da pizza e do Coliseu. Funda com Fogo ou Terra.", universo: "Mundo", tags: ["italia", "cidade"], pais: "Itália", idioma: "Italiano" },
  { nome: "Espanha", emoji: "🇪🇸", dica: "País do flamenco e da siesta. Funda com Vento, Terra ou Fogo.", universo: "Mundo", tags: ["espanha", "sol"], pais: "Espanha", idioma: "Espanhol" },
  { nome: "China", emoji: "🇨🇳", dica: "País da Muralha e do dragão. Funda com Terra ou Fogo.", universo: "Mundo", tags: ["china", "pedra"], pais: "China", idioma: "Mandarim" },
  { nome: "Coreia", emoji: "🇰🇷", dica: "País do K-Pop e do kimchi. Funda com Terra ou Vento.", universo: "Mundo", tags: ["coreia", "cidade"], pais: "Coreia", idioma: "Coreano" },
  { nome: "Índia", emoji: "🇮🇳", dica: "País do Taj Mahal e do curry. Funda com Terra ou Fogo.", universo: "Mundo", tags: ["india", "templo"], pais: "Índia", idioma: "Hindi" },
  { nome: "Egito", emoji: "🇪🇬", dica: "País das pirâmides e do Nilo. Funda com Terra, Água ou Fogo.", universo: "Mundo", tags: ["egito", "deserto"], pais: "Egito", idioma: "Árabe" },
  { nome: "Grécia", emoji: "🇬🇷", dica: "País do Olimpo e de Zeus. Funda com Terra ou Água.", universo: "Mundo", tags: ["grecia", "montanha"], pais: "Grécia", idioma: "Grego" },
  { nome: "EUA", emoji: "🇺🇸", dica: "País de Hollywood e do hambúrguer. Funda com Fogo ou Terra.", universo: "Mundo", tags: ["eua", "cidade"], pais: "EUA", idioma: "Inglês" },
  { nome: "Alemanha", emoji: "🇩🇪", dica: "País dos castelos e do pretzel. Funda com Terra ou Fogo.", universo: "Mundo", tags: ["alemanha", "castelo"], pais: "Alemanha", idioma: "Alemão" },
  { nome: "Inglaterra", emoji: "🏴", dica: "País do chá e do Big Ben. Funda com Água ou Terra.", universo: "Mundo", tags: ["inglaterra", "cidade"], pais: "Inglaterra", idioma: "Inglês" },
  { nome: "Rússia", emoji: "🇷🇺", dica: "País da matrioska e da balalaica. Funda com Terra ou Vento.", universo: "Mundo", tags: ["russia", "frio"], pais: "Rússia", idioma: "Russo" },
  { nome: "África", emoji: "🌍", dica: "Continente da savana e do leão. Funda com Terra ou Água.", universo: "Mundo", tags: ["africa", "savana"], pais: "África", idioma: "Suaíli" },
  { nome: "Austrália", emoji: "🇦🇺", dica: "País do canguru e do coala. Funda com Terra ou Água.", universo: "Mundo", tags: ["australia", "ilha"], pais: "Austrália", idioma: "Inglês" },
  { nome: "Canadá", emoji: "🇨🇦", dica: "País do alce e do xarope de bordo. Funda com Água ou Terra.", universo: "Mundo", tags: ["canada", "frio"], pais: "Canadá", idioma: "Inglês" },
  { nome: "Brasil", emoji: "🇧🇷", dica: "Idioma Base: Português do Brasil. Funda com Praia ou Turismo.", universo: "Mundo", tags: ["brasil", "praia"], pais: "Brasil", idioma: "Português" },
  { nome: "Portugal", emoji: "🇵🇹", dica: "País do fado e do bacalhau. Funda com Água ou Terra.", universo: "Mundo", tags: ["portugal", "mar"], pais: "Portugal", idioma: "Português" },
  { nome: "Turquia", emoji: "🇹🇷", dica: "País do bazar e do kebab. Funda com Terra ou Água.", universo: "Mundo", tags: ["turquia", "cidade"], pais: "Turquia", idioma: "Turco" },
  { nome: "Tailândia", emoji: "🇹🇭", dica: "País dos templos e do pad thai. Funda com Terra ou Água.", universo: "Mundo", tags: ["tailandia", "praia"], pais: "Tailândia", idioma: "Tailandês" },
  { nome: "Peru", emoji: "🇵🇪", dica: "País de Machu Picchu. Funda com Terra ou Montanha.", universo: "Mundo", tags: ["peru", "montanha"], pais: "Peru", idioma: "Espanhol" },
  { nome: "Argentina", emoji: "🇦🇷", dica: "País do tango. Funda com Vento ou Terra.", universo: "Mundo", tags: ["argentina", "campo"], pais: "Argentina", idioma: "Espanhol" },
  { nome: "Chile", emoji: "🇨🇱", dica: "País da cordilheira. Funda com Terra ou Montanha.", universo: "Mundo", tags: ["chile", "montanha"], pais: "Chile", idioma: "Espanhol" },
  { nome: "Colômbia", emoji: "🇨🇴", dica: "País do café e das flores. Funda com Flor ou Terra.", universo: "Mundo", tags: ["colombia", "flor"], pais: "Colômbia", idioma: "Espanhol" },
  { nome: "Nigéria", emoji: "🇳🇬", dica: "País do afrobeats. Funda com Vento ou Terra.", universo: "Mundo", tags: ["nigeria", "musica"], pais: "Nigéria", idioma: "Inglês" },
  { nome: "Quênia", emoji: "🇰🇪", dica: "País do safári. Funda com Terra ou Vento.", universo: "Mundo", tags: ["quenia", "savana"], pais: "Quênia", idioma: "Suaíli" },
  { nome: "Marrocos", emoji: "🇲🇦", dica: "País do deserto e do cuscuz. Funda com Terra ou Vento.", universo: "Mundo", tags: ["marrocos", "deserto"], pais: "Marrocos", idioma: "Árabe" },
  { nome: "Holanda", emoji: "🇳🇱", dica: "País das tulipas e dos moinhos. Funda com Flor ou Vento.", universo: "Mundo", tags: ["holanda", "flor"], pais: "Holanda", idioma: "Holandês" },
  { nome: "Suíça", emoji: "🇨🇭", dica: "País do chocolate e dos Alpes. Funda com Terra ou Fogo.", universo: "Mundo", tags: ["suica", "montanha"], pais: "Suíça", idioma: "Alemão" },
];
const PAISES_FILTRO = ["Todos os Países", "Brasil", "Japão", "México", "França", "Itália", "Espanha", "China", "Coreia", "Índia", "Egito", "Grécia", "EUA", "Alemanha", "Inglaterra", "Rússia", "África", "Austrália", "Canadá", "Portugal", "Turquia", "Tailândia", "Peru", "Argentina", "Chile", "Colômbia", "Nigéria", "Quênia", "Marrocos", "Holanda", "Suíça"];
function paisDoElemento(e: Elemento): string | undefined {
  if (e.pais) return e.pais;
  const semente = PAISES_SEMENTES.find((s) => s.nome === e.nome);
  if (semente?.pais) return semente.pais;
  if ((e.tags || []).includes("brasil")) return "Brasil";
  return undefined;
}
// --- PORTUGUÊS DO BRASIL: 300+ palavras/expressões reais ---
const DICIONARIO_PT_BR_LISTA: TuplaDicionario[] = [
  ["Oceano", "🌊", ["agua", "mar"], "Grande extensão de água salgada.", "Português"],
  ["Mar", "🌊", ["agua", "mar"], "Massa de água salgada que cobre parte da Terra.", "Português"],
  ["Lago", "🏞️", ["agua", "terra"], "Água parada cercada por terra.", "Português"],
  ["Lagoa", "🏞️", ["agua", "terra"], "Lago pequeno, muitas vezes perto do mar.", "Português"],
  ["Chuva", "🌧️", ["agua", "vento"], "Água que cai das nuvens.", "Português"],
  ["Nevoeiro", "🌫️", ["agua", "vento", "frio"], "Névoa densa que atrapalha a visão.", "Português"],
  ["Névoa", "🌫️", ["agua", "vento"], "Vapor leve que paira no ar.", "Português"],
  ["Orvalho", "💧", ["agua", "frio", "planta"], "Gotinhas de água que se formam de manhã.", "Português"],
  ["Cachoeira", "🌊", ["agua", "pedra", "cachoeira"], "Queda de água de um rio.", "Português"],
  ["Rio", "🌊", ["agua", "terra"], "Curso de água que corre para o mar.", "Português"],
  ["Riacho", "💧", ["agua", "terra"], "Rio pequeno e raso.", "Português"],
  ["Fonte", "💧", ["agua", "terra"], "Lugar onde a água brota do chão.", "Português"],
  ["Nascente", "💧", ["agua", "terra"], "Onde um rio começa.", "Português"],
  ["Praia", "🏖️", ["agua", "mar", "sol"], "Faixa de areia à beira do mar.", "Português"],
  ["Duna", "🏜️", ["areia", "vento", "terra"], "Monte de areia formado pelo vento.", "Português"],
  ["Montanha", "⛰️", ["terra", "pedra"], "Elevação grande do terreno.", "Português"],
  ["Serra", "⛰️", ["terra", "pedra"], "Conjunto de montanhas.", "Português"],
  ["Planalto", "🏔️", ["terra", "pedra"], "Terreno alto e plano.", "Português"],
  ["Vale", "🏞️", ["terra", "rio"], "Terra baixa entre montanhas.", "Português"],
  ["Gruta", "🕳️", ["terra", "pedra"], "Caverna pequena.", "Português"],
  ["Caverna", "🕳️", ["terra", "pedra"], "Buraco grande dentro da terra ou da pedra.", "Português"],
  ["Vulcão", "🌋", ["fogo", "terra", "pedra"], "Montanha que solta lava.", "Português"],
  ["Ilha", "🏝️", ["agua", "mar", "terra"], "Terra cercada de água por todos os lados.", "Português"],
  ["Baía", "🌊", ["agua", "mar"], "Entrada do mar na terra.", "Português"],
  ["Enseada", "🌊", ["agua", "mar"], "Baía pequena e calma.", "Português"],
  ["Delta", "🌊", ["agua", "terra", "rio"], "Onde o rio se abre em braços antes do mar.", "Português"],
  ["Mangue", "🌿", ["agua", "planta", "mar"], "Vegetação de beira-mar com raízes na lama.", "Português"],
  ["Pântano", "🐊", ["agua", "terra", "lama"], "Terreno alagado e lamacento.", "Português"],
  ["Brejo", "🐸", ["agua", "terra", "lama"], "Lugar úmido e lamacento.", "Português"],
  ["Lama", "🟤", ["agua", "terra"], "Terra molhada e mole.", "Português"],
  ["Argila", "🏺", ["agua", "terra"], "Barro fino usado em cerâmica.", "Português"],
  ["Barro", "🏺", ["agua", "terra"], "Terra molhada usada para modelar.", "Português"],
  ["Areia", "🏜️", ["terra", "pedra"], "Grãos finos de pedra.", "Português"],
  ["Pedra", "🪨", ["terra", "pedra"], "Pedaço duro de rocha.", "Português"],
  ["Rocha", "🪨", ["terra", "pedra"], "Massa dura de pedra.", "Português"],
  ["Seixo", "🪨", ["agua", "pedra"], "Pedrinha lisa de rio.", "Português"],
  ["Cristal", "💎", ["pedra", "brilho"], "Pedra transparente e brilhante.", "Português"],
  ["Diamante", "💎", ["pedra", "brilho"], "Pedra preciosa muito dura e brilhante.", "Português"],
  ["Rubi", "💎", ["pedra", "brilho", "fogo"], "Pedra preciosa vermelha.", "Português"],
  ["Opala", "💎", ["pedra", "brilho"], "Pedra que reflete várias cores.", "Português"],
  ["Geodo", "💎", ["pedra", "terra"], "Pedra oca cheia de cristais por dentro.", "Português"],
  ["Fóssil", "🦴", ["pedra", "terra", "tesouro"], "Resto de ser vivo antigo preservado na pedra.", "Português"],
  ["Gelo", "❄️", ["agua", "gelo", "frio"], "Água congelada.", "Português"],
  ["Neve", "❄️", ["agua", "gelo", "frio"], "Flocos de água congelada que caem do céu.", "Português"],
  ["Geada", "❄️", ["agua", "gelo", "frio"], "Camada fina de gelo sobre plantas e chão.", "Português"],
  ["Granizo", "🧊", ["agua", "gelo", "frio"], "Pedrinhas de gelo que caem com chuva forte.", "Português"],
  ["Vapor", "♨️", ["agua", "fogo"], "Água em forma de gás.", "Português"],
  ["Fumaça", "💨", ["fogo", "vento"], "Nuvem cinza que sai do fogo.", "Português"],
  ["Brisa", "🌬️", ["vento", "mar"], "Vento leve e fresco.", "Português"],
  ["Vendaval", "🌬️", ["vento", "chuva"], "Vento muito forte com chuva.", "Português"],
  ["Furacão", "🌪️", ["vento", "agua"], "Tempestade gigante que gira.", "Português"],
  ["Tornado", "🌪️", ["vento", "nuvem"], "Vento que gira em funil.", "Português"],
  ["Tufão", "🌀", ["vento", "agua", "tempestade"], "Furacão que acontece no mar.", "Português"],
  ["Tempestade", "⛈️", ["vento", "agua", "eletrico"], "Chuva forte com vento, raio e trovão.", "Português"],
  ["Relâmpago", "⚡", ["eletrico", "raio", "fogo"], "Clarão no céu antes do trovão.", "Português"],
  ["Raio", "⚡", ["eletrico", "raio"], "Descarga elétrica entre nuvem e terra.", "Português"],
  ["Trovão", "⚡", ["eletrico", "raio", "vento"], "Barulho forte depois do raio.", "Português"],
  ["Faísca", "✨", ["fogo", "vento"], "Pontinho de fogo que salta.", "Português"],
  ["Brasa", "🔥", ["fogo"], "Carvão aceso sem chama.", "Português"],
  ["Fogueira", "🔥", ["fogo"], "Fogo aceso ao ar livre.", "Português"],
  ["Incêndio", "🔥", ["fogo"], "Fogo grande e descontrolado.", "Português"],
  ["Chama", "🔥", ["fogo"], "Parte luminosa do fogo.", "Português"],
  ["Cinza", "🌋", ["fogo", "terra"], "Pó que sobra depois do fogo.", "Português"],
  ["Nuvem", "☁️", ["agua", "vento"], "Vapor condensado no céu.", "Português"],
  ["Céu", "☁️", ["vento", "nuvem"], "Espaço azul acima da Terra.", "Português"],
  ["Horizonte", "🌄", ["terra", "nuvem"], "Linha onde o céu parece encontrar a terra.", "Português"],
  ["Arco-íris", "🌈", ["agua", "luz"], "Arco colorido que aparece com sol e chuva.", "Português"],
  ["Aurora", "🌌", ["luz", "ceu"], "Luz colorida que aparece no céu frio.", "Português"],
  ["Estrela", "⭐", ["luz", "ceu"], "Astro que brilha no céu à noite.", "Português"],
  ["Lua", "🌙", ["luz", "ceu"], "Satélite natural da Terra.", "Português"],
  ["Sol", "☀️", ["luz", "fogo"], "Estrela que ilumina e esquenta a Terra.", "Português"],
  ["Flor", "🌸", ["planta", "flor"], "Parte colorida da planta.", "Português"],
  ["Planta", "🌱", ["planta", "terra"], "Ser vivo que cresce no solo.", "Português"],
  ["Jardim", "🌷", ["flor", "planta"], "Lugar com plantas e flores.", "Português"],
  ["Horta", "🥕", ["planta", "terra", "comida"], "Lugar onde se plantam verduras.", "Português"],
  ["Floresta", "🌳", ["planta", "terra", "chuva"], "Mata grande com muitas árvores.", "Português"],
  ["Mata", "🌳", ["planta", "terra"], "Floresta, conjunto de árvores.", "Português"],
  ["Campo", "🌾", ["terra", "planta"], "Terreno aberto com capim.", "Português"],
  ["Capim", "🌾", ["planta", "terra"], "Erva do campo.", "Português"],
  ["Folha", "🍃", ["planta", "vento"], "Parte verde da planta.", "Português"],
  ["Raiz", "🌱", ["planta", "terra"], "Parte da planta que fica dentro da terra.", "Português"],
  ["Semente", "🌱", ["planta", "terra"], "Grão que vira planta nova.", "Português"],
  ["Fruta", "🍎", ["planta", "comida"], "Fruto comestível.", "Português"],
  ["Vitória Régia", "🌸", ["agua", "planta", "flor"], "Planta aquática gigante da Amazônia.", "Português"],
  ["Vitória-Régia", "🌸", ["agua", "planta", "flor"], "Planta aquática gigante da Amazônia.", "Português"],
  ["Alga", "🌿", ["agua", "planta"], "Planta que vive na água.", "Português"],
  ["Samambaia", "🌿", ["planta", "agua"], "Planta de folhas rendadas.", "Português"],
  ["Cacto", "🌵", ["planta", "terra", "sol"], "Planta com espinhos que vive no seco.", "Português"],
  ["Girassol", "🌻", ["flor", "planta", "sol"], "Flor que vira para o sol.", "Português"],
  ["Rosa", "🌹", ["flor", "planta"], "Flor cheirosa com espinhos.", "Português"],
  ["Margarida", "🌼", ["flor", "planta"], "Flor branca e amarela do campo.", "Português"],
  ["Lótus", "🪷", ["flor", "agua", "lama"], "Flor que nasce na lagoa.", "Português"],
  ["Hibisco", "🌺", ["flor", "fogo", "lava"], "Flor grande e colorida de clima quente.", "Português"],
  ["Pólen", "🌼", ["flor", "vento"], "Pó fino da flor que voa com o vento.", "Português"],
  ["Cachorro", "🐶", ["cachorro", "animal"], "Animal doméstico, melhor amigo da gente.", "Português"],
  ["Gato", "🐱", ["gato", "animal"], "Animal doméstico que mia e ronrona.", "Português"],
  ["Cavalo", "🐴", ["cavalo", "animal"], "Animal grande usado para montar.", "Português"],
  ["Onça", "🐆", ["animal", "terra"], "Felino grande do Brasil.", "Português"],
  ["Capivara", "🦫", ["animal", "agua"], "Maior roedor do mundo, adora água.", "Português"],
  ["Arara", "🦜", ["animal", "voador", "flor"], "Ave colorida do Brasil.", "Português"],
  ["Tucano", "🦜", ["animal", "voador"], "Ave de bico grande e colorido.", "Português"],
  ["Papagaio", "🦜", ["animal", "voador"], "Ave que repete sons.", "Português"],
  ["Coruja", "🦉", ["animal", "voador"], "Ave noturna de olhos grandes.", "Português"],
  ["Morcego", "🦇", ["animal", "voador"], "Mamífero que voa à noite.", "Português"],
  ["Sapo", "🐸", ["animal", "agua"], "Anfíbio que vive perto da água.", "Português"],
  ["Jacaré", "🐊", ["animal", "agua"], "Réptil de água doce do Brasil.", "Português"],
  ["Tartaruga", "🐢", ["animal", "agua", "terra"], "Réptil de casco duro.", "Português"],
  ["Borboleta", "🦋", ["animal", "voador", "flor"], "Inseto de asas coloridas.", "Português"],
  ["Abelha", "🐝", ["animal", "voador", "flor"], "Inseto que faz mel.", "Português"],
  ["Formiga", "🐜", ["animal", "terra"], "Inseto pequeno que vive em colônia.", "Português"],
  ["Vaga-lume", "✨", ["animal", "luz", "voador"], "Inseto que brilha à noite.", "Português"],
  ["Peixe", "🐟", ["animal", "agua"], "Animal que vive na água.", "Português"],
  ["Baleia", "🐳", ["animal", "agua", "mar"], "Maior mamífero do mar.", "Português"],
  ["Golfinho", "🐬", ["animal", "agua", "mar"], "Mamífero marinho muito esperto.", "Português"],
  ["Polvo", "🐙", ["animal", "agua", "mar"], "Animal marinho de oito braços.", "Português"],
  ["Caranguejo", "🦀", ["animal", "agua", "mar"], "Animal de casca dura que anda de lado.", "Português"],
  ["Churrasco", "🔥", ["fogo", "comida"], "Carne assada na brasa.", "Português"],
  ["Feijoada", "🍲", ["comida", "fogo"], "Prato brasileiro de feijão com carnes.", "Português"],
  ["Brigadeiro", "🍫", ["doce", "comida"], "Doce de chocolate enrolado.", "Português"],
  ["Pão de Queijo", "🧀", ["comida", "queijo"], "Bolinho mineiro de polvilho e queijo.", "Português"],
  ["Café Coado", "☕", ["comida", "agua", "fogo"], "Café passado no coador.", "Português"],
  ["Tapioca", "🥞", ["comida"], "Crepe de goma de mandioca.", "Português"],
  ["Açaí", "🍇", ["fruta", "comida"], "Fruta da Amazônia servida gelada.", "Português"],
  ["Moqueca", "🍲", ["comida", "agua", "fogo"], "Ensopado de peixe com dendê.", "Português"],
  ["Pipoca", "🍿", ["comida", "fogo"], "Milho estourado no fogo.", "Português"],
  ["Pizza", "🍕", ["comida", "fogo"], "Massa assada com molho e queijo.", "Português"],
  ["Pão", "🍞", ["comida", "fogo"], "Alimento de farinha assada.", "Português"],
  ["Bolo", "🍰", ["doce", "comida"], "Massa doce assada.", "Português"],
  ["Sorvete", "🍦", ["doce", "comida", "frio"], "Doce gelado de fruta ou leite.", "Português"],
  ["Suco", "🧃", ["fruta", "agua", "comida"], "Bebida feita da fruta.", "Português"],
  ["Caldo", "🍲", ["comida", "agua", "fogo"], "Sopa rala e quente.", "Português"],
  ["Sopa", "🍲", ["comida", "agua", "fogo"], "Comida de legumes cozidos na água.", "Português"],
  ["Espada", "🗡️", ["espada", "metal"], "Arma de lâmina comprida.", "Português"],
  ["Escudo", "🛡️", ["espada", "metal"], "Peça para se defender.", "Português"],
  ["Lanterna", "🔦", ["luz"], "Objeto que ilumina.", "Português"],
  ["Bússola", "🧭", ["metal", "viagem"], "Instrumento que aponta o norte.", "Português"],
  ["Âncora", "⚓", ["metal", "mar", "agua"], "Peça que segura o barco no fundo.", "Português"],
  ["Corda", "🪢", ["objeto"], "Fio grosso para amarrar.", "Português"],
  ["Rede", "🛏️", ["objeto", "vento"], "Tecido de malha para deitar ou pescar.", "Português"],
  ["Mapa", "🗺️", ["viagem", "tesouro"], "Desenho que mostra lugares.", "Português"],
  ["Tesouro", "👑", ["tesouro", "ouro"], "Riqueza guardada e valiosa.", "Português"],
  ["Coroa", "👑", ["tesouro", "ouro"], "Enfeite de rei e rainha.", "Português"],
  ["Joia", "💎", ["tesouro", "brilho"], "Pedra ou metal precioso lapidado.", "Português"],
  ["Moeda", "🪙", ["tesouro", "ouro"], "Dinheiro de metal.", "Português"],
  ["Ouro", "🪙", ["tesouro", "ouro"], "Metal amarelo e precioso.", "Português"],
  ["Prata", "🪙", ["tesouro", "metal"], "Metal branco e brilhante.", "Português"],
  ["Coleira", "💎", ["cachorro", "animal"], "Faixa que vai no pescoço do cachorro.", "Português"],
  ["Brilhante", "✨", ["brilho", "luz"], "Que brilha muito.", "Português"],
  ["Coleira Brilhante", "💎", ["cachorro", "brilho"], "Coleira que brilha.", "Português"],
  ["Carinho", "❤️", ["amizade", "cachorro"], "Ato de fazer bem a alguém.", "Português"],
  ["Amizade", "💛", ["amizade"], "Afeição entre amigos.", "Português"],
  ["Saudade", "💜", ["amizade", "sentimento"], "Falta que a gente sente de alguém.", "Português"],
  ["Coragem", "🦁", ["forca", "sentimento"], "Força para enfrentar o medo.", "Português"],
  ["Alegria", "😄", ["sentimento"], "Sensação de felicidade.", "Português"],
  ["Tristeza", "😢", ["sentimento"], "Sensação de dor e falta de ânimo.", "Português"],
  ["Esperança", "🌈", ["sentimento", "luz"], "Vontade de que algo bom aconteça.", "Português"],
  ["Liberdade", "🕊️", ["vento", "sentimento"], "Poder ir e vir sem prisão.", "Português"],
  ["Paz", "🕊️", ["sentimento"], "Calma, sem briga nem guerra.", "Português"],
  ["Amor", "❤️", ["sentimento", "amizade"], "Sentimento forte de afeição.", "Português"],
  ["Festa", "🎉", ["festa", "musica"], "Reunião alegre para comemorar.", "Português"],
  ["Carnaval", "🎭", ["festa", "brasil"], "Festa popular brasileira de rua.", "Português"],
  ["Samba", "🎶", ["musica", "festa", "brasil"], "Ritmo musical brasileiro.", "Português"],
  ["Forró", "🎶", ["musica", "festa", "brasil"], "Ritmo e dança do Nordeste.", "Português"],
  ["Capoeira", "🥋", ["lutador", "musica", "brasil"], "Luta brasileira com música e ginga.", "Português"],
  ["Pata Molhada", "🐾", ["cachorro", "agua"], "Expressão: pata molhada de chuva ou de banho.", "Português"],
  ["Banho de Cachorro", "🐶", ["cachorro", "agua"], "Expressão: banho dado no cachorro.", "Português"],
  ["Passeio no Parque", "🌳", ["cachorro", "animal", "vento"], "Expressão: passeio ao ar livre com o cachorro.", "Português"],
  ["Soneca", "💤", ["cachorro", "animal"], "Cochilo curto e gostoso.", "Português"],
  ["Cochilo", "💤", ["animal", "sono"], "Soninho rápido.", "Português"],
  ["Cachorro Quente", "🌭", ["cachorro", "fogo", "comida"], "Lanche de salsicha no pão.", "Português"],
  ["Pé de Vento", "💨", ["vento"], "Expressão: pessoa ou coisa muito rápida.", "Português"],
  ["Mão na Massa", "🤲", ["comida", "terra"], "Expressão: começar a trabalhar de verdade.", "Português"],
  ["Chuva de Bênçãos", "🌧️", ["chuva", "sentimento"], "Expressão: muitas coisas boas de uma vez.", "Português"],
  ["Mar de Rosas", "🌹", ["mar", "flor"], "Expressão: fase fácil e feliz.", "Português"],
  ["Céu de Brigadeiro", "🍫", ["ceu", "doce"], "Expressão: céu limpo e bonito.", "Português"],
  ["Casa", "🏠", ["terra", "casa"], "Lugar onde a gente mora.", "Português"],
  ["Cabana", "🛖", ["terra", "casa"], "Casa pequena de madeira.", "Português"],
  ["Castelo", "🏰", ["pedra", "casa"], "Casa grande e forte de reis.", "Português"],
  ["Ponte", "🌉", ["terra", "agua", "rio"], "Construção para atravessar rio ou vale.", "Português"],
  ["Estrada", "🛣️", ["terra", "viagem"], "Caminho para viajar.", "Português"],
  ["Trilha", "🥾", ["terra", "viagem"], "Caminho estreito no mato.", "Português"],
  ["Vila", "🏘️", ["cidade", "casa"], "Povoado pequeno.", "Português"],
  ["Cidade", "🏙️", ["cidade"], "Lugar grande com muitas casas e ruas.", "Português"],
  ["Praça", "⛲", ["cidade", "planta"], "Espaço aberto com bancos e árvores.", "Português"],
  ["Feira", "🧺", ["cidade", "comida"], "Lugar onde se vende fruta e comida.", "Português"],
  ["Mercado", "🏪", ["cidade", "comida"], "Lugar onde se compra comida.", "Português"],
  ["Escola", "🏫", ["cidade", "ideia"], "Lugar onde se aprende.", "Português"],
  ["Biblioteca", "📚", ["cidade", "ideia"], "Lugar cheio de livros.", "Português"],
  ["Livro", "📖", ["ideia"], "Conjunto de páginas com história.", "Português"],
  ["História", "📖", ["ideia"], "Narração do que aconteceu.", "Português"],
  ["Poesia", "🌸", ["ideia", "flor"], "Texto bonito feito com palavras.", "Português"],
  ["Canção", "🎵", ["musica", "chuva"], "Música cantada.", "Português"],
  ["Dança", "💃", ["musica", "festa"], "Movimento do corpo no ritmo.", "Português"],
  ["Pipa", "🪁", ["vento"], "Brinquedo que voa com o vento.", "Português"],
  ["Balão", "🎈", ["vento", "voador"], "Bexiga cheia de ar que sobe.", "Português"],
  ["Parapente", "🪂", ["vento", "voador"], "Asa que voa com o vento.", "Português"],
  ["Barco", "⛵", ["agua", "mar", "vento"], "Veículo que navega na água.", "Português"],
  ["Canoa", "🛶", ["agua", "rio"], "Barco pequeno de madeira.", "Português"],
  ["Navio", "🚢", ["agua", "mar"], "Barco muito grande.", "Português"],
  ["Farol", "🗼", ["luz", "mar"], "Torre com luz para guiar barcos.", "Português"],
  ["Porto", "⚓", ["agua", "mar", "cidade"], "Lugar onde os barcos param.", "Português"],
  ["Onda", "🌊", ["agua", "mar"], "Movimento da água do mar.", "Português"],
  ["Maré", "🌊", ["agua", "mar"], "Subida e descida da água do mar.", "Português"],
  ["Espuma", "🫧", ["agua", "mar"], "Bolhas brancas na água.", "Português"],
  ["Concha", "🐚", ["agua", "mar"], "Casca dura de animal do mar.", "Português"],
  ["Pérola", "🦪", ["agua", "tesouro"], "Bolinha brilhante que nasce na ostra.", "Português"],
  ["Coral", "🪸", ["agua", "mar", "planta"], "Animal marinho que forma recifes.", "Português"],
  ["Recife", "🪸", ["agua", "mar", "pedra"], "Pedra ou coral perto da superfície do mar.", "Português"],
  ["Sal", "🧂", ["agua", "mar", "comida"], "Tempero que vem do mar.", "Português"],
  ["Sol Poente", "🌇", ["sol", "luz"], "Sol se pondo no fim do dia.", "Português"],
  ["Amanhecer", "🌅", ["sol", "luz"], "Começo do dia, quando o sol nasce.", "Português"],
  ["Entardecer", "🌇", ["sol", "luz"], "Fim da tarde.", "Português"],
  ["Meia-noite", "🌙", ["luz", "ceu"], "Meio da noite.", "Português"],
  ["Primavera", "🌸", ["flor", "planta", "sol"], "Estação das flores.", "Português"],
  ["Verão", "☀️", ["sol", "mar"], "Estação mais quente do ano.", "Português"],
  ["Outono", "🍂", ["folha", "planta", "vento"], "Estação em que as folhas caem.", "Português"],
  ["Inverno", "❄️", ["frio", "gelo"], "Estação mais fria do ano.", "Português"],
  ["Estação", "🍂", ["sol", "frio"], "Cada uma das quatro partes do ano.", "Português"],
  ["Sombra", "🌑", ["sombra", "sol"], "Lugar escuro sem sol direto.", "Português"],
  ["Luz", "💡", ["luz"], "Claridade que deixa ver.", "Português"],
  ["Escuridão", "🌑", ["sombra", "luz"], "Falta de luz.", "Português"],
  ["Espelho", "🪞", ["luz", "brilho"], "Superfície que reflete a imagem.", "Português"],
  ["Prisma", "🔮", ["luz", "cristal"], "Objeto que separa a luz em cores.", "Português"],
  ["Laser", "🔦", ["luz", "fogo"], "Feixe de luz muito forte.", "Português"],
  ["Fogo de Chão", "🔥", ["fogo", "terra"], "Fogueira feita no chão.", "Português"],
  ["Churrasqueira", "🔥", ["fogo", "comida"], "Lugar de assar churrasco.", "Português"],
  ["Panela", "🍲", ["fogo", "comida"], "Vasilha para cozinhar.", "Português"],
  ["Forno", "🔥", ["fogo", "comida"], "Lugar fechado para assar.", "Português"],
  ["Vela", "🕯️", ["fogo", "luz"], "Cilindro de cera que dá luz.", "Português"],
  ["Lamparina", "🪔", ["fogo", "luz"], "Luz pequena a óleo.", "Português"],
  ["Tocha", "🔥", ["fogo", "luz"], "Pau com fogo na ponta.", "Português"],
  ["Martelo", "🔨", ["metal", "pedra"], "Ferramenta para bater.", "Português"],
  ["Machado", "🪓", ["metal", "terra"], "Ferramenta para cortar madeira.", "Português"],
  ["Pá", "⛏️", ["metal", "terra"], "Ferramenta para cavar.", "Português"],
  ["Enxada", "⛏️", ["metal", "terra"], "Ferramenta para capinar.", "Português"],
  ["Sino", "🔔", ["metal", "musica"], "Peça de metal que toca.", "Português"],
  ["Tambor", "🥁", ["musica", "festa"], "Instrumento de percussão.", "Português"],
  ["Violão", "🎸", ["musica"], "Instrumento de cordas.", "Português"],
  ["Flauta", "🪈", ["musica", "vento"], "Instrumento de sopro.", "Português"],
  ["Apito", "📯", ["musica", "vento"], "Instrumento que apita.", "Português"],
  ["Peneira", "🪣", ["agua", "terra"], "Utensílio para separar grãos.", "Português"],
  ["Cesto", "🧺", ["planta", "comida"], "Recipiente trançado.", "Português"],
  ["Corda de Pular", "🪢", ["objeto", "vento"], "Corda para brincar de pular.", "Português"],
  ["Bola", "🔴", ["bola", "objeto"], "Objeto redondo para brincar.", "Português"],
  ["Piâo", "🪀", ["objeto"], "Brinquedo que gira.", "Português"],
  ["Boneca", "🪆", ["objeto"], "Brinquedo em forma de gente.", "Português"],
  ["Carrinho", "🚗", ["objeto", "cidade"], "Brinquedo ou carro pequeno.", "Português"],
  ["Trem", "🚂", ["cidade", "viagem"], "Veículo que anda nos trilhos.", "Português"],
  ["Avião", "✈️", ["voador", "viagem"], "Veículo que voa.", "Português"],
  ["Helicóptero", "🚁", ["voador", "viagem"], "Aeronave de hélices.", "Português"],
  ["Bicicleta", "🚲", ["cidade", "viagem"], "Veículo de duas rodas.", "Português"],
  ["Carroça", "🐴", ["cavalo", "terra"], "Carro puxado por animal.", "Português"],
  ["Chuva Forte", "🌧️", ["chuva", "vento"], "Chuva muito forte.", "Português"],
  ["Banho de Chuva", "🌧️", ["chuva", "agua"], "Banho tomado na chuva.", "Português"],
  ["Banho de Sol", "☀️", ["sol", "mar"], "Ficar ao sol para se aquecer.", "Português"],
  ["Banho de Mar", "🌊", ["mar", "agua"], "Banho no mar.", "Português"],
  ["Pé na Areia", "🏖️", ["praia", "areia"], "Expressão: andar descalço na praia.", "Português"],
  ["Cheiro de Chuva", "🌧️", ["chuva", "terra"], "Cheiro da terra molhada.", "Português"],
  ["Terra Molhada", "🌍", ["terra", "chuva"], "Terra úmida depois da chuva.", "Português"],
  ["Céu de Algodão", "☁️", ["nuvem", "vapor"], "Céu cheio de nuvens fofas.", "Português"],
  ["Flor de Lótus", "🪷", ["flor", "agua", "lama"], "Flor que nasce na lagoa.", "Português"],
  ["Jardim de Pedras", "🪨", ["pedra", "flor"], "Jardim feito com pedras.", "Português"],
  ["Pedra Preciosa", "💎", ["pedra", "tesouro"], "Pedra rara e valiosa.", "Português"],
  ["Poeira de Ouro", "✨", ["poeira", "tesouro"], "Pó dourado e brilhante.", "Português"],
  ["Pó Mágico", "✨", ["poeira", "magia"], "Pó que parece ter magia.", "Português"],
  ["Super Invenção", "💡", ["criador", "ideia"], "Invenção muito grande e nova.", "Português"],
  ["Grande Ideia", "💡", ["ideia"], "Ideia muito boa.", "Português"],
  ["Invenção", "💡", ["criador", "ideia"], "Coisa nova criada por alguém.", "Português"],
  ["Experimento", "🧪", ["criador", "magia"], "Teste feito para descobrir algo.", "Português"],
  ["Laboratório", "🧪", ["criador"], "Lugar de experimentos.", "Português"],
  ["Ideia", "💡", ["ideia"], "Pensamento novo.", "Português"],
  ["Imaginação", "☁️", ["ideia", "nuvem"], "Capacidade de imaginar.", "Português"],
  ["Criatividade", "🎨", ["ideia"], "Capacidade de criar.", "Português"],
  ["Aventura", "🗺️", ["viagem", "tesouro"], "Jornada cheia de novidades.", "Português"],
  ["Descoberta", "🔍", ["ideia", "viagem"], "Ato de achar algo novo.", "Português"],
  ["Segredo", "🤫", ["ideia"], "Coisa que não se conta.", "Português"],
  ["Mistério", "🔍", ["ideia", "sombra"], "Coisa difícil de entender.", "Português"],
  ["Lenda", "📖", ["ideia", "historia"], "História contada há muito tempo.", "Português"],
  ["Mito", "📖", ["ideia", "historia"], "História antiga com deuses e heróis.", "Português"],
  ["Herói", "🦸", ["lutador", "ideia"], "Pessoa corajosa que salva os outros.", "Português"],
  ["Vilão", "🦹", ["lutador", "sombra"], "Personagem mau da história.", "Português"],
  ["Mago", "🧙", ["magia"], "Pessoa que faz magia.", "Português"],
  ["Feitiço", "✨", ["magia"], "Palavra ou ato de magia.", "Português"],
  ["Poção", "🧪", ["magia", "agua"], "Bebida mágica.", "Português"],
  ["Magia", "🪄", ["magia"], "Poder de fazer o impossível.", "Português"],
  ["Encanto", "✨", ["magia", "flor"], "Beleza ou magia que atrai.", "Português"],
  ["Cristo Redentor", "🇧🇷", ["turismo", "monumento", "brasil", "rio"], "Estátua no Rio de Janeiro.", "Português"],
  ["Lençóis Maranhenses", "🏜️", ["turismo", "brasil", "areia", "agua"], "Dunas com lagoas no Maranhão.", "Português"],
  ["Cataratas do Iguaçu", "🌊", ["turismo", "brasil", "agua", "cachoeira"], "Quedas d’água na fronteira do Brasil.", "Português"],
  ["Bahia", "🎶", ["brasil", "praia", "festa"], "Estado brasileiro de sol, mar e festa.", "Português"],
  ["Amazônia", "🌳", ["brasil", "floresta", "rio"], "Maior floresta tropical do mundo.", "Português"],
  ["Pantanal", "🐊", ["brasil", "agua", "animal"], "Maior planície alagada do mundo.", "Português"],
  ["Cerrado", "🌾", ["brasil", "terra", "planta"], "Vegetação do centro do Brasil.", "Português"],
  ["Caatinga", "🌵", ["brasil", "terra", "sol"], "Vegetação seca do Nordeste.", "Português"],
  ["Sertão", "☀️", ["brasil", "sol", "terra"], "Interior seco do Nordeste.", "Português"],
  ["Mata Atlântica", "🌿", ["brasil", "floresta", "planta"], "Floresta da costa brasileira.", "Português"],
  ["Ouro Preto", "⛪", ["turismo", "brasil", "historia", "ouro"], "Cidade histórica de Minas Gerais.", "Português"],
  ["Gramado", "🌸", ["turismo", "brasil", "frio", "flor"], "Cidade serrana do Sul.", "Português"],
  ["Fernando de Noronha", "🏝️", ["turismo", "brasil", "praia", "mar", "ilha"], "Arquipélago paradisíaco do Brasil.", "Português"],
  ["Chapada Diamantina", "⛰️", ["turismo", "brasil", "montanha", "cachoeira"], "Chapada da Bahia com cachoeiras.", "Português"],
  ["Jericoacoara", "🏖️", ["turismo", "brasil", "praia", "vento", "mar"], "Praia de dunas no Ceará.", "Português"],
  ["Bonito", "🐠", ["turismo", "brasil", "agua", "rio"], "Cidade de rios cristalinos.", "Português"],
];
const DICIONARIO_PT_BR = dicionario(DICIONARIO_PT_BR_LISTA, "Vida Real");
// --- DICIONÁRIOS DO MUNDO: palavras reais de outros idiomas ---
const DICIONARIO_MUNDO_LISTA: TuplaDicionario[] = [
  ["Tsunami", "🌊", ["agua", "mar", "terra"], "Onda gigante do mar.", "Japonês"],
  ["Sakura", "🌸", ["flor", "planta", "vento"], "Flor de cerejeira do Japão.", "Japonês"],
  ["Samurai", "⚔️", ["espada", "lutador"], "Guerreiro do Japão antigo.", "Japonês"],
  ["Katana", "🗡️", ["espada", "metal"], "Espada japonesa.", "Japonês"],
  ["Sushi", "🍣", ["comida", "agua"], "Prato japonês com arroz e peixe.", "Japonês"],
  ["Origami", "🦢", ["papel", "ideia"], "Arte japonesa de dobrar papel.", "Japonês"],
  ["Karaokê", "🎤", ["musica", "festa"], "Cantar com música gravada.", "Japonês"],
  ["Ninja", "🥷", ["lutador", "sombra"], "Guerreiro ágil do Japão.", "Japonês"],
  ["Sensei", "🧑‍🏫", ["ideia", "cidade"], "Mestre, professor.", "Japonês"],
  ["Zen", "🧘", ["sentimento", "paz"], "Calma e atenção plena.", "Japonês"],
  ["Ocean", "🌊", ["agua", "mar"], "Oceano, em inglês.", "Inglês"],
  ["Lake", "🏞️", ["agua", "terra"], "Lago, em inglês.", "Inglês"],
  ["Thunder", "⚡", ["eletrico", "raio"], "Trovão, em inglês.", "Inglês"],
  ["Rainbow", "🌈", ["agua", "luz"], "Arco-íris, em inglês.", "Inglês"],
  ["Sunshine", "☀️", ["sol", "luz"], "Luz do sol, em inglês.", "Inglês"],
  ["Snowflake", "❄️", ["agua", "gelo", "frio"], "Floco de neve, em inglês.", "Inglês"],
  ["Fireworks", "🎆", ["fogo", "flor"], "Fogos de artifício, em inglês.", "Inglês"],
  ["Butterfly", "🦋", ["animal", "voador", "flor"], "Borboleta, em inglês.", "Inglês"],
  ["Waterfall", "🌊", ["agua", "pedra", "cachoeira"], "Cachoeira, em inglês.", "Inglês"],
  ["Moonlight", "🌙", ["luz", "ceu"], "Luz da lua, em inglês.", "Inglês"],
  ["Fiesta", "🎉", ["festa", "musica"], "Festa, em espanhol.", "Espanhol"],
  ["Siesta", "💤", ["sono", "animal"], "Cochilo depois do almoço, em espanhol.", "Espanhol"],
  ["Playa", "🏖️", ["agua", "mar", "sol"], "Praia, em espanhol.", "Espanhol"],
  ["Sombrero", "👒", ["sol", "objeto"], "Chapéu largo, em espanhol.", "Espanhol"],
  ["Tornado", "🌪️", ["vento", "nuvem"], "Tornado, em espanhol e inglês.", "Espanhol"],
  ["Chocolate", "🍫", ["doce", "comida"], "Chocolate, em espanhol.", "Espanhol"],
  ["Tomate", "🍅", ["comida", "planta"], "Tomate, em espanhol.", "Espanhol"],
  ["Château", "🏰", ["pedra", "casa"], "Castelo, em francês.", "Francês"],
  ["Croissant", "🥐", ["comida", "fogo"], "Pão folhado, em francês.", "Francês"],
  ["Baguette", "🥖", ["comida", "fogo"], "Pão comprido, em francês.", "Francês"],
  ["Ballet", "🩰", ["musica", "festa"], "Dança clássica, em francês.", "Francês"],
  ["Déjà vu", "🔍", ["ideia", "memoria"], "Sensação de já ter vivido algo, em francês.", "Francês"],
  ["Parapluie", "🌂", ["chuva", "agua"], "Guarda-chuva, em francês.", "Francês"],
  ["Pizza", "🍕", ["comida", "fogo"], "Pizza, em italiano.", "Italiano"],
  ["Pasta", "🍝", ["comida", "fogo"], "Macarrão, em italiano.", "Italiano"],
  ["Gelato", "🍦", ["doce", "comida", "frio"], "Sorvete italiano.", "Italiano"],
  ["Bravo", "👏", ["festa", "sentimento"], "Muito bem, em italiano.", "Italiano"],
  ["Vulcano", "🌋", ["fogo", "terra", "pedra"], "Vulcão, em italiano.", "Italiano"],
  ["Blitz", "⚡", ["eletrico", "raio"], "Relâmpago, em alemão.", "Alemão"],
  ["Wunderkind", "💡", ["ideia", "criador"], "Criança prodígio, em alemão.", "Alemão"],
  ["Kindergarten", "🏫", ["cidade", "ideia"], "Jardim de infância, em alemão.", "Alemão"],
  ["Poltergeist", "👻", ["sombra", "magia"], "Fantasma barulhento, em alemão.", "Alemão"],
  ["Samba", "🎶", ["musica", "festa", "brasil"], "Ritmo brasileiro, também em outros idiomas.", "Português"],
  ["Capoeira", "🥋", ["lutador", "musica", "brasil"], "Luta brasileira.", "Português"],
  ["Aloha", "🌺", ["mar", "flor", "amizade"], "Olá e adeus com carinho, em havaiano.", "Havaiano"],
  ["Ohana", "❤️", ["amizade", "familia"], "Família, em havaiano.", "Havaiano"],
  ["Safari", "🦁", ["animal", "terra", "viagem"], "Viagem para ver animais, em suaíli.", "Suaíli"],
  ["Jambo", "👋", ["amizade", "viagem"], "Olá, em suaíli.", "Suaíli"],
  ["Karaoke", "🎤", ["musica", "festa"], "Karaokê, em japonês.", "Japonês"],
  ["Taco", "🌮", ["comida", "fogo"], "Comida mexicana.", "Espanhol"],
  ["Piñata", "🪅", ["festa", "doce"], "Boneco de festa cheio de doces.", "Espanhol"],
  ["Salsa", "💃", ["musica", "festa", "comida"], "Dança e molho, em espanhol.", "Espanhol"],
  ["Mango", "🥭", ["fruta", "comida"], "Manga, em inglês.", "Inglês"],
  ["Coconut", "🥥", ["fruta", "agua"], "Coco, em inglês.", "Inglês"],
  ["Volcano", "🌋", ["fogo", "terra", "pedra"], "Vulcão, em inglês.", "Inglês"],
  ["Hurricane", "🌀", ["vento", "agua"], "Furacão, em inglês.", "Inglês"],
  ["Eclipse", "🌑", ["sol", "lua", "luz"], "Eclipse, em inglês e português.", "Inglês"],
  ["Aurora", "🌌", ["luz", "ceu"], "Aurora, em latim e português.", "Latim"],
  ["Terra", "🌍", ["terra"], "Terra, em latim e português.", "Latim"],
  ["Aqua", "💧", ["agua"], "Água, em latim.", "Latim"],
  ["Ignis", "🔥", ["fogo"], "Fogo, em latim.", "Latim"],
  ["Ventus", "💨", ["vento"], "Vento, em latim.", "Latim"],
  ["Luna", "🌙", ["luz", "ceu"], "Lua, em latim e espanhol.", "Latim"],
  ["Sol", "☀️", ["luz", "fogo"], "Sol, em latim e português.", "Latim"],
  ["Flora", "🌸", ["flor", "planta"], "Flora, em latim.", "Latim"],
  ["Fauna", "🐾", ["animal"], "Fauna, em latim.", "Latim"],
  ["Yoga", "🧘", ["sentimento", "paz"], "Prática de corpo e calma, em sânscrito.", "Sânscrito"],
  ["Karma", "🔄", ["sentimento", "ideia"], "Ação e consequência, em sânscrito.", "Sânscrito"],
  ["Guru", "🧑‍🏫", ["ideia"], "Mestre, em sânscrito.", "Sânscrito"],
  ["Chai", "🍵", ["comida", "agua", "fogo"], "Chá com especiarias, em hindi.", "Hindi"],
  ["Bazaar", "🏪", ["cidade", "comida"], "Mercado, em persa.", "Persa"],
  ["Coffee", "☕", ["comida", "agua", "fogo"], "Café, em inglês.", "Inglês"],
  ["Tea", "🍵", ["comida", "agua", "fogo"], "Chá, em inglês.", "Inglês"],
];
const DICIONARIO_MUNDO = dicionario(DICIONARIO_MUNDO_LISTA, "Vida Real").map((e) => ({ ...e, pais: paisDePalavraMundo(e.nome, e.dicionario), idioma: e.dicionario }));
// ===== DICIONÁRIO DO MUNDO — TODOS OS PAÍSES (200+ palavras) =====
// Formato: [nome, emoji, tags, significado em PT-BR, idioma, país].
// A primeira tag é sempre a chave do país (ex.: "japao"), para a fusão
// país + elemento reconhecer a palavra. Nomes estrangeiros mantêm a
// grafia original; a explicação fica em Português do Brasil.
const DICIONARIO_MUNDO_EXTRA: TuplaMundo[] = [
  ["Kimono", "👘", ["japao", "flor", "vento"], "Quimono: roupa tradicional do Japão.", "Japonês", "Japão"],
  ["Monte Fuji", "🗻", ["japao", "montanha", "terra"], "Monte Fuji: vulcão famoso do Japão.", "Japonês", "Japão"],
  ["Templo de Kyoto", "⛩️", ["japao", "pedra", "terra"], "Templo de Kyoto: templo histórico do Japão.", "Japonês", "Japão"],
  ["Ramen", "🍜", ["japao", "comida", "agua"], "Ramen: sopa japonesa de macarrão.", "Japonês", "Japão"],
  ["Matcha", "🍵", ["japao", "planta", "agua"], "Matcha: chá verde em pó do Japão.", "Japonês", "Japão"],
  ["Bonsai", "🌳", ["japao", "planta", "terra"], "Bonsai: árvore pequena cultivada em vaso.", "Japonês", "Japão"],
  ["Koi", "🐟", ["japao", "agua", "animal"], "Koi: carpa colorida do Japão.", "Japonês", "Japão"],
  ["Sumô", "🤼", ["japao", "lutador", "terra"], "Sumô: luta tradicional do Japão.", "Japonês", "Japão"],
  ["Hanami", "🌸", ["japao", "flor", "festa"], "Hanami: festa de ver as cerejeiras floridas.", "Japonês", "Japão"],
  ["Pimenta", "🌶️", ["mexico", "fogo", "comida"], "Pimenta: fruto picante da culinária mexicana.", "Espanhol", "México"],
  ["Horchata", "🥛", ["mexico", "agua", "doce"], "Horchata: bebida doce de arroz do México.", "Espanhol", "México"],
  ["Cacto", "🌵", ["mexico", "terra", "planta"], "Cacto: planta de espinhos que vive no seco.", "Espanhol", "México"],
  ["Sombrero", "👒", ["mexico", "sol", "vento"], "Sombrero: chapéu largo do México.", "Espanhol", "México"],
  ["Chichen Itza", "🛕", ["mexico", "pedra", "terra"], "Chichen Itza: cidade antiga do México.", "Espanhol", "México"],
  ["Pirâmide do Sol", "🔺", ["mexico", "pedra", "sol"], "Pirâmide do Sol: pirâmide antiga do México.", "Espanhol", "México"],
  ["Guacamole", "🥑", ["mexico", "comida", "planta"], "Guacamole: pasta de abacate do México.", "Espanhol", "México"],
  ["Mariachi", "🎺", ["mexico", "musica", "festa"], "Mariachi: grupo musical do México.", "Espanhol", "México"],
  ["Axolote", "🦎", ["mexico", "agua", "animal"], "Axolote: anfíbio do México que vive na água.", "Espanhol", "México"],
  ["Torre Eiffel", "🗼", ["franca", "terra", "metal"], "Torre Eiffel: torre de ferro de Paris.", "Francês", "França"],
  ["Museu do Louvre", "🖼️", ["franca", "cidade", "arte"], "Museu do Louvre: museu famoso de Paris.", "Francês", "França"],
  ["Macaron", "🍪", ["franca", "doce", "comida"], "Macaron: docinho colorido da França.", "Francês", "França"],
  ["Crepe", "🥞", ["franca", "comida", "fogo"], "Crepe: panqueca fina da França.", "Francês", "França"],
  ["Lavanda", "💜", ["franca", "flor", "planta"], "Lavanda: flor roxa e cheirosa da França.", "Francês", "França"],
  ["Moinho", "🌬️", ["franca", "vento", "terra"], "Moinho: construção que gira com o vento.", "Francês", "França"],
  ["Perfume", "🌸", ["franca", "flor", "vento"], "Perfume: cheiro de flor em frasco.", "Francês", "França"],
  ["Queijo Brie", "🧀", ["franca", "comida", "animal"], "Queijo Brie: queijo macio da França.", "Francês", "França"],
  ["Coliseu", "🏛️", ["italia", "pedra", "terra"], "Coliseu: arena antiga de Roma.", "Italiano", "Itália"],
  ["Gôndola", "🛶", ["italia", "agua", "rio"], "Gôndola: barco de Veneza.", "Italiano", "Itália"],
  ["Torre de Pisa", "🗼", ["italia", "pedra", "terra"], "Torre de Pisa: torre inclinada da Itália.", "Italiano", "Itália"],
  ["Tiramisù", "🍰", ["italia", "doce", "comida"], "Tiramisù: doce italiano de café.", "Italiano", "Itália"],
  ["Espresso", "☕", ["italia", "comida", "agua"], "Espresso: café forte da Itália.", "Italiano", "Itália"],
  ["Vespa", "🛵", ["italia", "cidade", "vento"], "Vespa: motinha famosa da Itália.", "Italiano", "Itália"],
  ["Ópera", "🎭", ["italia", "musica", "festa"], "Ópera: peça cantada nascida na Itália.", "Italiano", "Itália"],
  ["Paella", "🥘", ["espanha", "comida", "terra"], "Paella: arroz de panela da Espanha.", "Espanhol", "Espanha"],
  ["Flamenco", "💃", ["espanha", "musica", "festa"], "Flamenco: dança da Espanha.", "Espanhol", "Espanha"],
  ["Touro", "🐂", ["espanha", "animal", "fogo"], "Touro: animal símbolo das festas da Espanha.", "Espanhol", "Espanha"],
  ["Alhambra", "🏰", ["espanha", "pedra", "terra"], "Alhambra: palácio antigo da Espanha.", "Espanhol", "Espanha"],
  ["Sagrada Família", "⛪", ["espanha", "pedra", "cidade"], "Sagrada Família: igreja de Barcelona.", "Espanhol", "Espanha"],
  ["Churros", "🍩", ["espanha", "doce", "comida"], "Churros: doce frito com açúcar.", "Espanhol", "Espanha"],
  ["Muralha da China", "🧱", ["china", "pedra", "terra"], "Muralha da China: muralha gigante da China.", "Mandarim", "China"],
  ["Panda", "🐼", ["china", "animal", "planta"], "Panda: urso que come bambu na China.", "Mandarim", "China"],
  ["Lanterna", "🏮", ["china", "luz", "fogo"], "Lanterna: luz de papel da China.", "Mandarim", "China"],
  ["Dragão Chinês", "🐉", ["china", "fogo", "dragao"], "Dragão Chinês: dragão das festas da China.", "Mandarim", "China"],
  ["Bambu", "🎋", ["china", "planta", "terra"], "Bambu: planta alta que o panda come.", "Mandarim", "China"],
  ["Chá Verde", "🍵", ["china", "planta", "agua"], "Chá Verde: chá de folhas da China.", "Mandarim", "China"],
  ["Cidade Proibida", "🏯", ["china", "pedra", "cidade"], "Cidade Proibida: palácio antigo da China.", "Mandarim", "China"],
  ["Kimchi", "🥬", ["coreia", "comida", "terra"], "Kimchi: conserva apimentada da Coreia.", "Coreano", "Coreia"],
  ["K-Pop", "🎤", ["coreia", "musica", "vento"], "K-Pop: música pop da Coreia.", "Coreano", "Coreia"],
  ["Taekwondo", "🥋", ["coreia", "lutador", "vento"], "Taekwondo: luta da Coreia.", "Coreano", "Coreia"],
  ["Hanbok", "👘", ["coreia", "flor", "vento"], "Hanbok: roupa tradicional da Coreia.", "Coreano", "Coreia"],
  ["Bibimbap", "🍚", ["coreia", "comida", "fogo"], "Bibimbap: arroz misturado da Coreia.", "Coreano", "Coreia"],
  ["Taj Mahal", "🕌", ["india", "pedra", "terra"], "Taj Mahal: palácio de mármore da Índia.", "Hindi", "Índia"],
  ["Curry", "🍛", ["india", "comida", "fogo"], "Curry: molho apimentado da Índia.", "Hindi", "Índia"],
  ["Elefante", "🐘", ["india", "animal", "terra"], "Elefante: animal grande da Índia.", "Hindi", "Índia"],
  ["Sari", "👗", ["india", "flor", "vento"], "Sari: roupa colorida da Índia.", "Hindi", "Índia"],
  ["Holi", "🎨", ["india", "festa", "flor"], "Holi: festa das cores da Índia.", "Hindi", "Índia"],
  ["Tigre", "🐯", ["india", "animal", "terra"], "Tigre: felino listrado da Índia.", "Hindi", "Índia"],
  ["Pirâmide", "🔺", ["egito", "pedra", "terra"], "Pirâmide: tumba dos faraós do Egito.", "Árabe", "Egito"],
  ["Esfinge", "🦁", ["egito", "pedra", "deserto"], "Esfinge: estátua com corpo de leão no Egito.", "Árabe", "Egito"],
  ["Nilo", "🌊", ["egito", "agua", "rio"], "Nilo: rio grande do Egito.", "Árabe", "Egito"],
  ["Faraó", "👑", ["egito", "tesouro", "pedra"], "Faraó: rei do Egito antigo.", "Árabe", "Egito"],
  ["Papiro", "📜", ["egito", "planta", "agua"], "Papiro: papel antigo feito de planta do Egito.", "Árabe", "Egito"],
  ["Zeus", "⚡", ["grecia", "eletrico", "montanha"], "Zeus: deus do trovão da Grécia.", "Grego", "Grécia"],
  ["Olimpo", "⛰️", ["grecia", "montanha", "terra"], "Olimpo: montanha dos deuses da Grécia.", "Grego", "Grécia"],
  ["Acrópole", "🏛️", ["grecia", "pedra", "terra"], "Acrópole: ruína antiga de Atenas.", "Grego", "Grécia"],
  ["Odisseia", "🚢", ["grecia", "mar", "viagem"], "Odisseia: viagem de Odisseu pelo mar.", "Grego", "Grécia"],
  ["Oliveira", "🫒", ["grecia", "planta", "sol"], "Oliveira: árvore da azeitona da Grécia.", "Grego", "Grécia"],
  ["Hambúrguer", "🍔", ["eua", "comida", "fogo"], "Hambúrguer: sanduíche famoso dos EUA.", "Inglês", "EUA"],
  ["Hollywood", "🎬", ["eua", "cidade", "filme"], "Hollywood: bairro dos filmes nos EUA.", "Inglês", "EUA"],
  ["Cowboy", "🤠", ["eua", "animal", "terra"], "Cowboy: vaqueiro dos EUA.", "Inglês", "EUA"],
  ["Estátua da Liberdade", "🗽", ["eua", "pedra", "mar"], "Estátua da Liberdade: estátua de Nova York.", "Inglês", "EUA"],
  ["Grand Canyon", "🏜️", ["eua", "pedra", "deserto"], "Grand Canyon: cânion gigante dos EUA.", "Inglês", "EUA"],
  ["Pipoca", "🍿", ["eua", "comida", "fogo"], "Pipoca: milho estourado do cinema.", "Inglês", "EUA"],
  ["Jazz", "🎷", ["eua", "musica", "festa"], "Jazz: música nascida nos EUA.", "Inglês", "EUA"],
  ["Pretzel", "🥨", ["alemanha", "comida", "fogo"], "Pretzel: pão torcido da Alemanha.", "Alemão", "Alemanha"],
  ["Castelo de Neuschwanstein", "🏰", ["alemanha", "pedra", "castelo"], "Castelo de Neuschwanstein: castelo da Alemanha.", "Alemão", "Alemanha"],
  ["Cuco", "🐦", ["alemanha", "animal", "vento"], "Cuco: pássaro do relógio da Alemanha.", "Alemão", "Alemanha"],
  ["Floresta Negra", "🌲", ["alemanha", "planta", "terra"], "Floresta Negra: floresta da Alemanha.", "Alemão", "Alemanha"],
  ["Chá", "☕", ["inglaterra", "agua", "comida"], "Chá: bebida quente da Inglaterra.", "Inglês", "Inglaterra"],
  ["Big Ben", "🕰️", ["inglaterra", "pedra", "cidade"], "Big Ben: relógio famoso de Londres.", "Inglês", "Inglaterra"],
  ["Guarda Real", "💂", ["inglaterra", "cidade", "lutador"], "Guarda Real: guarda do palácio de Londres.", "Inglês", "Inglaterra"],
  ["Stonehenge", "🗿", ["inglaterra", "pedra", "terra"], "Stonehenge: círculo de pedras da Inglaterra.", "Inglês", "Inglaterra"],
  ["Matrioska", "🪆", ["russia", "objeto", "terra"], "Matrioska: boneca dentro de boneca da Rússia.", "Russo", "Rússia"],
  ["Balalaica", "🎸", ["russia", "musica", "vento"], "Balalaica: instrumento de cordas da Rússia.", "Russo", "Rússia"],
  ["Urso", "🐻", ["russia", "animal", "frio"], "Urso: animal do frio da Rússia.", "Russo", "Rússia"],
  ["Kremlin", "🏰", ["russia", "pedra", "cidade"], "Kremlin: fortaleza de Moscou.", "Russo", "Rússia"],
  ["Savana", "🦁", ["africa", "terra", "sol"], "Savana: campo aberto da África.", "Suaíli", "África"],
  ["Leão", "🦁", ["africa", "animal", "terra"], "Leão: felino da savana da África.", "Suaíli", "África"],
  ["Baobá", "🌳", ["africa", "planta", "terra"], "Baobá: árvore gigante da África.", "Suaíli", "África"],
  ["Tambor", "🥁", ["africa", "musica", "festa"], "Tambor: instrumento de festa da África.", "Suaíli", "África"],
  ["Canguru", "🦘", ["australia", "animal", "terra"], "Canguru: animal que pula na Austrália.", "Inglês", "Austrália"],
  ["Coala", "🐨", ["australia", "animal", "planta"], "Coala: animal que vive em árvore na Austrália.", "Inglês", "Austrália"],
  ["Boomerang", "🪃", ["australia", "vento", "objeto"], "Boomerang: brinquedo que volta na Austrália.", "Inglês", "Austrália"],
  ["Ópera de Sydney", "🎭", ["australia", "cidade", "mar"], "Ópera de Sydney: teatro famoso da Austrália.", "Inglês", "Austrália"],
  ["Xarope de Bordo", "🍁", ["canada", "planta", "doce"], "Xarope de Bordo: xarope doce do Canadá.", "Inglês", "Canadá"],
  ["Alce", "🦌", ["canada", "animal", "frio"], "Alce: animal grande do frio do Canadá.", "Inglês", "Canadá"],
  ["Niagara Falls", "🌊", ["canada", "agua", "cachoeira"], "Niagara Falls: cachoeira do Canadá.", "Inglês", "Canadá"],
  ["Fado", "🎶", ["portugal", "musica", "mar"], "Fado: música saudosa de Portugal.", "Português", "Portugal"],
  ["Bacalhau", "🐟", ["portugal", "agua", "comida"], "Bacalhau: peixe salgado de Portugal.", "Português", "Portugal"],
  ["Torre de Belém", "🗼", ["portugal", "pedra", "mar"], "Torre de Belém: torre à beira do mar em Lisboa.", "Português", "Portugal"],
  ["Kebab", "🥙", ["turquia", "comida", "fogo"], "Kebab: espeto de carne da Turquia.", "Turco", "Turquia"],
  ["Bazar", "🏪", ["turquia", "cidade", "comida"], "Bazar: mercado cheio de cores da Turquia.", "Turco", "Turquia"],
  ["Pad Thai", "🍜", ["tailandia", "comida", "fogo"], "Pad Thai: macarrão frito da Tailândia.", "Tailandês", "Tailândia"],
  ["Templo Dourado", "🛕", ["tailandia", "pedra", "templo"], "Templo Dourado: templo da Tailândia.", "Tailandês", "Tailândia"],
  ["Machu Picchu", "⛰️", ["peru", "montanha", "pedra"], "Machu Picchu: cidade antiga do Peru.", "Espanhol", "Peru"],
  ["Tango", "💃", ["argentina", "musica", "festa"], "Tango: dança da Argentina.", "Espanhol", "Argentina"],
  ["Café", "☕", ["colombia", "planta", "comida"], "Café: bebida de grãos da Colômbia.", "Espanhol", "Colômbia"],
  ["Afrobeats", "🥁", ["nigeria", "musica", "festa"], "Afrobeats: ritmo dançante da Nigéria.", "Inglês", "Nigéria"],
  ["Safári", "🦁", ["quenia", "animal", "viagem"], "Safári: viagem para ver animais no Quênia.", "Suaíli", "Quênia"],
  ["Cuscuz", "🍲", ["marrocos", "comida", "terra"], "Cuscuz: prato de grãos de Marrocos.", "Árabe", "Marrocos"],
  ["Tulipa", "🌷", ["holanda", "flor", "planta"], "Tulipa: flor colorida da Holanda.", "Holandês", "Holanda"],
  ["Moinho de Vento", "🌬️", ["holanda", "vento", "terra"], "Moinho de Vento: moinho que gira com o vento.", "Holandês", "Holanda"],
  ["Chocolate Suíço", "🍫", ["suica", "doce", "comida"], "Chocolate Suíço: chocolate famoso da Suíça.", "Alemão", "Suíça"],
  ["Alpes", "🏔️", ["suica", "montanha", "neve"], "Alpes: montanhas de neve da Suíça.", "Alemão", "Suíça"],
  ["Sushi", "🍣", ["japao", "comida", "agua"], "Sushi: prato japonês com arroz e peixe.", "Japonês", "Japão"],
  ["Kimono", "👘", ["japao", "flor", "vento"], "Quimono: roupa tradicional do Japão.", "Japonês", "Japão"],
];
const WORLD_DICTIONARY = dicionarioMundo(DICIONARIO_MUNDO_EXTRA, "Vida Real");
const DICIONARIO_MUNDO_TODOS: EntradaDicionario[] = (() => { const vistos = new Set<string>(); const todos: EntradaDicionario[] = []; for (const e of [...DICIONARIO_MUNDO, ...WORLD_DICTIONARY]) { const k = e.nome.toLowerCase(); if (!vistos.has(k)) { vistos.add(k); todos.push(e); } } return todos; })();
function dicionarioDe(nome: string): { dicionario: string; significado: string; pais?: string; idioma?: string } | null {
  const n = normalizar(nome);
  const achado = [...DICIONARIO_PT_BR, ...DICIONARIO_MUNDO_TODOS].find((e) => normalizar(e.nome) === n);
  if (!achado) return null;
  return { dicionario: achado.dicionario, significado: achado.significado, pais: achado.pais || (achado.dicionario === "Português" ? "Brasil" : undefined), idioma: achado.idioma || achado.dicionario };
}
const PALAVRAS_DICIONARIO = new Set<string>([...[...DICIONARIO_PT_BR, ...DICIONARIO_MUNDO_TODOS].flatMap((e) => e.nome.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").split(/[^a-z]+/).filter(Boolean)), "super", "mega", "grande", "pequeno", "novo", "do", "san", "brilhante", "coleira", "quente", "molhada"]);
function buscarDicionario(pool: EntradaDicionario[], tagsA: string[], tagsB: string[], excluir: Set<string>): { entrada: EntradaDicionario; compartilhadas: string[] } | null {
  let melhor: { entrada: EntradaDicionario; compartilhadas: string[] } | null = null;
  for (const entrada of pool) {
    if (excluir.has(entrada.nome)) continue;
    const comA = tagsEmComum(entrada.tags, tagsA);
    const comB = tagsEmComum(entrada.tags, tagsB);
    if (!comA.length || !comB.length) continue;
    const compartilhadas = [...new Set([...comA, ...comB])];
    if (compartilhadas.length < 2) continue;
    if (!melhor || compartilhadas.length > melhor.compartilhadas.length) melhor = { entrada, compartilhadas };
  }
  return melhor;
}
function montarResultadoDicionario(entrada: EntradaDicionario, a: Elemento, b: Elemento, compartilhadas: string[]): ResultadoIA {
  return {
    nome: limitarNomeIA(entrada.nome), emoji: entrada.emoji, categoria: entrada.categoria, universo: entrada.dicionario === "Português" ? "Dicionário PT-BR" : `Dicionário do Mundo`,
    tags: entrada.tags, dicionario: entrada.dicionario, significado: entrada.significado, pais: entrada.pais, idioma: entrada.idioma || entrada.dicionario,
    motivo: entrada.pais ? `🌍 País: ${entrada.pais} | Idioma: ${entrada.idioma || entrada.dicionario} | Dicionário: ${entrada.nome} = ${entrada.significado} Combina com ${a.nome} e ${b.nome} pelas tags ${compartilhadas.join(", ")}.` : `Dicionário ${entrada.dicionario}: ${entrada.nome} existe de verdade — ${entrada.significado} Combina com ${a.nome} e ${b.nome} pelas tags ${compartilhadas.join(", ")}.`,
  };
}
// [Elemento A, Elemento B, Nome, Emoji, Categoria, motivo curto]
// A chave é montada com chave(A, B), então a ordem aqui não importa.
const CURATED_ENTRIES: Array<[string, string, string, string, CategoriaIA, string]> = [
  // ===== MESMO ELEMENTO + MESMO ELEMENTO = VERSÃO INTENSIFICADA =====
  // Nunca "X de X". Mesma dupla = sempre o mesmo resultado (determinístico).
  ["Água", "Água", "Oceano", "🌊", "Vida Real", "água com água não é água de água: é tanta água que vira oceano"],
  ["Fogo", "Fogo", "Incêndio", "🔥", "Vida Real", "fogo com fogo não é fogo de fogo: é fogo grande, um incêndio"],
  ["Terra", "Terra", "Montanha", "⛰️", "Vida Real", "terra com terra empilha e vira montanha"],
  ["Vento", "Vento", "Furacão", "🌪️", "Vida Real", "vento com vento gira forte e vira furacão"],
  ["San", "San", "Super San", "🦸", "Vida Real", "San com San não é San de San: é o Super San"],
  ["Meg", "Meg", "Matilha", "🐶", "Vida Real", "Meg com Meg não é Meg de Meg: é uma matilha de cachorrinhas"],
  ["Vapor", "Vapor", "Névoa", "🌫️", "Vida Real", "vapor com vapor espalha e vira névoa"],
  ["Lava", "Lava", "Vulcão", "🌋", "Vida Real", "lava com lava é lava de vulcão em erupção"],
  ["Pedra", "Pedra", "Montanha", "⛰️", "Vida Real", "pedra com pedra empilha e vira montanha"],
  ["Chuva", "Chuva", "Chuva Forte", "🌧️", "Vida Real", "chuva com chuva vira chuva forte"],
  ["Nuvem", "Nuvem", "Céu de Algodão", "☁️", "Vida Real", "nuvem com nuvem cobre o céu de algodão"],
  ["Flor", "Flor", "Jardim", "🌷", "Vida Real", "flor com flor vira jardim"],
  ["Cristal", "Cristal", "Geodo", "💎", "Vida Real", "cristal com cristal vira geodo cheio de pedras"],
  ["Lama", "Lama", "Pântano", "🐊", "Vida Real", "lama com lama vira pântano"],
  ["Poeira", "Poeira", "Deserto", "🏜️", "Vida Real", "poeira com poeira vira deserto"],
  ["Faísca", "Faísca", "Relâmpago", "⚡", "Vida Real", "faísca com faísca vira relâmpago"],
  ["Tempestade", "Tempestade", "Furacão", "🌪️", "Vida Real", "tempestade com tempestade gira em furacão"],
  ["Arco-íris", "Arco-íris", "Duplo Arco-Íris", "🌈", "Vida Real", "arco-íris com arco-íris forma duplo arco-íris"],
  ["Magia", "Magia", "Super Magia", "🪄", "Filme", "magia com magia vira super magia"],
  ["Tesouro", "Tesouro", "Fortuna", "👑", "Vida Real", "tesouro com tesouro vira fortuna"],
  ["Ideia", "Ideia", "Grande Ideia", "💡", "Vida Real", "ideia com ideia vira grande ideia"],
  ["Amizade", "Amizade", "Super Amizade", "💛", "Vida Real", "amizade com amizade vira super amizade"],
  ["Pata", "Pata", "Pegada", "🐾", "Vida Real", "pata com pata deixa pegada marcada"],
  ["Banho", "Banho", "Piscina", "🏊", "Vida Real", "banho com banho vira piscina"],
  ["Água", "Fogo", "Vapor", "♨️", "Vida Real", "na chaleira vira o vapor do chá"],
  ["Água", "Terra", "Lama", "🟤", "Vida Real", "vira aquela meleca boa de brincar depois da chuva"],
  ["Água", "Vento", "Chuva", "🌧️", "Vida Real", "o vento leva a água e ela volta em chuva"],
  ["Água", "San", "Poção", "🧪", "Filme", "lembra a poção de Hogwarts que o San testaria no laboratório"],
  ["Água", "Meg", "Banho de Cachorro", "🐶", "Vida Real", "é a hora do banho da Meg, com espuma e tudo"],
  ["Fogo", "Terra", "Lava", "🌋", "Vida Real", "terra derretida pelo fogo vira lava de vulcão"],
  ["Fogo", "Vento", "Faísca", "✨", "Vida Real", "o vento espalha o fogo em faíscas"],
  ["Fogo", "San", "Ideia", "💡", "Vida Real", "perto do fogo o San sempre tem uma ideia brilhante"],
  ["Fogo", "Meg", "Cachorro Quente", "🌭", "Vida Real", "fogo + cachorro é cachorro quente de verdade, não Vaporeon (que é de água)"],
  ["Terra", "Vento", "Poeira", "🌪️", "Vida Real", "terra leve voando com o vento vira poeira"],
  ["Terra", "San", "Casa", "🏠", "Vida Real", "com terra, tijolo e ideia do San nasce uma casa"],
  ["Terra", "Meg", "Pata", "🐾", "Vida Real", "a Meg deixa uma patinha marcada na terra"],
  ["Vento", "San", "Liberdade", "🕊️", "Vida Real", "vento solto com o San tem cara de liberdade"],
  ["Vento", "Meg", "Passeio no Parque", "🌳", "Vida Real", "vento fresco é o convite perfeito para passear com a Meg"],
  ["San", "Meg", "Amizade", "💛", "Vida Real", "San + Meg é amizade verdadeira, igual Carinho"],
  ["Terra", "Vapor", "Nuvem", "☁️", "Vida Real", "vapor encontra terra e sobe em nuvem"],
  ["Lava", "Água", "Pedra", "🪨", "Vida Real", "lava esfria na água e vira pedra"],
  ["Chuva", "Terra", "Flor", "🌸", "Vida Real", "chuva na terra faz a flor nascer"],
  ["Faísca", "Vento", "Tempestade", "⛈️", "Vida Real", "faísca com vento vira tempestade"],
  ["Fogo", "Nuvem", "Arco-íris", "🌈", "Vida Real", "sol na nuvem pinta o céu de arco-íris"],
  ["Fogo", "Pedra", "Cristal", "💎", "Vida Real", "pedra no fogo vira cristal"],
  ["Arco-íris", "San", "Magia", "🪄", "Filme", "o San tocando o arco-íris faz magia como em Hogwarts"],
  ["Cristal", "Magia", "Tesouro", "👑", "Filme", "cristal + magia guardam um tesouro de filme de aventura"],
  ["Água", "Flor", "Planta", "🌱", "Vida Real", "flor com água vira planta crescendo no vaso"],
  ["Água", "Pedra", "Rio", "🌊", "Vida Real", "água contornando pedra forma um rio"],
  ["Água", "Cristal", "Gelo Brilhante", "💎", "Vida Real", "cristal/diamante + água vira gelo brilhante — não tem tag elétrica, então nunca é Jolteon"],
  ["Água", "Planta", "Vitória Régia", "🌸", "Vida Real", "água + planta é planta aquática de verdade, como a vitória-régia da Amazônia — não é Gyarados, que é água/dragão e não tem planta"],
  ["Água", "Diamante", "Gelo Brilhante", "💎", "Vida Real", "diamante + água vira gelo brilhante — sem tag elétrica, sem Jolteon"],
  ["Pokébola", "Chidori", "Pikachu", "⚡", "Anime", "pokébola + Chidori (elétrico) solta o Pikachu, o Pokémon elétrico — o tipo elétrico bate forte"],
  ["Água", "Magia", "Percy Jackson", "🌊", "Mitologia", "água com magia lembra Percy Jackson e o mar"],
  ["Água", "Tesouro", "Pérola", "🦪", "Vida Real", "tesouro no fundo da água vira pérola na ostra"],
  ["Água", "Nuvem", "Neve", "❄️", "Vida Real", "água na nuvem fria cai em neve"],
  ["Água", "Tempestade", "Furacão", "🌀", "Vida Real", "água com tempestade gira em furacão"],
  ["Água", "Arco-íris", "Cachoeira", "🌈", "Vida Real", "água caindo com sol forma cachoeira com arco-íris"],
  ["Água", "Vapor", "Mundo Invertido", "🌀", "Série", "neblina de vapor lembra o Mundo Invertido de Stranger Things"],
  ["Água", "Lama", "Argila", "🏺", "Vida Real", "água com lama vira argila de olaria"],
  ["Água", "Lava", "Obsidiana", "🪨", "Vida Real", "lava encontrando água vira obsidiana, pedra vulcânica de verdade"],
  ["Fogo", "Flor", "Fênix", "🔥", "Mitologia", "flor que renasce no fogo lembra a Fênix"],
  ["Fogo", "Pedra", "Tijolo", "🧱", "Vida Real", "pedra e barro no fogo viram tijolo de construção"],
  ["Fogo", "Cristal", "Rubi", "💎", "Vida Real", "cristal no fogo lembra o rubi, pedra vermelha de verdade"],
  ["Fogo", "Magia", "Dragão de Game of Thrones", "🐉", "Série", "fogo com magia lembra o dragão de Game of Thrones"],
  ["Fogo", "Tesouro", "Ouro", "🪙", "Vida Real", "tesouro no fogo brilha como ouro derretido"],
  ["Fogo", "Tempestade", "Vulcão", "🌋", "Vida Real", "tempestade de fogo lembra a erupção de um vulcão"],
  ["Fogo", "Vapor", "Sauna", "🧖", "Vida Real", "fogo com vapor vira sauna quentinha"],
  ["Fogo", "Lama", "Cerâmica", "🏺", "Vida Real", "lama no fogo vira cerâmica de panela e vaso"],
  ["Fogo", "Lava", "Magma", "🌋", "Vida Real", "fogo com lava é magma dentro do vulcão"],
  ["Fogo", "Chuva", "Chá", "🍵", "Vida Real", "chuva fervida no fogo vira chá quentinho"],
  ["Vento", "Flor", "Pólen", "🌸", "Vida Real", "vento leva o pólen da flor pelo jardim"],
  ["Vento", "Pedra", "Suna", "🏜️", "Anime", "vento com pedra vira areia, como a Suna de Gaara em Naruto"],
  ["Vento", "Cristal", "Prisma", "🔮", "Vida Real", "vento com cristal lembra o prisma que separa a luz"],
  ["Vento", "Magia", "Rasengan", "🌪️", "Anime", "vento com magia gira como o Rasengan do Naruto"],
  ["Vento", "Tesouro", "Mapa do Tesouro", "🗺️", "Filme", "vento com tesouro lembra o mapa de Piratas do Caribe"],
  ["Vento", "Nuvem", "Tornado", "🌪️", "Vida Real", "vento com nuvem gira em tornado"],
  ["Vento", "Tempestade", "Tufão", "🌀", "Vida Real", "vento forte com tempestade vira tufão no mar"],
  ["Vento", "Arco-íris", "Pipa", "🪁", "Vida Real", "vento com arco-íris é dia perfeito de soltar pipa"],
  ["Vento", "Vapor", "Brisa", "🌬️", "Vida Real", "vento com vapor leve vira brisa fresca"],
  ["Vento", "Lama", "Tempestade de Areia", "🏜️", "Vida Real", "vento com lama seca vira tempestade de areia"],
  ["Vento", "Lava", "Cinza Vulcânica", "🌋", "Vida Real", "vento leva a cinza da lava para longe do vulcão"],
  ["Vento", "Chuva", "Vendaval", "🌬️", "Vida Real", "vento com chuva forte vira vendaval"],
  ["Terra", "Flor", "Mokuton", "🌳", "Anime", "terra com flor lembra o Mokuton, o estilo madeira de Naruto"],
  ["Terra", "Pedra", "Montanha", "⛰️", "Vida Real", "terra com pedra empilhada vira montanha"],
  ["Terra", "Cristal", "Geodo", "💎", "Vida Real", "terra com cristal esconde um geodo cheio de pedras"],
  ["Terra", "Magia", "Golem", "🗿", "Mitologia", "terra com magia lembra o Golem de pedra da mitologia"],
  ["Terra", "Tesouro", "Mina de Ouro", "⛏️", "Vida Real", "tesouro enterrado na terra vira mina de ouro"],
  ["Terra", "Nuvem", "Horizonte", "🌄", "Vida Real", "terra longe com nuvem forma o horizonte do campo"],
  ["Terra", "Tempestade", "Terremoto", "🌍", "Vida Real", "terra tremendo com tempestade lembra terremoto"],
  ["Terra", "Arco-íris", "Campo de Girassóis", "🌻", "Vida Real", "terra com arco-íris vira campo de girassóis"],
  ["Terra", "Vapor", "Estufa", "🌱", "Vida Real", "terra com vapor quentinho vira estufa de plantas"],
  ["Terra", "Lama", "Pântano", "🐊", "Vida Real", "terra com lama vira pântano"],
  ["Terra", "Lava", "Jurassic Park", "🦖", "Filme", "terra com lava lembra a ilha vulcânica de Jurassic Park"],
  ["Terra", "Chuva", "Floresta", "🌳", "Vida Real", "terra com chuva vira floresta verdinha"],
  ["San", "Flor", "Buquê", "💐", "Vida Real", "San com flor monta um buquê"],
  ["San", "Pedra", "Escultura", "🗿", "Vida Real", "San com pedra esculpe uma escultura"],
  ["San", "Cristal", "Joia", "💎", "Vida Real", "San com cristal lapida uma joia"],
  ["San", "Magia", "Feitiço", "✨", "Filme", "San com magia lança um feitiço como em Harry Potter"],
  ["San", "Tesouro", "Aventura", "🗺️", "Filme", "San com tesouro vive uma aventura como Indiana Jones"],
  ["San", "Nuvem", "Sonho", "☁️", "Vida Real", "San com nuvem fica sonhando de barriga para cima"],
  ["San", "Tempestade", "Zoro", "⚔️", "Anime", "San com tempestade lembra Zoro, o espadachim de One Piece"],
  ["San", "Arco-íris", "Esperança", "🌈", "Vida Real", "San com arco-íris tem cara de esperança"],
  ["San", "Vapor", "Chá Quente", "🍵", "Vida Real", "San com vapor prepara um chá quentinho"],
  ["San", "Lama", "Arte com Argila", "🎨", "Vida Real", "San com lama faz arte com argila"],
  ["San", "Lava", "Luffy Gear 5", "🔥", "Anime", "San com lava lembra Luffy Gear 5 em One Piece, cheio de energia"],
  ["San", "Chuva", "Guarda-Chuva", "🌂", "Vida Real", "San com chuva abre o guarda-chuva"],
  ["Meg", "Flor", "Cachorro no Jardim", "🐶", "Vida Real", "Meg com flor é cachorro feliz no jardim"],
  ["Meg", "Pedra", "Chopper", "🦌", "Anime", "Meg com pedra lembra Chopper, a rena médica de One Piece"],
  ["Meg", "Cristal", "Coleira Brilhante", "💎", "Vida Real", "Meg com cristal ganha uma coleira brilhante"],
  ["Meg", "Magia", "Patrono", "🦌", "Filme", "Meg com magia lembra o Patrono de Harry Potter"],
  ["Meg", "Tesouro", "Caça ao Tesouro", "🐾", "Filme", "Meg com tesouro sai em caça ao tesouro farejando tudo"],
  ["Meg", "Nuvem", "Soneca", "💤", "Vida Real", "Meg com nuvem tira uma soneca fofinha"],
  ["Meg", "Tempestade", "Medo de Trovão", "⚡", "Vida Real", "Meg com tempestade fica com medo de trovão, como muito cachorro"],
  ["Meg", "Arco-íris", "Ponte do Arco-Íris", "🌈", "Mitologia", "Meg com arco-íris lembra a Ponte do Arco-Íris dos pets"],
  ["Meg", "Vapor", "Banho Quente", "🛁", "Vida Real", "Meg com vapor ganha um banho quentinho"],
  ["Meg", "Lama", "Banho de Lama", "🐶", "Vida Real", "Meg com lama volta do quintal precisando de banho de lama"],
  ["Meg", "Lava", "Lareira", "🐶", "Vida Real", "Meg com lava deita perto da lareira para se aquecer"],
  ["Meg", "Chuva", "Pata Molhada", "🐾", "Vida Real", "Meg com chuva volta com a pata molhada"],
  ["Vapor", "Flor", "Perfume", "🌸", "Vida Real", "vapor com flor vira perfume de flor"],
  ["Vapor", "Pedra", "Pedra-Pomes", "🪨", "Vida Real", "vapor com pedra vulcânica vira pedra-pomes"],
  ["Vapor", "Cristal", "Diamante", "💎", "Vida Real", "vapor com cristal lembra o diamante lapidado"],
  ["Vapor", "Magia", "Portal", "🌀", "Filme", "vapor com magia abre um portal como em Doutor Estranho"],
  ["Vapor", "Tesouro", "Baú Mágico", "🎁", "Filme", "vapor com tesouro lembra o baú mágico de filme de aventura"],
  ["Vapor", "Nuvem", "Céu", "☁️", "Vida Real", "vapor com nuvem forma o céu de algodão"],
  ["Vapor", "Tempestade", "Raio", "⚡", "Vida Real", "vapor com tempestade solta um raio"],
  ["Vapor", "Arco-íris", "Aurora Boreal", "🌌", "Vida Real", "vapor com arco-íris lembra a aurora boreal no céu"],
  ["Vapor", "Lama", "Argila Cozida", "🏺", "Vida Real", "vapor com lama vira argila cozida de vaso"],
  ["Vapor", "Lava", "Gêiser", "🌋", "Vida Real", "vapor com lava jorra como um gêiser"],
  ["Vapor", "Chuva", "Orvalho", "💧", "Vida Real", "vapor com chuva vira orvalho na grama"],
  ["Lama", "Flor", "Vitória-Régia", "🌸", "Vida Real", "lama com flor vira vitória-régia na lagoa"],
  ["Lama", "Pedra", "Tijolo de Barro", "🧱", "Vida Real", "lama com pedra vira tijolo de barro"],
  ["Lama", "Cristal", "Âmbar", "🟠", "Vida Real", "lama com cristal lembra o âmbar, resina dourada de verdade"],
  ["Lama", "Magia", "Homem de Barro", "🗿", "Mitologia", "lama com magia lembra o homem de barro da mitologia"],
  ["Lama", "Tesouro", "Fóssil", "🦴", "Vida Real", "lama com tesouro esconde um fóssil de dinossauro"],
  ["Lama", "Nuvem", "Tempestade de Poeira", "🌪️", "Vida Real", "lama seca com nuvem vira tempestade de poeira"],
  ["Lama", "Tempestade", "Enchente", "🌊", "Vida Real", "lama com tempestade vira enchente"],
  ["Lama", "Arco-íris", "Pintura com Barro", "🎨", "Vida Real", "lama com arco-íris vira pintura com barro colorido"],
  ["Lama", "Lava", "Rocha Vulcânica", "🪨", "Vida Real", "lama com lava esfria em rocha vulcânica"],
  ["Lama", "Chuva", "Pântano", "🐊", "Vida Real", "lama com chuva vira pântano"],
  ["Lava", "Flor", "Hibisco", "🌺", "Vida Real", "lava com flor lembra o hibisco do Havaí, terra de vulcão"],
  ["Lava", "Pedra", "Granito", "🪨", "Vida Real", "lava com pedra vira granito de cozinha"],
  ["Lava", "Cristal", "Pedra do Infinito", "💎", "Filme", "lava com cristal brilha como a Pedra do Infinito dos Vingadores"],
  ["Lava", "Magia", "Balrog", "🔥", "Filme", "lava com magia lembra o Balrog de O Senhor dos Anéis"],
  ["Lava", "Tesouro", "Diamante Vulcânico", "💎", "Vida Real", "lava com tesouro esconde diamante vulcânico"],
  ["Lava", "Nuvem", "Nuvem de Cinzas", "🌋", "Vida Real", "lava com nuvem vira nuvem de cinzas do vulcão"],
  ["Lava", "Tempestade", "Erupção", "🌋", "Vida Real", "lava com tempestade vira erupção"],
  ["Lava", "Arco-íris", "Lava Lamp", "🪔", "Vida Real", "lava com arco-íris lembra a lava lamp colorida"],
  ["Lava", "Chuva", "Ilha", "🏝️", "Vida Real", "lava com chuva esfria e forma uma ilha"],
  ["Chuva", "Flor", "Jardim de Chuva", "🌧️", "Vida Real", "chuva com flor rega um jardim de chuva"],
  ["Chuva", "Pedra", "Seixo", "🪨", "Vida Real", "chuva com pedra deixa o seixo lisinho do rio"],
  ["Chuva", "Cristal", "Prisma de Chuva", "🌈", "Vida Real", "chuva com cristal forma prisma de chuva com arco-íris"],
  ["Chuva", "Magia", "Tempestade Mágica", "🌩️", "Filme", "chuva com magia vira tempestade mágica de filme"],
  ["Chuva", "Tesouro", "Ouro no Fim do Arco-Íris", "🌈", "Mitologia", "chuva com tesouro lembra o ouro no fim do arco-íris"],
  ["Chuva", "Nuvem", "Monção", "🌧️", "Vida Real", "chuva com nuvem vira monção, chuva forte da estação"],
  ["Chuva", "Tempestade", "Tempestade Elétrica", "⛈️", "Vida Real", "chuva com tempestade vira tempestade elétrica"],
  ["Chuva", "Arco-íris", "Duplo Arco-Íris", "🌈", "Vida Real", "chuva com arco-íris forma duplo arco-íris no céu"],
  ["Faísca", "Flor", "Fogos de Artifício", "🎆", "Vida Real", "faísca com flor explode em fogos de artifício"],
  ["Faísca", "Pedra", "Pederneira", "🪨", "Vida Real", "faísca com pedra é pederneira, que acende fogo de verdade"],
  ["Faísca", "Cristal", "Laser", "🔦", "Vida Real", "faísca com cristal vira laser"],
  ["Faísca", "Magia", "Feitiço de Fogo", "🔥", "Filme", "faísca com magia vira feitiço de fogo de Harry Potter"],
  ["Faísca", "Tesouro", "Moeda de Ouro", "🪙", "Vida Real", "faísca com tesouro brilha como moeda de ouro"],
  ["Faísca", "Nuvem", "Raio", "⚡", "Vida Real", "faísca com nuvem solta um raio"],
  ["Faísca", "Tempestade", "Relâmpago", "⚡", "Vida Real", "faísca com tempestade vira relâmpago"],
  ["Faísca", "Arco-íris", "Faísca Mágica", "✨", "Filme", "faísca com arco-íris vira faísca mágica de filme"],
  ["Faísca", "Vapor", "Fumaça", "💨", "Vida Real", "faísca com vapor vira fumaça"],
  ["Faísca", "Lama", "Tijolo Queimado", "🧱", "Vida Real", "faísca com lama queima o tijolo no forno"],
  ["Faísca", "Lava", "Erupção de Faíscas", "✨", "Vida Real", "faísca com lava salta em erupção de faíscas"],
  ["Faísca", "Chuva", "Arco Voltaico", "⚡", "Vida Real", "faísca com chuva lembra o arco voltaico da eletricidade"],
  ["Poeira", "Flor", "Pólen Dourado", "🌼", "Vida Real", "poeira com flor vira pólen dourado"],
  ["Poeira", "Pedra", "Deserto", "🏜️", "Vida Real", "poeira com pedra vira deserto"],
  ["Poeira", "Cristal", "Areia de Cristal", "💎", "Vida Real", "poeira com cristal vira areia de cristal"],
  ["Poeira", "Magia", "Pó Mágico", "✨", "Filme", "poeira com magia vira pó mágico como em Peter Pan"],
  ["Poeira", "Tesouro", "Poeira de Ouro", "✨", "Vida Real", "poeira com tesouro brilha como poeira de ouro"],
  ["Poeira", "Nuvem", "Névoa de Poeira", "🌫️", "Vida Real", "poeira com nuvem vira névoa de poeira"],
  ["Poeira", "Tempestade", "Tempestade de Areia", "🏜️", "Vida Real", "poeira com tempestade vira tempestade de areia"],
  ["Poeira", "Arco-íris", "Poeira de Fada", "🧚", "Filme", "poeira com arco-íris vira poeira de fada"],
  ["Poeira", "Vapor", "Fumaça de Poeira", "💨", "Vida Real", "poeira com vapor vira fumaça de poeira"],
  ["Poeira", "Lama", "Barro Seco", "🏜️", "Vida Real", "poeira com lama seca vira barro seco"],
  ["Poeira", "Lava", "Cinza", "🌋", "Vida Real", "poeira com lava vira cinza do vulcão"],
  ["Poeira", "Chuva", "Terra Molhada", "🌍", "Vida Real", "poeira com chuva vira terra molhada com cheiro de chuva"],
  ["Poção", "Flor", "Elixir da Vida", "🧪", "Mitologia", "poção com flor lembra o elixir da vida da mitologia"],
  ["Poção", "Pedra", "Pedra Filosofal", "🪨", "Filme", "poção com pedra vira a Pedra Filosofal de Harry Potter"],
  ["Poção", "Cristal", "Poção de Invisibilidade", "🫥", "Filme", "poção com cristal vira poção de invisibilidade"],
  ["Poção", "Magia", "Feitiço", "🪄", "Filme", "poção com magia vira feitiço"],
  ["Poção", "Tesouro", "Poção de Sorte", "🍀", "Filme", "poção com tesouro vira poção de sorte"],
  ["Poção", "Nuvem", "Poção de Voo", "🧹", "Filme", "poção com nuvem vira poção de voo"],
  ["Poção", "Tempestade", "Poção de Trovão", "⚡", "Filme", "poção com tempestade vira poção de trovão"],
  ["Poção", "Arco-íris", "Poção do Arco-Íris", "🌈", "Filme", "poção com arco-íris vira poção do arco-íris"],
  ["Poção", "Vapor", "Poção Fumegante", "♨️", "Filme", "poção com vapor vira poção fumegante"],
  ["Poção", "Lama", "Poção de Barro", "🧪", "Filme", "poção com lama vira poção de barro"],
  ["Poção", "Lava", "Poção de Fogo", "🔥", "Filme", "poção com lava vira poção de fogo"],
  ["Poção", "Chuva", "Poção de Chuva", "🌧️", "Filme", "poção com chuva vira poção de chuva"],
  ["Ideia", "Flor", "Poesia", "🌸", "Vida Real", "ideia com flor vira poesia"],
  ["Ideia", "Pedra", "Arquitetura", "🏛️", "Vida Real", "ideia com pedra vira arquitetura"],
  ["Ideia", "Cristal", "Invenção", "💡", "Vida Real", "ideia com cristal brilha como invenção"],
  ["Ideia", "Magia", "Livro de Magia", "📖", "Filme", "ideia com magia vira livro de magia"],
  ["Ideia", "Tesouro", "Plano de Aventura", "🗺️", "Filme", "ideia com tesouro vira plano de aventura"],
  ["Ideia", "Nuvem", "Imaginação", "☁️", "Vida Real", "ideia com nuvem vira imaginação"],
  ["Ideia", "Tempestade", "Revolução", "⚡", "Vida Real", "ideia com tempestade vira revolução"],
  ["Ideia", "Arco-íris", "Criatividade", "🎨", "Vida Real", "ideia com arco-íris vira criatividade"],
  ["Ideia", "Vapor", "Ideia Quente", "💡", "Vida Real", "ideia com vapor é ideia quentinha, na hora"],
  ["Ideia", "Lama", "Escultura de Barro", "🏺", "Vida Real", "ideia com lama vira escultura de barro"],
  ["Ideia", "Lava", "Energia Geotérmica", "🌋", "Vida Real", "ideia com lava vira energia geotérmica, energia do vulcão"],
  ["Ideia", "Chuva", "Canção da Chuva", "🎵", "Vida Real", "ideia com chuva vira canção da chuva"],
  ["Banho", "Flor", "Banho de Flores", "🌸", "Vida Real", "banho com flor vira banho de flores"],
  ["Banho", "Pedra", "Ofurô", "🛁", "Vida Real", "banho com pedra vira ofurô, banheira japonesa"],
  ["Banho", "Cristal", "Banheira de Hidromassagem", "🛁", "Vida Real", "banho com cristal vira banheira de hidromassagem"],
  ["Banho", "Magia", "Banho Mágico", "🪄", "Filme", "banho com magia vira banho mágico"],
  ["Banho", "Tesouro", "Banho de Ouro", "🪙", "Vida Real", "banho com tesouro vira banho de ouro"],
  ["Banho", "Nuvem", "Banho de Nuvem", "☁️", "Vida Real", "banho com nuvem é banho de nuvem, levinho"],
  ["Banho", "Tempestade", "Banho de Chuva", "🌧️", "Vida Real", "banho com tempestade vira banho de chuva"],
  ["Banho", "Arco-íris", "Banho Colorido", "🌈", "Vida Real", "banho com arco-íris vira banho colorido"],
  ["Banho", "Vapor", "Sauna", "🧖", "Vida Real", "banho com vapor vira sauna"],
  ["Banho", "Lama", "Banho de Lama Terapêutico", "🧖", "Vida Real", "banho com lama vira banho de lama terapêutico"],
  ["Banho", "Lava", "Banho Termal", "♨️", "Vida Real", "banho com lava vira banho termal de água quente"],
  ["Banho", "Chuva", "Banho de Chuva", "🌧️", "Vida Real", "banho com chuva é banho de chuva no quintal"],
  ["Pata", "Flor", "Rastro Florido", "🐾", "Vida Real", "pata com flor deixa rastro florido no jardim"],
  ["Pata", "Pedra", "Pegada", "🐾", "Vida Real", "pata com pedra deixa pegada marcada"],
  ["Pata", "Cristal", "Pegada Brilhante", "🐾", "Vida Real", "pata com cristal deixa pegada brilhante"],
  ["Pata", "Magia", "Cachorro Mágico", "🐶", "Filme", "pata com magia vira cachorro mágico de filme"],
  ["Pata", "Tesouro", "Caça ao Tesouro de Patas", "🐾", "Filme", "pata com tesouro vira caça ao tesouro de patas"],
  ["Pata", "Nuvem", "Sonho de Cachorro", "🐶", "Vida Real", "pata com nuvem é sonho de cachorro dormindo"],
  ["Pata", "Tempestade", "Pata Assustada", "🐾", "Vida Real", "pata com tempestade é pata assustada com trovão"],
  ["Pata", "Arco-íris", "Pata Colorida", "🌈", "Vida Real", "pata com arco-íris vira pata colorida de tinta"],
  ["Pata", "Vapor", "Rastro Quente", "🐾", "Vida Real", "pata com vapor deixa rastro quentinho"],
  ["Pata", "Lama", "Pegada na Lama", "🐾", "Vida Real", "pata com lama deixa pegada na lama"],
  ["Pata", "Lava", "Pegada Vulcânica", "🐾", "Vida Real", "pata com lava deixa pegada vulcânica"],
  ["Pata", "Chuva", "Pata Molhada", "🐾", "Vida Real", "pata com chuva volta molhada da rua"],
  ["Amizade", "Flor", "Buquê de Amizade", "💐", "Vida Real", "amizade com flor vira buquê de amizade"],
  ["Amizade", "Pedra", "Promessa Eterna", "💎", "Vida Real", "amizade com pedra vira promessa eterna"],
  ["Amizade", "Cristal", "Amizade Verdadeira", "💎", "Vida Real", "amizade com cristal é amizade verdadeira"],
  ["Amizade", "Magia", "Amizade Mágica", "✨", "Filme", "amizade com magia vira amizade mágica de filme"],
  ["Amizade", "Tesouro", "Amizade Preciosa", "👑", "Vida Real", "amizade com tesouro é amizade preciosa"],
  ["Amizade", "Nuvem", "Amizade nas Nuvens", "☁️", "Vida Real", "amizade com nuvem é amizade nas nuvens"],
  ["Amizade", "Tempestade", "Amizade à Prova de Tempestade", "🌧️", "Vida Real", "amizade com tempestade é amizade à prova de tempestade"],
  ["Amizade", "Arco-íris", "Amizade Colorida", "🌈", "Vida Real", "amizade com arco-íris vira amizade colorida"],
  ["Amizade", "Vapor", "Amizade Quente", "💛", "Vida Real", "amizade com vapor é amizade quentinha"],
  ["Amizade", "Lama", "Amizade de Infância", "🧒", "Vida Real", "amizade com lama lembra amizade de infância no quintal"],
  ["Amizade", "Lava", "Amizade que Queima", "🔥", "Vida Real", "amizade com lava é amizade que queima de tanta energia"],
  ["Amizade", "Chuva", "Amizade na Chuva", "🌧️", "Vida Real", "amizade com chuva é dividir guarda-chuva na chuva"],
  ["Nuvem", "Pedra", "Montanha com Nuvens", "⛰️", "Vida Real", "nuvem com pedra forma montanha com nuvens no topo"],
  ["Nuvem", "Cristal", "Castelo nas Nuvens", "🏰", "Filme", "nuvem com cristal vira castelo nas nuvens"],
  ["Nuvem", "Magia", "Vassoura Voadora", "🧹", "Filme", "nuvem com magia vira vassoura voadora de Harry Potter"],
  ["Nuvem", "Tesouro", "Cidade no Céu", "☁️", "Filme", "nuvem com tesouro lembra a cidade no céu de O Castelo no Céu"],
  ["Nuvem", "Tempestade", "Cumulonimbus", "☁️", "Vida Real", "nuvem com tempestade vira cumulonimbus, nuvem de tempestade"],
  ["Nuvem", "Arco-íris", "Arco-Íris nas Nuvens", "🌈", "Vida Real", "nuvem com arco-íris forma arco-íris nas nuvens"],
  ["Nuvem", "Vapor", "Céu de Algodão", "☁️", "Vida Real", "nuvem com vapor vira céu de algodão"],
  ["Nuvem", "Lama", "Nuvem de Poeira", "🌫️", "Vida Real", "nuvem com lama seca vira nuvem de poeira"],
  ["Nuvem", "Lava", "Nuvem de Cinzas", "🌋", "Vida Real", "nuvem com lava vira nuvem de cinzas"],
  ["Nuvem", "Chuva", "Chuva Forte", "🌧️", "Vida Real", "nuvem com chuva cai em chuva forte"],
  ["Pedra", "Flor", "Jardim de Pedras", "🪨", "Vida Real", "pedra com flor vira jardim de pedras"],
  ["Pedra", "Cristal", "Pedra Preciosa", "💎", "Vida Real", "pedra com cristal vira pedra preciosa"],
  ["Pedra", "Magia", "Excalibur", "🗡️", "Mitologia", "pedra com magia lembra Excalibur, a espada na pedra"],
  ["Pedra", "Tesouro", "Rubim", "💎", "Vida Real", "pedra com tesouro vira rubim"],
  ["Pedra", "Tempestade", "Deslizamento", "🪨", "Vida Real", "pedra com tempestade vira deslizamento no morro"],
  ["Pedra", "Arco-íris", "Opala", "💎", "Vida Real", "pedra com arco-íris vira opala, pedra colorida"],
  ["Pedra", "Vapor", "Gêiser de Pedra", "🌋", "Vida Real", "pedra com vapor jorra como gêiser de pedra"],
  ["Pedra", "Lama", "Barro Cozido", "🏺", "Vida Real", "pedra com lama vira barro cozido"],
  ["Pedra", "Lava", "Rocha Ígnea", "🪨", "Vida Real", "pedra com lava vira rocha ígnea"],
  ["Pedra", "Chuva", "Cachoeira de Pedra", "🌊", "Vida Real", "pedra com chuva vira cachoeira de pedra"],
  ["Flor", "Tempestade", "Tempestade de Pétalas", "🌸", "Vida Real", "flor com tempestade vira tempestade de pétalas"],
  ["Flor", "Cristal", "Flor de Cristal", "💎", "Vida Real", "flor com cristal vira flor de cristal"],
  ["Flor", "Magia", "Flor Mágica", "🌸", "Filme", "flor com magia lembra a flor mágica de Enrolados"],
  ["Flor", "Tesouro", "Flor de Ouro", "🌻", "Vida Real", "flor com tesouro vira flor de ouro"],
  ["Flor", "Arco-íris", "Jardim Encantado", "🌈", "Filme", "flor com arco-íris vira jardim encantado"],
  ["Flor", "Vapor", "Aromaterapia", "🌸", "Vida Real", "flor com vapor vira aromaterapia"],
  ["Flor", "Lama", "Flor de Lótus", "🪷", "Vida Real", "flor com lama nasce flor de lótus na lagoa"],
  ["Flor", "Lava", "Rosa de Fogo", "🌹", "Vida Real", "flor com lava vira rosa de fogo"],
  ["Flor", "Chuva", "Flor da Chuva", "🌧️", "Vida Real", "flor com chuva é flor da chuva no jardim"],
  ["Tempestade", "Cristal", "Raio de Cristal", "💎", "Vida Real", "tempestade com cristal vira raio de cristal"],
  ["Tempestade", "Magia", "Tempestade Mágica", "🌩️", "Filme", "tempestade com magia vira tempestade mágica"],
  ["Tempestade", "Tesouro", "Navio Naufragado", "🚢", "Filme", "tempestade com tesouro lembra navio naufragado de Piratas do Caribe"],
  ["Tempestade", "Arco-íris", "Tempestade de Arco-Íris", "🌈", "Vida Real", "tempestade com arco-íris vira tempestade de arco-íris"],
  ["Tempestade", "Vapor", "Furacão", "🌪️", "Vida Real", "tempestade com vapor gira em furacão"],
  ["Tempestade", "Lama", "Enchente de Lama", "🌊", "Vida Real", "tempestade com lama vira enchente de lama"],
  ["Tempestade", "Lava", "Erupção Elétrica", "🌋", "Vida Real", "tempestade com lava vira erupção elétrica do vulcão"],
  ["Tempestade", "Chuva", "Monção", "🌧️", "Vida Real", "tempestade com chuva vira monção"],
  ["Arco-íris", "Cristal", "Prisma de Arco-Íris", "🌈", "Vida Real", "arco-íris com cristal vira prisma de arco-íris"],
  ["Arco-íris", "Magia", "Arco-Íris Mágico", "🌈", "Filme", "arco-íris com magia vira arco-íris mágico"],
  ["Arco-íris", "Tesouro", "Pote de Ouro", "🪙", "Mitologia", "arco-íris com tesouro lembra o pote de ouro do duende"],
  ["Arco-íris", "Vapor", "Arco-Íris Duplo", "🌈", "Vida Real", "arco-íris com vapor forma arco-íris duplo"],
  ["Arco-íris", "Lama", "Pintura com Barro", "🎨", "Vida Real", "arco-íris com lama vira pintura com barro"],
  ["Arco-íris", "Lava", "Arco-Íris de Fogo", "🌈", "Vida Real", "arco-íris com lava lembra o arco-íris de fogo no céu"],
  ["Arco-íris", "Chuva", "Arco-Íris da Chuva", "🌈", "Vida Real", "arco-íris com chuva é arco-íris da chuva"],
  ["Cristal", "Tesouro", "Coroa de Cristal", "👑", "Vida Real", "cristal com tesouro vira coroa de cristal"],
  ["Cristal", "Vapor", "Cristal de Gelo", "❄️", "Vida Real", "cristal com vapor vira cristal de gelo"],
  ["Cristal", "Lama", "Cristal de Barro", "💎", "Vida Real", "cristal com lama vira cristal de barro"],
  ["Cristal", "Lava", "Pedra do Infinito", "💎", "Filme", "cristal com lava brilha como Pedra do Infinito"],
  ["Cristal", "Chuva", "Cristal de Chuva", "💎", "Vida Real", "cristal com chuva vira cristal de chuva"],
  ["Magia", "Tesouro", "Baú Mágico", "🎁", "Filme", "magia com tesouro abre um baú mágico"],
  ["Magia", "Vapor", "Feitiço de Névoa", "🌫️", "Filme", "magia com vapor vira feitiço de névoa"],
  ["Magia", "Lama", "Golem de Barro", "🗿", "Mitologia", "magia com lama cria o golem de barro"],
  ["Magia", "Lava", "Dragão de Fogo", "🐉", "Mitologia", "magia com lava invoca um dragão de fogo"],
  ["Magia", "Chuva", "Chuva Mágica", "🌧️", "Filme", "magia com chuva vira chuva mágica"],
  ["Tesouro", "Vapor", "Tesouro Escondido", "🗺️", "Filme", "tesouro com vapor vira tesouro escondido"],
  ["Tesouro", "Lama", "Tesouro Enterrado", "🗺️", "Filme", "tesouro com lama vira tesouro enterrado"],
  ["Tesouro", "Lava", "Tesouro Vulcânico", "🌋", "Filme", "tesouro com lava vira tesouro vulcânico"],
  ["Tesouro", "Chuva", "Caça ao Tesouro na Chuva", "🗺️", "Filme", "tesouro com chuva vira caça ao tesouro na chuva"],
  ["Pokébola", "Fogo", "Charizard", "🔥", "Anime", "pokébola com fogo solta o Charizard, o dragão de fogo"],
  ["Pokébola", "Água", "Blastoise", "🌊", "Anime", "pokébola com água solta o Blastoise, a tartaruga de água"],
  ["Pokébola", "Elétrico", "Pikachu", "⚡", "Anime", "pokébola elétrica solta o Pikachu"],
  ["Brasil", "Praia", "Bahia", "🎶", "Vida Real", "brasil com praia tem a cara da Bahia, sol, mar e festa"],
  ["Brasil", "Turismo", "Cristo Redentor", "🇧🇷", "Vida Real", "turismo no brasil leva direto ao Cristo Redentor"],
  // Correção do bug "do San Oceano": San + Oceano NUNCA vira "do San Oceano"
  // (preposição invertida no começo). Ordem correta em português:
  // Substantivo + do + Nome = "Praia do San". Determinístico: sempre este.
  ["Oceano", "San", "Praia do San", "🏖️", "Vida Real", "o San chega no oceano e a praia vira a Praia do San, com sol, mar e diversão"],
  ["Turismo", "Praia", "Cataratas do Iguaçu", "🌊", "Vida Real", "turismo com praia leva às Cataratas do Iguaçu"],
  ["Turismo", "Brasil", "Cristo Redentor", "🇧🇷", "Vida Real", "turismo no brasil leva direto ao Cristo Redentor"],
  ["Praia", "Brasil", "Bahia", "🎶", "Vida Real", "praia no brasil tem a cara da Bahia"],
  // ===== MODO MUNDO — fusões com países (determinísticas) =====
  ["Água", "Japão", "Tsunami", "🌊", "Vida Real", "água do mar no Japão vira tsunami, onda gigante de verdade"],
  ["Flor", "Japão", "Sakura", "🌸", "Vida Real", "flor do Japão é a sakura, a flor de cerejeira"],
  ["Montanha", "Japão", "Monte Fuji", "🗻", "Vida Real", "montanha do Japão é o Monte Fuji"],
  ["Pedra", "Japão", "Katana", "🗡️", "Vida Real", "pedra e fogo de forja no Japão viram katana, a espada japonesa"],
  ["Vento", "Japão", "Origami", "🦢", "Vida Real", "vento leve no Japão lembra o origami, a arte de dobrar papel"],
  ["Fogo", "México", "Pimenta", "🌶️", "Vida Real", "fogo com México vira pimenta, o tempero picante de verdade"],
  ["Água", "México", "Horchata", "🥛", "Vida Real", "água com México vira horchata, bebida doce de arroz"],
  ["Terra", "México", "Cacto", "🌵", "Vida Real", "terra seca do México vira cacto"],
  ["Vento", "México", "Sombrero", "👒", "Vida Real", "vento e sol do México pedem sombrero, o chapéu largo"],
  ["Terra", "França", "Torre Eiffel", "🗼", "Vida Real", "terra de Paris com ferro vira Torre Eiffel"],
  ["Fogo", "França", "Croissant", "🥐", "Vida Real", "fogo do forno na França vira croissant"],
  ["Fogo", "Itália", "Pizza", "🍕", "Vida Real", "fogo do forno na Itália vira pizza"],
  ["Terra", "Itália", "Coliseu", "🏛️", "Vida Real", "terra de Roma vira Coliseu"],
  ["Água", "Itália", "Gôndola", "🛶", "Vida Real", "água de Veneza vira gôndola"],
  ["Vento", "Espanha", "Flamenco", "💃", "Vida Real", "vento e ritmo da Espanha viram flamenco"],
  ["Terra", "Espanha", "Paella", "🥘", "Vida Real", "terra da Espanha com arroz vira paella"],
  ["Fogo", "Espanha", "Touro", "🐂", "Vida Real", "fogo e festa da Espanha lembram o touro"],
  ["Terra", "China", "Muralha da China", "🧱", "Vida Real", "terra da China empilhada vira Muralha da China"],
  ["Fogo", "China", "Dragão Chinês", "🐉", "Vida Real", "fogo com China vira dragão chinês das festas"],
  ["Terra", "Coreia", "Kimchi", "🥬", "Vida Real", "terra da Coreia com repolho vira kimchi"],
  ["Vento", "Coreia", "K-Pop", "🎤", "Vida Real", "vento e ritmo da Coreia viram K-Pop"],
  ["Terra", "Índia", "Taj Mahal", "🕌", "Vida Real", "terra da Índia com mármore vira Taj Mahal"],
  ["Fogo", "Índia", "Curry", "🍛", "Vida Real", "fogo da Índia com tempero vira curry"],
  ["Terra", "Egito", "Pirâmide", "🔺", "Vida Real", "terra do Egito empilhada vira pirâmide"],
  ["Água", "Egito", "Nilo", "🌊", "Vida Real", "água do Egito é o rio Nilo"],
  ["Fogo", "Egito", "Esfinge", "🦁", "Vida Real", "fogo do deserto do Egito lembra a Esfinge"],
  ["Terra", "Grécia", "Olimpo", "⛰️", "Vida Real", "terra da Grécia alta vira Olimpo"],
  ["Água", "Grécia", "Odisseia", "🚢", "Vida Real", "água da Grécia com viagem vira Odisseia"],
  ["Fogo", "EUA", "Hambúrguer", "🍔", "Vida Real", "fogo dos EUA com carne vira hambúrguer"],
  ["Terra", "EUA", "Hollywood", "🎬", "Vida Real", "terra dos EUA com cinema vira Hollywood"],
  ["Terra", "Alemanha", "Castelo de Neuschwanstein", "🏰", "Vida Real", "terra da Alemanha vira Castelo de Neuschwanstein"],
  ["Fogo", "Alemanha", "Pretzel", "🥨", "Vida Real", "fogo do forno da Alemanha vira pretzel"],
  ["Água", "Inglaterra", "Chá", "☕", "Vida Real", "água quente da Inglaterra vira chá"],
  ["Terra", "Inglaterra", "Big Ben", "🕰️", "Vida Real", "terra de Londres vira Big Ben"],
  ["Terra", "Rússia", "Matrioska", "🪆", "Vida Real", "terra da Rússia com madeira vira matrioska"],
  ["Vento", "Rússia", "Balalaica", "🎸", "Vida Real", "vento da Rússia com música vira balalaica"],
  ["Terra", "África", "Savana", "🦁", "Vida Real", "terra da África aberta vira savana"],
  ["Água", "África", "Leão", "🦁", "Vida Real", "água da savana da África lembra o leão"],
  ["Terra", "Austrália", "Canguru", "🦘", "Vida Real", "terra da Austrália com animal vira canguru"],
  ["Água", "Austrália", "Boomerang", "🪃", "Vida Real", "água da Austrália com vento lembra o boomerang"],
  ["Água", "Canadá", "Xarope de Bordo", "🍁", "Vida Real", "água doce do Canadá vira xarope de bordo"],
  ["Terra", "Canadá", "Alce", "🦌", "Vida Real", "terra fria do Canadá vira alce"],
  ["Água", "Portugal", "Bacalhau", "🐟", "Vida Real", "água de Portugal com peixe vira bacalhau"],
  ["Terra", "Turquia", "Bazar", "🏪", "Vida Real", "terra da Turquia com mercado vira bazar"],
  ["Terra", "Tailândia", "Templo Dourado", "🛕", "Vida Real", "terra da Tailândia vira Templo Dourado"],
  ["Terra", "Peru", "Machu Picchu", "⛰️", "Vida Real", "terra do Peru alta vira Machu Picchu"],
  ["Vento", "Argentina", "Tango", "💃", "Vida Real", "vento da Argentina com música vira tango"],
  ["Flor", "Colômbia", "Café", "☕", "Vida Real", "flor da Colômbia com grão vira café"],
  ["Terra", "Quênia", "Safári", "🦁", "Vida Real", "terra do Quênia com animais vira safári"],
  ["Terra", "Marrocos", "Cuscuz", "🍲", "Vida Real", "terra de Marrocos com grãos vira cuscuz"],
  ["Flor", "Holanda", "Tulipa", "🌷", "Vida Real", "flor da Holanda é a tulipa"],
  ["Terra", "Suíça", "Alpes", "🏔️", "Vida Real", "terra da Suíça alta vira Alpes"],
];
const CURATED_COMBOS: Record<string, ResultadoIA> = Object.fromEntries(
  CURATED_ENTRIES.map(([a, b, nome, emoji, categoria, motivoCurto]) => [
    chave(a, b),
    { nome: limitarNomeIA(nome), emoji, categoria, motivo: `Porque ${a} + ${b} ${motivoCurto}.`, dicionario: dicionarioDe(nome)?.dicionario, significado: dicionarioDe(nome)?.significado, pais: dicionarioDe(nome)?.pais, idioma: dicionarioDe(nome)?.idioma },
  ]),
);
// ===== IA POR PREDOMINÂNCIA DE UNIVERSO =====
// 1. Curada exata já foi resolvida em combinar() antes de chegar aqui.
// 2. Universo de A manda: procura em A algo com as tags de B.
// 3. Universo de B: procura em B algo com as tags de A.
// 4. Neutro + Neutro: física / vida real, com tag em comum.
// 5. Outros universos: só com pelo menos 1 tag em comum.
// 6. Criação Original: quando nada existente faz sentido, inventar algo novo
//    e plausível a partir de uma propriedade real de cada elemento.
//    Temperatura 0.4: conservadora — nunca força um personagem/coisa existente
//    Temperatura 0.6: mais criativa — ainda plausível, nunca força um
//    personagem/coisa existente que não combina.
//    que não combina, e nunca diz que a invenção existe fora do jogo.
const ADJETIVO_POR_TAG: Record<string, string> = {
  fogo: "Quente", agua: "Molhado", vento: "Leve", terra: "Firme", eletrico: "Elétrico", raio: "Elétrico",
  // REGRA DE OURO: todo adjetivo aqui pode ir ANTES do substantivo
  // ("Criativo Oceano", "Dracônico Oceano") ou DEPOIS ("Oceano Criativo").
  // NUNCA pode começar com preposição ("do San", "de Dragão", "do Mar"):
  // era isso que gerava "do San Oceano" — o adjetivo "do San" era colado
  // na frente do substantivo. Preposição só no meio, na ordem correta:
  // Substantivo + do/da + Substantivo ("Oceano do San").
  dragao: "Dracônico", monstro: "Monstruoso", magia: "Mágico", doce: "Doce", comida: "Gostoso",
  flor: "Florido", planta: "Verde", pedra: "Rochoso", mar: "Marinho", gelo: "Gelado", portal: "Místico",
  tesouro: "Precioso", ouro: "Dourado", luz: "Brilhante", sombra: "Sombrio", voador: "Voador",
  cachorro: "Fofo", animal: "Fofo", criador: "Criativo", captura: "Capturador", bola: "Redondo",
  esfera: "Esférico", desejo: "Desejado", espada: "Afiado", pirata: "Pirata", borracha: "Elástico",
  chakra: "Energético", jutsu: "Ninja", ideia: "Brilhante", amizade: "Amigável", fruta: "Frutado",
  sol: "Ensolarado", lua: "Lunar", estrela: "Estrelado", coracao: "Afetuoso", psiquico: "Psíquico",
  fantasma: "Fantasmagórico", veneno: "Venenoso", lutador: "Lutador", metal: "Metálico", normal: "Simples",
  areia: "Arenoso", sapo: "Anfíbio", olho: "Observador", forca: "Forte", cura: "Curativo",
  atirador: "Preciso", musica: "Musical", robo: "Robótico", energia: "Energético", heroi: "Heróico",
  dinossauro: "Pré-histórico", casa: "Caseiro", labirinto: "Labiríntico", cavalo: "Equestre",
  passaro: "Alado", tartaruga: "Marinho", rato: "Pequeno", raposa: "Astuto",
  brasil: "Brasileiro", turismo: "Turístico", praia: "Praiano", cidade: "Urbano", monumento: "Monumental", viagem: "Viajante",
  cachoeira: "Cascateante", festa: "Festivo", capital: "Capitalino", inseto: "Minúsculo", fada: "Encantado",
};
// Essência = a parte mais reconhecível do elemento. Ex.: Meg vira "Pata",
// Hidra vira "Dragão" — assim "Café + Hidra" pode virar "Café de Dragão".
const ESSENCIA_POR_NOME: Record<string, string> = {
  Meg: "Pata", San: "Invenção", Hidra: "Dragão", Amizade: "Carinho", Pata: "Pata",
  Pokébola: "Pokébola", "Esfera do Dragão": "Esfera", "Devil Fruit": "Fruta",
};
function adjetivoDe(e: Elemento, meta: MetaElemento): string {
  for (const tag of meta.tags) {
    const adjetivo = ADJETIVO_POR_TAG[tag];
    // Defesa em profundidade: um adjetivo nunca pode começar com
    // preposição ("do San", "de Dragão") — era a causa de "do San Oceano".
    if (adjetivo && !/^(do|de|da|dos|das|no|na)\s/i.test(adjetivo)) return adjetivo;
  }
  const palavras = normalizar(e.nome).split(/[^a-z]+/).filter(Boolean);
  for (const palavra of palavras) {
    const adjetivo = ADJETIVO_POR_TAG[palavra];
    if (adjetivo && !/^(do|de|da|dos|das|no|na)\s/i.test(adjetivo)) return adjetivo;
  }
  return "Novo";
}
function essenciaDe(e: Elemento): string {
  // Nunca devolver o nome composto inteiro: "Banho de Cachorro" /
  // "Banho-de-Cachorro" vira "Banho", para o fallback nunca montar
  // "Banho de Cachorro de Água".
  const base = ESSENCIA_POR_NOME[e.nome] || e.nome;
  const comEspaco = base.replace(/-/g, " ");
  return comEspaco.includes(" de ") ? comEspaco.split(" de ")[0].trim() : comEspaco;
}
function criarOriginal(a: Elemento, b: Elemento, jaTem: (nome: string) => boolean): ResultadoIA {
  // Mesmo elemento + mesmo elemento: intensificar, nunca repetir.
  if (normalizar(a.nome) === normalizar(b.nome)) return versaoIntensificada(a);
  // San + qualquer coisa sem receita curada: ordem correta em português é
  // Substantivo + do + San ("Oceano do San", "Praia do San") — nunca
  // "do San Oceano" (preposição invertida no começo) nem "San Oceano" colado.
  const outroDoSan = normalizar(a.nome) === "san" ? b : normalizar(b.nome) === "san" ? a : null;
  if (outroDoSan) {
    const essenciaOutro = essenciaDe(outroDoSan);
    const nomeSan = limitarNomeIA(`${essenciaOutro} do San`);
    if (!nomeProibido(nomeSan, a, b) && nomeSan !== a.nome && nomeSan !== b.nome) {
      return {
        nome: nomeSan, emoji: outroDoSan.emoji || "✨", categoria: "Vida Real", universo: "Criação Original",
        tags: [...new Set([...metadadosDe(a).tags, ...metadadosDe(b).tags])],
        original: true,
        motivo: `Criação Original: ${a.nome} + ${b.nome} vira ${nomeSan} — em português a ordem certa é substantivo + "do" + San, nunca "do San ${essenciaOutro}". Uma invenção do jogo, não um elemento oficial.`,
      };
    }
  }
  const metaA = metadadosDe(a);
  const metaB = metadadosDe(b);
  const adjA = adjetivoDe(a, metaA);
  const adjB = adjetivoDe(b, metaB);
  // Essências já sem "de ..." (essenciaDe corta no "de") e sem repetição:
  // se as duas essências forem iguais, usar só uma + adjetivo.
  const essA = essenciaDe(a);
  const essB = essenciaDe(b);
  const essBUnica = normalizar(essB) === normalizar(essA) ? essA : essB;
  const emojiA = a.emoji || "✨";
  const emojiB = b.emoji || "✨";
  // Modelos combinam 1 PROPRIEDADE de A + 1 propriedade/conceito de B,
  // nunca concatenam os nomes ("X de Y" banido). Ordem determinística
  // pelo hash da dupla: mesma dupla = sempre o mesmo resultado.
  const modelos: Array<{ nome: string; emoji: string }> = [
    { nome: `${adjA} ${essBUnica}`, emoji: emojiB },
    { nome: `${adjB} ${essA}`, emoji: emojiA },
    { nome: `Super ${essBUnica}`, emoji: emojiB },
    { nome: `Mega ${essA}`, emoji: emojiA },
    { nome: `Grande ${essBUnica}`, emoji: emojiB },
    { nome: `Pequeno ${essBUnica}`, emoji: emojiB },
    { nome: `${essA} ${adjB}`, emoji: emojiA },
  ];
  // Determinístico e independente da ordem: A+B e B+A usam a mesma chave ordenada.
  const inicio = hashTexto(chave(a.nome, b.nome)) % modelos.length;
  for (let i = 0; i < modelos.length; i++) {
    const candidato = modelos[(inicio + i) % modelos.length];
    const nome = limitarNomeIA(candidato.nome);
    // Criação Original só com palavras do dicionário: cada palavra do
    // candidato precisa existir no dicionário (ex.: Coleira + Brilhante).
    const palavrasCandidato = nome.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").split(/[^a-z]+/).filter(Boolean);
    if (palavrasCandidato.some((p) => !PALAVRAS_DICIONARIO.has(p))) continue;
    // Não pular por jaTem: repetir a mesma dupla deve devolver o mesmo
    // resultado (combinarNomes já trata "você já tem"). Pular faria a
    // segunda fusão dar outro elemento — o bug Amizade+Fogo = Eevee/ Charizard.
    void jaTem;
    if (nome === a.nome || nome === b.nome) continue;
    if (FRASES_PROIBIDAS_IA.some((f) => normalizar(nome).includes(f))) continue;
    // Anti-recursão: descarta qualquer "X de X" ou nome com palavra repetida
    // e tenta o próximo modelo, em vez de devolver "Água de Água de Água".
    if (nomeProibido(nome, a, b)) continue;
    return {
      nome, emoji: candidato.emoji, categoria: "Vida Real", universo: "Criação Original",
      tags: [...new Set([...metaA.tags, ...metaB.tags])],
      original: true,
      motivo: `Criação Original: ${a.nome} traz “${adjA.toLowerCase()}” e ${b.nome} traz “${essBUnica}”. Juntos, dá pra imaginar ${nome} — uma invenção do jogo, não um elemento oficial de anime, filme ou da vida real.`,
    };
  }
  // Último recurso: versão intensificada, nunca "Novo X de Y".
  // Último recurso também passa pelo filtro: se "Super X" fosse proibido
  // (ex.: começasse com preposição), cai para um nome seguro e prefixável.
  const nomeBruto = limitarNomeIA(`Super ${essBUnica}`);
  const nome = nomeProibido(nomeBruto, a, b) ? "Super Invenção" : nomeBruto;
  return {
    nome, emoji: emojiB, categoria: "Vida Real", universo: "Criação Original", tags: [...new Set([...metaA.tags, ...metaB.tags])], original: true,
    motivo: `Criação Original: ${a.nome} + ${b.nome} vira ${nome} — uma versão maior e mais forte, não uma repetição do nome.`,
  };
}
function gerarIA(a: Elemento, b: Elemento, jaTem: (nome: string) => boolean, alucinatorio = false): ResultadoIA {
  // A+A que não está na tabela curada: intensificar direto, sem passar
  // pelos bancos (que poderiam devolver um conceito solto) e sem "A de A".
  if (normalizar(a.nome) === normalizar(b.nome)) return versaoIntensificada(a);
  // Modo Alucinatório (temperatura 0.9): tenta primeiro uma invenção
  // inesperada com símbolos / números / palavras do mundo. Se nenhuma
  // candidata segura passar, cai para o caminho dicionário abaixo.
  // Quando OFF, este bloco nunca roda — o resultado continua determinístico.
  if (alucinatorio) {
    const alucinacao = criarAlucinatorio(a, b, jaTem);
    if (alucinacao) return alucinacao;
  }
  const metaA = metadadosDe(a);
  const metaB = metadadosDe(b);
  const excluir = new Set([a.nome, b.nome]);
  // NOVA ORDEM (pedido do jogador):
  // 1. Curada exata — já resolvida em combinarNomes antes de chegar aqui.
  // 2. TERRA REAL primeiro: física / natureza / vida real.
  // 3. BRASIL segundo: estados, cidades e pontos do Brasil.
  // 4. FICCIONAL por último — SÓ com match forte (ver buscarForte).
  // 5. Criação Original (temp. 0.6) se nada existir com sentido.
  // DETERMINÍSTICO: nunca usa Math.random() e nunca exclui um resultado
  // só porque ele já foi descoberto — repetir a dupla devolve o mesmo
  // elemento e combinarNomes avisa "você já tinha". Sem isso, a 2ª fusão
  // de 💛+🔥 trocava Eevee por Charizard.
  void jaTem;
  const nuncaTem = () => false;
  const forte = (universo: string, exigeBrasil: boolean) =>
    buscarForte(universo, metaA.tags, metaB.tags, excluir, { minTotal: 2, exigeAmbos: true, exigeBrasil });
  // 2 — DICIONÁRIO PT-BR PRIMEIRO: palavra real do dicionário brasileiro
  // com 1 tag de cada insumo. Ex.: Água + Planta = Vitória Régia.
  const pt = buscarDicionario(DICIONARIO_PT_BR, metaA.tags, metaB.tags, excluir);
  if (pt) return montarResultadoDicionario(pt.entrada, a, b, pt.compartilhadas);
  // 2 — Terra real: candidato precisa ter pelo menos 1 tag de CADA insumo.
  // Água+Planta → Vitória Régia (agua+planta). Diamante+Água → Gelo Brilhante
  // (pedra+agua, sem eletricidade). Meg+Faísca → Cachorro Quente (cachorro+fogo).
  // Com 1 tag só, Gyarados (agua+dragao) jamais passaria por Água+Planta.
  for (const universo of ["Vida Real", "Neutro"]) {
    const achado = forte(universo, false);
    if (achado) return montarResultado(achado.entrada, universo === "Neutro" ? "Neutro" : "Vida Real", a, b, achado.compartilhadas, "é física / natureza da Terra real");
  }
  // 3 — Brasil: candidato precisa ser do Brasil E ter 1 tag de cada insumo.
  for (const universo of ["Estados do Brasil", "Cidades do Mundo", "Pontos Turísticos do Mundo"]) {
    const achado = forte(universo, true);
    if (achado) return montarResultado(achado.entrada, "Brasil", a, b, achado.compartilhadas, "é do Brasil");
  }
  // 3b — DICIONÁRIOS DO MUNDO: palavra real de outro idioma, com origem.
  // Ex.: Flor + Vento pode trazer Sakura (Japonês); Água + Japão seria Tsunami
  // quando o elemento Japão estiver na coleção.
  const mundo = buscarDicionario(DICIONARIO_MUNDO_TODOS, metaA.tags, metaB.tags, excluir);
  if (mundo) return montarResultadoDicionario(mundo.entrada, a, b, mundo.compartilhadas);
  // 4 — Ficcional: exige 1 tag de cada insumo E pelo menos 2 tags no total.
  // Água+Planta nunca chega aqui (Terra já resolveu). Fogo+Cachorro nunca
  // vira Vaporeon: Vaporeon tem agua+cachorro, 0 tags de fogo.
  const FICCIONAIS = ["Pokémon", "Naruto", "Dragon Ball", "One Piece", "Mitologia", "Filme", "Anime"];
  for (const universo of FICCIONAIS) {
    const achado = forte(universo, false);
    if (achado) return montarResultado(achado.entrada, universo, a, b, achado.compartilhadas, "combina forte com os dois insumos");
  }
  // 4b — Captura: Pokébola/Esfera + um tipo forte (ex.: Chidori = elétrico).
  // Aqui 1 tag basta, porque a Pokébola diz o universo e o outro insumo diz o tipo.
  const captura = buscarCaptura(a, b, metaA, metaB, excluir);
  if (captura) return montarResultado(captura.entrada, "Pokémon", a, b, captura.compartilhadas, "a Pokébola captura o tipo do outro insumo");
  // 5 — Criação Original: nada existente fez sentido, então inventar algo
  // novo e plausível (temperatura 0.6), em vez de forçar um fictício.
  return criarOriginal(a, b, jaTem);
}
// Match forte: candidato precisa compartilhar tag com A E com B, e o total
// (tags únicas em comum com a dupla) precisa ser >= minTotal. Desempate:
// mantém o primeiro da lista — ordem fixa, sem sorteio, sempre igual.
function buscarForte(
  universo: string,
  tagsA: string[],
  tagsB: string[],
  excluir: Set<string>,
  opts: { minTotal: number; exigeAmbos: boolean; exigeBrasil: boolean },
): { entrada: EntradaUniverso; compartilhadas: string[]; comA: string[]; comB: string[] } | null {
  let melhor: { entrada: EntradaUniverso; compartilhadas: string[]; comA: string[]; comB: string[] } | null = null;
  for (const entrada of BANCO_UNIVERSOS[universo] || []) {
    if (excluir.has(entrada.nome)) continue;
    if (opts.exigeBrasil && !entrada.tags.includes("brasil")) continue;
    const comA = tagsEmComum(entrada.tags, tagsA);
    const comB = tagsEmComum(entrada.tags, tagsB);
    if (opts.exigeAmbos && (!comA.length || !comB.length)) continue;
    const compartilhadas = [...new Set([...comA, ...comB])];
    if (compartilhadas.length < opts.minTotal) continue;
    if (!melhor || compartilhadas.length > melhor.compartilhadas.length) melhor = { entrada, compartilhadas, comA, comB };
  }
  return melhor;
}
// Pokébola/Esfera + tipo: procura em Pokémon um candidato que tenha pelo
// menos 1 tag do insumo que NÃO é a Pokébola (ex.: eletrico do Chidori).
function buscarCaptura(a: Elemento, b: Elemento, metaA: MetaElemento, metaB: MetaElemento, excluir: Set<string>): { entrada: EntradaUniverso; compartilhadas: string[] } | null {
  const ladoCaptura = metaA.tags.some((t) => t === "captura" || t === "bola" || t === "esfera")
    ? { outro: metaB.tags } : metaB.tags.some((t) => t === "captura" || t === "bola" || t === "esfera")
    ? { outro: metaA.tags } : null;
  if (!ladoCaptura) return null;
  let melhor: { entrada: EntradaUniverso; compartilhadas: string[] } | null = null;
  for (const entrada of BANCO_UNIVERSOS["Pokémon"] || []) {
    if (excluir.has(entrada.nome)) continue;
    const compartilhadas = tagsEmComum(entrada.tags, ladoCaptura.outro);
    if (!compartilhadas.length) continue;
    if (!melhor || compartilhadas.length > melhor.compartilhadas.length) melhor = { entrada, compartilhadas };
  }
  return melhor;
}

// ===== ESCOLHA DE EMOJI - LABORATÓRIO DO CRIADOR =====
// Teclado de emoji estilo celular. Cada emoji é só um atalho:
// clicar em um deles preenche o campo Emoji do novo elemento.
// O teclado mostra EXATAMENTE 10 emojis por página, em grade 5x2.
const EMOJIS_POR_PAGINA = 10;
const CATEGORIAS_EMOJI: { titulo: string; icone: string; emojis: string[] }[] = [
  {
    titulo: "Smileys",
    icone: "😀",
    emojis: ["😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋", "😛", "😜", "🤪", "😝", "🤑", "🤗", "🤭", "🤫", "🤔", "🤐", "🤨", "😐", "😑", "😶", "🙄", "😬", "😔", "😪", "🤤", "😴", "😷", "🤒", "🤕", "🤢", "🤮", "🤧", "🥵", "🥶", "🥴", "😵", "🤯", "🤠", "🥳", "😎", "🤓", "🧐", "😕", "😟", "🙁", "☹️", "😮", "😯", "😲", "😳", "🥺", "😦", "😧", "😨", "😰", "😥", "😢", "😭", "😱", "😖", "😣", "😞", "😓", "😩", "😫", "🥱", "😤", "😡", "😠", "🤬", "😈", "👿", "💀", "☠️"],
  },
  {
    titulo: "Pessoas",
    icone: "🧑",
    emojis: ["👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤌", "🤏", "✌️", "🤞", "🤟", "🤘", "🤙", "👈", "👉", "👆", "🖕", "👇", "☝️", "👍", "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏", "✍️", "💅", "🤳", "💪", "🦾", "🦿", "🦵", "🦶", "👂", "🦻", "👃", "🧠", "🫀", "🫁", "🦷", "🦴", "👀", "👁️", "👅", "👄", "💋", "🩸"],
  },
  {
    titulo: "Animais",
    icone: "🐶",
    emojis: ["🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🦝", "🐻", "🐼", "🦥", "🦦", "🦨", "🦘", "🦡", "🐾", "🦃", "🐔", "🐣", "🐤", "🐥", "🐦", "🐧", "🕊️", "🦅", "🦆", "🦢", "🦉", "🦤", "🪶", "🦩", "🦚", "🦜", "🐸", "🐊", "🐢", "🦎", "🐍", "🐲", "🐉", "🦕", "🦖", "🐳", "🐬", "🦭", "🐟", "🐠", "🐡", "🦈", "🐙", "🦑", "🦀", "🦞", "🦐", "🦪", "🐌", "🦋", "🐛", "🐜", "🐝", "🪲", "🐞", "🦗", "🪳", "🕷️", "🕸️", "🦂", "🦟", "🪰", "🪱", "🦠"],
  },
  {
    titulo: "Comida",
    icone: "🍔",
    emojis: ["🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅", "🥑", "🥦", "🥬", "🥒", "🌶️", "🫑", "🌽", "🥕", "🫒", "🧄", "🧅", "🥔", "🍠", "🥐", "🥯", "🍞", "🥖", "🥨", "🧀", "🥚", "🍳", "🧈", "🥞", "🧇", "🥓", "🥩", "🍗", "🍖", "🦴", "🌭", "🍔", "🍟", "🍕", "🥪", "🥙", "🧆", "🌮", "🌯", "🫔", "🥗", "🥘", "🫕", "🥫", "🍝", "🍜", "🍲", "🍛", "🍣", "🍱", "🥟", "🦪", "🍤", "🍙", "🍚", "🍘", "🍥", "🥠", "🥮", "🍢", "🍡", "🍧", "🍨", "🍦", "🥧", "🧁", "🍰", "🎂", "🍮", "🍭", "🍬", "🍫", "🍿", "🍩", "🍪", "🌰", "🥜", "🍯", "🥛", "🍼", "🫖", "☕", "🍵", "🧃", "🥤", "🧋", "🍶", "🍺", "🍻", "🥂", "🍷", "🥃", "🍸", "🍹", "🧉", "🍾", "🧊", "🥄", "🍴", "🍽️", "🥢"],
  },
  {
    titulo: "Esporte",
    icone: "⚽",
    emojis: ["⚽", "🏀", "🏈", "⚾", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱", "🪀", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏", "🪃", "🥅", "⛳", "🪁", "🏹", "🎣", "🤿", "🥊", "🥋", "🎽", "🛹", "🛼", "🛷", "⛸️", "🥌", "🎿", "⛷️", "🏂", "🪂", "🏋️", "🤼", "🤸", "⛹️", "🤾", "🏌️", "🏇", "🧘", "🏄", "🏊", "🚣", "🚵", "🚴", "🤽"],
  },
  {
    titulo: "Viagem",
    icone: "✈️",
    emojis: ["🚗", "🚕", "🚙", "🚌", "🚎", "🏎️", "🚓", "🚑", "🚒", "🚐", "🛻", "🚚", "🚛", "🚜", "🦯", "🦽", "🦼", "🩼", "🛴", "🚲", "🛵", "🏍️", "🛺", "🚨", "🚔", "🚍", "🚘", "🚖", "🚡", "🚠", "🚟", "🚃", "🚋", "🚞", "🚝", "🚄", "🚅", "🚈", "🚂", "🚆", "🚇", "🚊", "🚉", "✈️", "🛫", "🛬", "🪂", "💺", "🛰️", "🚀", "🛸", "🚁", "🛶", "⛵", "🚤", "🛥️", "🛳️", "⛴️", "🚢", "⚓", "🪝", "⛽", "🚧", "🚦", "🚥", "🚏", "🗺️", "🗿", "🗽", "🗼", "🏰", "🏯", "🏟️", "🎡", "🎢", "🎠", "⛲", "⛱️", "🏖️", "🏝️", "🏜️", "🌋", "⛰️", "🏔️", "🗻", "🏕️", "⛺", "🏠", "🏡", "🏘️", "🏚️", "🏗️", "🏭", "🏢", "🏬", "🏣", "🏤", "🏥", "🏦", "🏨", "🏪", "🏫", "🏩", "💒", "🏛️", "⛪", "🕌", "🛕", "🕍", "🕋", "⛩️", "🛤️", "🛣️", "🗾", "🎑", "🏞️", "🌅", "🌄", "🌠", "🎇", "🎆", "🌇", "🌆", "🏙️", "🌃", "🌌", "🌉", "🌁"],
  },
  {
    titulo: "Objetos",
    icone: "💡",
    emojis: ["⌚", "📱", "📲", "💻", "⌨️", "🖥️", "🖨️", "🖱️", "🖲️", "🕹️", "🗜️", "💽", "💾", "💿", "📀", "📼", "📷", "📸", "📹", "🎥", "📽️", "🎞️", "📞", "☎️", "📟", "📠", "📺", "📻", "🎙️", "🎚️", "🎛️", "🧭", "⏱️", "⏲️", "⏰", "🕰️", "⌛", "⏳", "📡", "🔋", "🪫", "🔌", "💡", "🔦", "🕯️", "🪔", "🧯", "🛢️", "💸", "💵", "💴", "💶", "💷", "🪙", "💰", "💳", "🧾", "💎", "⚖️", "🪜", "🧰", "🪛", "🔧", "🔨", "⚒️", "🛠️", "⛏️", "🪚", "🔩", "⚙️", "🪤", "🧱", "⛓️", "🧲", "🔫", "💣", "🧨", "🪓", "🔪", "🗡️", "⚔️", "🛡️", "🚬", "⚰️", "🪦", "⚱️", "🏺", "🔮", "📿", "🧿", "🪬", "💈", "⚗️", "🔭", "🔬", "🕳️", "🩹", "🩺", "💊", "💉", "🩸", "🧬", "🦠", "🧫", "🧪", "🌡️", "🧹", "🪥", "🧺", "🧻", "🚽", "🚿", "🛁", "🪒", "🧴", "🧷"],
  },
  {
    titulo: "Símbolos",
    icone: "❤️",
    emojis: ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "☮️", "✝️", "☪️", "🕉️", "☸️", "✡️", "🔯", "🕎", "☯️", "☦️", "🛐", "⛎", "♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓", "🆔", "⚛️", "🉑", "☢️", "☣️", "📴", "📳", "🈶", "🈚", "🈸", "🈺", "🈷️", "✴️", "🆚", "💮", "🉐", "㊙️", "㊗️", "🈴", "🈵", "🈹", "🈲", "🅰️", "🅱️", "🆎", "🆑", "🅾️", "🆘", "❌", "⭕", "🛑", "⛔", "📛", "🔞", "📵", "📶", "📈", "📉", "📊", "📋", "📌", "📍", "📎", "🖇️", "📏", "📐", "✂️", "🖊️", "🖋️", "✒️", "🖌️", "🖍️", "📝", "✏️", "🔍", "🔎", "🔏", "🔐", "🔒", "🔓"],
  },
  {
    titulo: "Bandeiras",
    icone: "🏳️",
    emojis: ["🏳️", "🏴", "🏁", "🚩", "🏳️‍🌈", "🏳️‍⚧️", "🇧🇷", "🇺🇸", "🇬🇧", "🇫🇷", "🇩🇪", "🇮🇹", "🇪🇸", "🇵🇹", "🇦🇷", "🇨🇱", "🇨🇴", "🇲🇽", "🇨🇦", "🇯🇵", "🇰🇷", "🇨🇳", "🇮🇳", "🇷🇺", "🇺🇦", "🇦🇺", "🇳🇿", "🇿🇦", "🇪🇬", "🇳🇬", "🇰🇪", "🇲🇦", "🇹🇷", "🇸🇦", "🇦🇪", "🇮🇱", "🇵🇸", "🇱🇧", "🇮🇶", "🇮🇷", "🇵🇰", "🇧🇩", "🇹🇭", "🇻🇳", "🇮🇩", "🇲🇾", "🇸🇬", "🇵🇭", "🇲🇲", "🇱🇦", "🇰🇭", "🇲🇳", "🇳🇵", "🇱🇰", "🇧🇹", "🇦🇫", "🇵🇱", "🇳🇱", "🇧🇪", "🇨🇭", "🇦🇹", "🇸🇪", "🇳🇴", "🇩🇰", "🇫🇮", "🇮🇸", "🇮🇪", "🇬🇷"],
  },
];

// Dicionário do conversor palavra -> emoji. As chaves já estão sem acento:
// "água" vira "agua" e "dragão" vira "dragao" antes da busca.
const DICIONARIO_PALAVRA_EMOJI: Record<string, string[]> = {
  fogo: ["🔥", "🌋", "✨", "☀️"],
  agua: ["💧", "🌊", "🌧️", "🧪"],
  terra: ["🌍", "🪨", "🌱", "🌋"],
  vento: ["💨", "🌪️", "🌬️", "☁️"],
  portal: ["🌀", "🚪", "✨", "🌌"],
  dragao: ["🐉", "🐲", "🔥", "🥚"],
  luffy: ["👒", "🍖", "🏴‍☠️", "😄"],
  san: ["🍳", "🧪", "💡", "👨‍🍳"],
  meg: ["🐶", "🐾", "🦴", "🐕"],
  espada: ["🗡️", "⚔️", "🔪", "🛡️"],
  escudo: ["🛡️", "🪖", "💎", "✨"],
  cristal: ["💎", "🔮", "✨", "💠"],
  pocao: ["🧪", "⚗️", "🍵", "✨"],
  trovao: ["⚡", "⛈️", "🌩️", "💥"],
  lava: ["🌋", "🔥", "🪨", "♨️"],
  onda: ["🌊", "💧", "🏄", "🐚"],
  sol: ["☀️", "🌞", "🔥", "⭐"],
  lua: ["🌙", "🌚", "⭐", "🌌"],
  estrela: ["⭐", "🌟", "✨", "💫"],
  coracao: ["❤️", "💛", "💖", "🫶"],
  carinho: ["❤️", "🫶", "🤗", "🥰"],
  raiva: ["😡", "🤬", "🔥", "💢"],
  flor: ["🌸", "🌻", "🌷", "🌿"],
  nuvem: ["☁️", "🌧️", "🌈", "💨"],
  chuva: ["🌧️", "💧", "☁️", "🌂"],
  pedra: ["🪨", "💎", "🌋", "⛰️"],
  magia: ["🪄", "🔮", "✨", "🌟"],
  tesouro: ["👑", "💎", "🗝️", "🎁"],
  ideia: ["💡", "✨", "🧪", "🌟"],
  amizade: ["💛", "🤝", "🫶", "💖"],
  pata: ["🐾", "🐶", "🦴", "🐕"],
  banho: ["🛁", "💧", "🫧", "🧼"],
  castelo: ["🏰", "🏯", "👑", "🗝️"],
  comida: ["🍕", "🍔", "🍩", "🍓"],
  gato: ["🐱", "🐾", "🐈", "😺"],
  cachorro: ["🐶", "🐾", "🦴", "🐕"],
};

function normalizarPalavra(palavra: string) {
  return palavra
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

export default function App() {
  const [abaLogin, setAbaLogin] = useState<"entrar" | "registrar">("entrar");
  const [nomeDigitado, setNomeDigitado] = useState("");
  const [senhaDigitada, setSenhaDigitada] = useState("");
  // Contas desta sessão, em memória (sem localStorage / sem banco).
  // { nome, senha, role } — role "ADM" só para o nome exato "san123".
  type Conta = { nome: string; senha: string; role: "ADM" | "Jogador" };
  const [contas, setContas] = useState<Conta[]>([]);
  const [usuario, setUsuario] = useState("");
  const [ehCriador, setEhCriador] = useState(false);
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [statusLogin, setStatusLogin] = useState("");
  const nomeRef = useRef<HTMLInputElement>(null);
  const [descobertos, setDescobertos] = useState<Elemento[]>(INICIAIS);
  const [busca, setBusca] = useState("");
  const [confirmarExcluir, setConfirmarExcluir] = useState<string | null>(null);
  function excluirElemento(nome: string) {
    setDescobertos((antigo) => antigo.filter((e) => e.nome !== nome));
    setCustomizados((antigo) => antigo.filter((e) => e.nome !== nome));
    setItensLousa((antigo) => antigo.filter((i) => i.nome !== nome));
    setConfirmarExcluir(null);
    setUltimaIA((atual) => (atual && atual.nome === nome ? null : atual));
    setMensagem(`Elemento ${nome} removido da coleção e da lousa.`);
  }
  function restaurarBase() {
    const faltando = INICIAIS.filter((base) => !descobertos.some((e) => e.nome === base.nome));
    if (!faltando.length) { setMensagem("A base já está completa: Água, Fogo, Vento, Terra, San e Meg já estão na coleção."); return; }
    setDescobertos((antigo) => [...antigo, ...faltando]);
    setMensagem(`Base restaurada: ${faltando.map((e) => `${e.emoji} ${e.nome}`).join(", ")} de volta na coleção.`);
  }
  type ItemLousa = { id: string; nome: string; emoji: string; x: number; y: number };
  const [itensLousa, setItensLousa] = useState<ItemLousa[]>([
    { id: "lousa-agua", nome: "Água", emoji: "💧", x: 18, y: 28 },
    { id: "lousa-fogo", nome: "Fogo", emoji: "🔥", x: 42, y: 28 },
    { id: "lousa-vento", nome: "Vento", emoji: "💨", x: 18, y: 62 },
    { id: "lousa-terra", nome: "Terra", emoji: "🌍", x: 42, y: 62 },
  ]);
  const [alvoLousa, setAlvoLousa] = useState<string | null>(null);
  const [foraLousa, setForaLousa] = useState<string | null>(null);
  const [lousaExpandida, setLousaExpandida] = useState(false);
  const [zoomLousa, setZoomLousa] = useState(1);
  const zoomLousaRef = useRef(1);
  useEffect(() => { zoomLousaRef.current = zoomLousa; }, [zoomLousa]);
  const lousaViewportRef = useRef<HTMLDivElement>(null);
  function ajustarZoom(proximo: number) {
    const limitado = Math.min(2, Math.max(0.5, Math.round(proximo * 100) / 100));
    setZoomLousa(limitado);
    setMensagem(`Zoom da Lousa: ${Math.round(limitado * 100)}%`);
  }
  function copiarItemSelecionado() {
    const selId = itemSelecionadoRef.current;
    if (!selId) { setMensagem("Toque em um elemento da Lousa para selecionar antes de copiar."); return; }
    const item = itensLousaRef.current.find((i) => i.id === selId);
    if (!item) return;
    clipboardLousaRef.current = { nome: item.nome, emoji: item.emoji };
    try {
      const area = document.createElement("textarea");
      area.value = `${item.emoji} ${item.nome}`; area.style.position = "fixed"; area.style.opacity = "0";
      document.body.appendChild(area); area.select();
      document.execCommand("copy"); document.body.removeChild(area);
    } catch { /* cópia interna já vale */ }
    setMensagem(`Copiado: ${item.emoji} ${item.nome} — agora use Colar.`);
  }
  function colarItemCopiado() {
    const copiado = clipboardLousaRef.current;
    if (!copiado) { setMensagem("Nada copiado ainda. Selecione um elemento e aperte Copiar."); return; }
    const pos = posMouseLousaRef.current || { x: 50, y: 50 };
    const id = `lousa-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    const novo = { id, nome: copiado.nome, emoji: copiado.emoji, x: pos.x, y: pos.y };
    setItensLousa((antigo) => [...antigo, { ...novo }]);
    setItemSelecionado(id);
    setMensagem(`Colado: ${copiado.emoji} ${copiado.nome}`);
  }
  function duplicarItemSelecionado() {
    const selId = itemSelecionadoRef.current;
    if (!selId) { setMensagem("Toque em um elemento da Lousa para selecionar antes de duplicar."); return; }
    const item = itensLousaRef.current.find((i) => i.id === selId);
    if (!item) return;
    const id = `lousa-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    const novo = { id, nome: item.nome, emoji: item.emoji, x: Math.min(92, item.x + 8), y: Math.min(90, item.y + 8) };
    setItensLousa((antigo) => [...antigo, { ...novo }]);
    setItemSelecionado(id);
    setMensagem(`Duplicado: ${item.emoji} ${item.nome}`);
  }
  function deletarItemSelecionado() {
    const selId = itemSelecionadoRef.current;
    if (!selId) { setMensagem("Toque em um elemento da Lousa para selecionar antes de deletar."); return; }
    const item = itensLousaRef.current.find((i) => i.id === selId);
    setItensLousa((antigo) => antigo.filter((i) => i.id !== selId));
    setItemSelecionado(null);
    if (item) setMensagem(`${item.emoji} ${item.nome} saiu da lousa.`);
  }
  const [itemSelecionado, setItemSelecionado] = useState<string | null>(null);
  const itemSelecionadoRef = useRef<string | null>(null);
  useEffect(() => { itemSelecionadoRef.current = itemSelecionado; }, [itemSelecionado]);
  const clipboardLousaRef = useRef<{ nome: string; emoji: string } | null>(null);
  const posMouseLousaRef = useRef<{ x: number; y: number } | null>(null);
  // Atalhos da lousa: só quando o foco NÃO está num campo de texto.
  useEffect(() => {
    function emCampo(e: KeyboardEvent) {
      const t = e.target as HTMLElement | null;
      return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable);
    }
    function onKey(e: KeyboardEvent) {
      if (emCampo(e)) return;
      const ctrl = e.ctrlKey || e.metaKey;
      const selId = itemSelecionadoRef.current;
      if (e.key === "Escape") { e.preventDefault(); setItemSelecionado(null); return; }
      if (ctrl && (e.key === "c" || e.key === "C")) {
        if (!selId) { setMensagem("Toque em um elemento da Lousa para selecionar antes de copiar."); return; }
        e.preventDefault();
        copiarItemSelecionado();
        return;
      }
      if (ctrl && (e.key === "v" || e.key === "V")) {
        if (!clipboardLousaRef.current) { setMensagem("Nada copiado ainda. Selecione um elemento e aperte Copiar."); return; }
        e.preventDefault();
        colarItemCopiado();
        return;
      }
      if (ctrl && (e.key === "d" || e.key === "D")) {
        if (!selId) { setMensagem("Toque em um elemento da Lousa para selecionar antes de duplicar."); return; }
        e.preventDefault();
        duplicarItemSelecionado();
        return;
      }
      if (e.key === "Delete" || e.key === "Backspace" || (ctrl && e.key === "Delete")) {
        if (!selId) { setMensagem("Toque em um elemento da Lousa para selecionar antes de deletar."); return; }
        e.preventDefault();
        deletarItemSelecionado();
        return;
      }
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);
  // Ctrl + rodinha do mouse dá zoom na Lousa sem dar zoom na página.
  useEffect(() => {
    const viewport = lousaViewportRef.current;
    if (!viewport) return;
    function onWheel(e: WheelEvent) {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      const passo = e.deltaY < 0 ? 0.25 : -0.25;
      const limitado = Math.min(2, Math.max(0.5, Math.round((zoomLousaRef.current + passo) * 100) / 100));
      setZoomLousa(limitado);
      setMensagem(`Zoom da Lousa: ${Math.round(limitado * 100)}%`);
    }
    viewport.addEventListener("wheel", onWheel, { passive: false });
    return () => viewport.removeEventListener("wheel", onWheel);
  }, []);
  // Se o item selecionado sumir (fusão, limpar, deletar), limpa a seleção.
  useEffect(() => {
    if (itemSelecionado && !itensLousa.some((i) => i.id === itemSelecionado)) setItemSelecionado(null);
  }, [itensLousa, itemSelecionado]);
  const lousaRef = useRef<HTMLDivElement>(null);
  // Espelho da lousa para os handlers de arraste lerem a posição atual
  // sem ficarem presos a um estado antigo.
  const itensLousaRef = useRef(itensLousa);
  useEffect(() => { itensLousaRef.current = itensLousa; }, [itensLousa]);
  // Arraste da lousa (mouse/caneta via Pointer Events, celular via Touch).
  // O arraste começa em qualquer parte do chip — emoji ou nome — e o
  // texto nunca é selecionável, para o clique não destacar a palavra.
  const arrasteRef = useRef<{ id: string; nome: string; emoji: string; pointerId?: number; touchId?: number; moveu: boolean; alvoId: string | null; inicioX: number; inicioY: number } | null>(null);
  const [log, setLog] = useState<string[]>(["Bem-vindo! Arraste dois elementos um sobre o outro na lousa para fundir."]);
  const [iaLigada, setIaLigada] = useState(true);
  const [modoAlucinatorio, setModoAlucinatorio] = useState(true);
  const [ultimaIA, setUltimaIA] = useState<ResultadoIA | null>(null);
  const [confete, setConfete] = useState(false);
  const [mensagem, setMensagem] = useState("");
  const [customizados, setCustomizados] = useState<Elemento[]>([]);
  const [nomeNovo, setNomeNovo] = useState("");
  const [emojiNovo, setEmojiNovo] = useState("✨");
  const [receitaA, setReceitaA] = useState("Água");
  const [receitaB, setReceitaB] = useState("Fogo");
  const [dicaNova, setDicaNova] = useState("");
  const [codigoPacote, setCodigoPacote] = useState("");
  const [codigoParaColar, setCodigoParaColar] = useState("");
  const [confirmarApagar, setConfirmarApagar] = useState(false);
  const [mostrarPicker, setMostrarPicker] = useState(false);
  const [categoriaEmoji, setCategoriaEmoji] = useState(0);
  const [paginaEmoji, setPaginaEmoji] = useState(0);
  const [palavraEmoji, setPalavraEmoji] = useState("");
  const [sugestoesEmoji, setSugestoesEmoji] = useState<string[]>([]);
  const [avisoConversor, setAvisoConversor] = useState("");
  const [mostrarEscolhaSaveLogin, setMostrarEscolhaSaveLogin] = useState(false);
  const [mostrarEscolhaSaveCaixa, setMostrarEscolhaSaveCaixa] = useState(false);
  const [aberturasSaveLogin, setAberturasSaveLogin] = useState(0);
  const [aberturasSaveCaixa, setAberturasSaveCaixa] = useState(0);
  const [tentativasEntrar, setTentativasEntrar] = useState(0);
  // Diário + slots vivem só nesta sessão: o pedido original pede 3 slots
  // com nome, mas não pede gravação permanente no navegador.
  const [diarioMinimizado, setDiarioMinimizado] = useState(false);
  type DadosSlot = { jogador: string; descobertos: Elemento[]; customizados: Elemento[]; log: string[]; itensLousa: ItemLousa[]; salvoEm: string };
  type SlotSave = { nome: string; save: DadosSlot | null };
  const [slotsSave, setSlotsSave] = useState<SlotSave[]>([
    { nome: "Slot 1", save: null },
    { nome: "Slot 2", save: null },
    { nome: "Slot 3", save: null },
  ]);
  function formatarDataSlot(iso: string) {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    const dd = String(d.getDate()).padStart(2, "0");
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const hh = String(d.getHours()).padStart(2, "0");
    const min = String(d.getMinutes()).padStart(2, "0");
    return `${dd}/${mm} ${hh}:${min}`;
  }
  function renomearSlot(indice: number, nome: string) {
    setSlotsSave((antigos) => antigos.map((s, i) => (i === indice ? { ...s, nome } : s)));
  }
  function salvarSlot(indice: number) {
    const nome = (slotsSave[indice]?.nome || `Slot ${indice + 1}`).trim() || `Slot ${indice + 1}`;
    const save: DadosSlot = { jogador: usuario, descobertos: [...descobertos], customizados: [...customizados], log: [...log], itensLousa: [...itensLousa], salvoEm: new Date().toISOString() };
    setSlotsSave((antigos) => antigos.map((s, i) => (i === indice ? { nome, save } : s)));
    setMensagem(`Save guardado em “${nome}”: ${descobertos.length} elementos • salvo em ${formatarDataSlot(save.salvoEm)}. Fica nesta sessão.`);
  }
  function carregarSlot(indice: number) {
    const slot = slotsSave[indice];
    if (!slot?.save) { setMensagem(`“${slot?.nome || `Slot ${indice + 1}`}” está vazio. Salve um jogo nele primeiro.`); return; }
    const save = slot.save;
    setDescobertos(save.descobertos);
    setCustomizados(save.customizados);
    setLog(save.log);
    setItensLousa(save.itensLousa);
    setUltimaIA(null);
    setBusca("");
    setAlvoLousa(null);
    setForaLousa(null);
    // Um save nunca libera ADM sozinho: só o login com Nome + Senha faz isso.
    if (save.jogador && save.jogador !== NOME_ADM) { setUsuario(save.jogador); setEhCriador(false); }
    setMensagem(`Save “${slot.nome}” carregado: ${save.descobertos.length} elementos • salvo em ${formatarDataSlot(save.salvoEm)}.`);
  }
  function apagarSlot(indice: number) {
    const slot = slotsSave[indice];
    if (!slot?.save) { setMensagem(`“${slot?.nome || `Slot ${indice + 1}`}” já está vazio.`); return; }
    setSlotsSave((antigos) => antigos.map((s, i) => (i === indice ? { ...s, save: null } : s)));
    setMensagem(`Save “${slot.nome}” apagado. O slot ficou vazio, mas o nome foi mantido.`);
  }
  const arquivoRef = useRef<HTMLInputElement>(null);
  const arquivoPacoteRef = useRef<HTMLInputElement>(null);
  // Contadores síncronos: cada ativação (pointerdown ou click) precisa
  // gerar uma mensagem diferente, mesmo quando o React agrupa dois
  // cliques seguidos. Sem isso, a segunda ativação parece não responder.
  const tentativasRef = useRef(0);
  const aberturasLoginRef = useRef(0);
  const aberturasCaixaRef = useRef(0);
  const [avisoSaveCaixa, setAvisoSaveCaixa] = useState("");
  // Guarda a última ativação por botão: um clique real dispara pointerdown
  // e depois click; o teste sintético pode disparar só um deles. Sem a
  // guarda, o mesmo clique executaria a ação duas vezes (ex.: abrir e
  // fechar a escolha de save).
  const ultimaAcaoRef = useRef<Record<string, number>>({});
  function executarUmaVez(chaveAcao: string, acao: () => void) {
    const agora = Date.now();
    if (agora - (ultimaAcaoRef.current[chaveAcao] || 0) < 800) return;
    ultimaAcaoRef.current[chaveAcao] = agora;
    acao();
  }

  function escolherEmoji(emoji: string) {
    setEmojiNovo(emoji);
    setMensagem(`Emoji escolhido: ${emoji} — agora é só terminar o elemento e apertar Adicionar Elemento.`);
  }

  function trocarCategoriaEmoji(indice: number) {
    setCategoriaEmoji(indice);
    setPaginaEmoji(0);
  }

  // Página atual do teclado: exatamente 10 emojis, em grade 5x2.
  const categoriaAtualEmoji = CATEGORIAS_EMOJI[categoriaEmoji];
  const totalPaginasEmoji = Math.max(1, Math.ceil(categoriaAtualEmoji.emojis.length / EMOJIS_POR_PAGINA));
  const paginaSeguraEmoji = Math.min(paginaEmoji, totalPaginasEmoji - 1);
  const emojisPaginaAtual = categoriaAtualEmoji.emojis.slice(
    paginaSeguraEmoji * EMOJIS_POR_PAGINA,
    paginaSeguraEmoji * EMOJIS_POR_PAGINA + EMOJIS_POR_PAGINA,
  );

  function converterPalavra() {
    const palavra = normalizarPalavra(palavraEmoji);
    if (!palavra) {
      setSugestoesEmoji([]);
      setAvisoConversor("Digite uma palavra primeiro, ex.: fogo, portal, dragão, água.");
      return;
    }
    const exata = DICIONARIO_PALAVRA_EMOJI[palavra];
    if (exata) {
      setSugestoesEmoji(exata);
      setAvisoConversor(`Sugestões para “${palavraEmoji.trim()}”. Toque em uma para usar no campo Emoji.`);
      return;
    }
    // Busca parcial: "foguinho" encontra "fogo", "portalzinho" encontra "portal".
    const parcial = Object.keys(DICIONARIO_PALAVRA_EMOJI).find(
      (chaveDicionario) => palavra.includes(chaveDicionario) || chaveDicionario.includes(palavra),
    );
    if (parcial) {
      setSugestoesEmoji(DICIONARIO_PALAVRA_EMOJI[parcial]);
      setAvisoConversor(`Não achei “${palavraEmoji.trim()}” exato, mas achei parecido com “${parcial}”.`);
      return;
    }
    setSugestoesEmoji(["✨", "🌟", "🔮", "💫"]);
    setAvisoConversor(`Ainda não tenho “${palavraEmoji.trim()}” no dicionário. Que tal uma dessas? Ou escolha na tabela abaixo.`);
  }

  const todos = useMemo(() => {
    const mapa = new Map<string, Elemento>();
    [...descobertos, ...customizados].forEach((e) => mapa.set(e.nome, e));
    return Array.from(mapa.values());
  }, [descobertos, customizados]);

  // Cada elemento em "Seus Elementos" conta para o progresso — incluindo os
  // elementos adicionados pelo Criador, que também entram em descobertos.
  const progressoBase = descobertos.length;

  function entrar() {
    const nome = nomeDigitado.trim();
    if (!nome) {
      tentativasRef.current += 1;
      const tentativa = tentativasRef.current;
      setTentativasEntrar(tentativa);
      setMensagem(`Digite seu Nome para entrar. Tentativa ${tentativa}.`);
      setStatusLogin(`Digite seu Nome para entrar. Tentativa ${tentativa}.`);
      nomeRef.current?.focus();
      return;
    }
    if (!senhaDigitada) {
      setMensagem("Digite sua Senha para entrar.");
      setStatusLogin("Digite sua Senha para entrar.");
      return;
    }
    const conta = contas.find((c) => c.nome === nome);
    if (!conta) {
      setMensagem(`Conta “${nome}” não encontrada nesta sessão. Vá em Registrar e crie sua conta.`);
      setStatusLogin(`Conta “${nome}” não encontrada. Vá em Registrar e crie sua conta.`);
      return;
    }
    if (conta.senha !== senhaDigitada) {
      setMensagem("Senha incorreta. Confira e tente de novo.");
      setStatusLogin("Senha incorreta. Confira e tente de novo.");
      return;
    }
    tentativasRef.current = 0;
    setTentativasEntrar(0);
    setUsuario(nome);
    setEhCriador(conta.role === "ADM");
    setSenhaDigitada("");
    setStatusLogin(`Olá, ${nome}! Bem-vindo de volta.`);
    setMensagem(`Olá, ${nome}! Bem-vindo de volta.`);
  }
  function registrar() {
    const nome = nomeDigitado.trim();
    if (!nome) { setMensagem("Digite um Nome para criar sua conta."); setStatusLogin("Digite um Nome para criar sua conta."); nomeRef.current?.focus(); return; }
    if (!senhaDigitada) { setMensagem("Digite uma Senha para criar sua conta."); setStatusLogin("Digite uma Senha para criar sua conta."); return; }
    if (contas.some((c) => c.nome === nome)) { setMensagem(`A conta “${nome}” já existe. Vá em Entrar e use sua senha.`); setStatusLogin(`A conta “${nome}” já existe. Vá em Entrar.`); return; }
    const role: "ADM" | "Jogador" = nome === NOME_ADM ? "ADM" : "Jogador";
    setContas((antigas) => [...antigas, { nome, senha: senhaDigitada, role }]);
    setUsuario(nome);
    setEhCriador(role === "ADM");
    setSenhaDigitada("");
    setStatusLogin(`Conta criada! Olá, ${nome}! Bem-vindo.`);
    setMensagem(`Conta criada! Olá, ${nome}! Bem-vindo.`);
  }
  function entrarComoVisitante() {
    setUsuario("Visitante");
    setEhCriador(false);
    setSenhaDigitada("");
    setStatusLogin("Jogando como Visitante — só para testar.");
    setMensagem("Jogando como Visitante — só para testar.");
  }

  function abrirCarregarSave() {
    // Sempre abre (não alterna) e o contador sobe a cada ativação,
    // inclusive pointerdown seguida de click.
    aberturasLoginRef.current += 1;
    const proxima = aberturasLoginRef.current;
    setAberturasSaveLogin(proxima);
    setMostrarEscolhaSaveLogin(true);
    setStatusLogin(`Escolha o arquivo do save para carregar. (aberto ${proxima}×)`);
    setMensagem(`Escolha o arquivo do save para carregar. (aberto ${proxima}×)`);
  }
  function abrirCarregarSaveCaixa() {
    aberturasCaixaRef.current += 1;
    const proxima = aberturasCaixaRef.current;
    setAberturasSaveCaixa(proxima);
    setMostrarEscolhaSaveCaixa(true);
    setAvisoSaveCaixa(`Escolha o arquivo do save para carregar. (aberto ${proxima}×)`);
    setStatusLogin(`Escolha o arquivo do save para carregar. (aberto ${proxima}×)`);
    setMensagem(`Escolha o arquivo do save para carregar. (aberto ${proxima}×)`);
  }

  function sair() {
    setUsuario("");
    setEhCriador(false);
    setNomeDigitado("");
    setSenhaDigitada("");
    setMostrarSenha(false);
    setStatusLogin("");
    setMensagem("Você saiu. Entre de novo quando quiser.");
  }

  function adicionarLog(texto: string) {
    setLog((antigo) => [texto, ...antigo].slice(0, 30));
  }

  function celebrar() {
    setConfete(true);
    window.setTimeout(() => setConfete(false), 1800);
  }

  // Lógica da fusão: receita do San → curada → IA (predominância de universo).
  function combinarNomes(nomeA: string, nomeB: string, aoCriar?: (novo: Elemento) => void) {
    if (!usuario && !ehCriador) { setMensagem("Entre com Nome + Senha (ou jogue como Visitante) antes de combinar."); return; }
    if (!nomeA || !nomeB) { setMensagem("Escolha dois elementos."); return; }
    const a = todos.find((e) => e.nome === nomeA);
    const b = todos.find((e) => e.nome === nomeB);
    if (!a || !b) return;
    const k = chave(a.nome, b.nome);
    // Ordem: receita do Criador → receita curada da IA (vida real / cultura) → receita base.
    // A receita curada cobre as bases com o mesmo nome, mas já com categoria + motivo.
    const curada = CURATED_COMBOS[k];
    const base = curada
      ? { nome: curada.nome, emoji: curada.emoji, dica: curada.motivo, categoria: curada.categoria, motivo: curada.motivo }
      : RECEITAS_BASE[k];
    const doSan = customizados.find((e) => e.receita === k);

    // O Pacote do San tem prioridade quando existe para esta dupla.
    const jaTemSan = doSan ? descobertos.some((e) => e.nome === doSan.nome) : false;
    const jaTemBase = base ? descobertos.some((e) => e.nome === base.nome) : false;
    if (jaTemSan || (jaTemBase && !doSan)) {
      const nome = doSan?.nome || base?.nome;
      adicionarLog(`${a.emoji} + ${b.emoji} = ${nome} — você já tinha!`);
      // Na lousa, fundir de novo ainda mostra o resultado: as fontes somem
      // e o elemento já conhecido nasce no ponto da fusão.
      const existente = todos.find((e) => e.nome === nome);
      if (existente) {
        if (base && !doSan) {
          const meta = metadadosDe({ nome: existente.nome, emoji: existente.emoji, dica: existente.dica, categoria: existente.categoria });
          setUltimaIA({ nome: existente.nome, emoji: existente.emoji, categoria: (existente.categoria as CategoriaIA) || "Vida Real", motivo: curada ? curada.motivo : `Porque ${a.nome} + ${b.nome} criam ${existente.nome} na vida real.`, universo: existente.universo || meta.universo, tags: existente.tags || meta.tags, dicionario: curada?.dicionario || dicionarioDe(existente.nome)?.dicionario, significado: curada?.significado || dicionarioDe(existente.nome)?.significado });
        }
        setMensagem(`IA Criou: ${existente.emoji} ${existente.nome} • Universo: ${existente.universo || "Neutro"}`);
        aoCriar?.(existente);
        celebrar();
      } else {
        setMensagem(`Você já tem ${nome}. Tente outra dupla.`);
      }
      return;
    }

    if (doSan) {
      setUltimaIA(null);
      setDescobertos((antigo) => [...antigo, doSan]);
      adicionarLog(`🎉 ${a.emoji} + ${b.emoji} = ${doSan.emoji} ${doSan.nome} (Pacote do San)!`);
      setMensagem(`Você achou um elemento secreto: ${doSan.emoji} ${doSan.nome}!`);
      aoCriar?.(doSan);
      celebrar(); return;
    }
    if (base) {
      const metaBase = metadadosDe({ nome: base.nome, emoji: base.emoji, dica: base.dica, categoria: base.categoria });
      const resultadoIA: ResultadoIA = curada
        ? { ...curada, universo: curada.universo || metaBase.universo, tags: curada.tags || metaBase.tags, motivo: `Porque ${a.nome} é do universo ${metadadosDe(a).universo} e ${b.nome} é do universo ${metadadosDe(b).universo}, a receita exata manda: ${curada.motivo}` }
        : { nome: limitarNomeIA(base.nome), emoji: base.emoji, categoria: "Vida Real", universo: metaBase.universo, tags: metaBase.tags, motivo: `Porque ${a.nome} + ${b.nome} criam ${base.nome} na vida real.` };
      setUltimaIA(resultadoIA);
      const novoBase: Elemento = { ...base, universo: resultadoIA.universo, tags: resultadoIA.tags };
      setDescobertos((antigo) => [...antigo, novoBase]);
      adicionarLog(`🎉 ${a.emoji} + ${b.emoji} = ${base.emoji} ${base.nome}! Universo: ${resultadoIA.universo}. Categoria: ${resultadoIA.categoria}.`);
      setMensagem(`Nova descoberta: ${base.emoji} ${base.nome}! Universo: ${resultadoIA.universo}. Categoria: ${resultadoIA.categoria}.`);
      aoCriar?.(novoBase);
      celebrar(); return;
    }
    if (!iaLigada) {
      adicionarLog(`Nada aconteceu com ${a.nome} + ${b.nome}.`);
      setMensagem("Nada aconteceu. Ligue a IA ou tente outra combinação.");
      return;
    }
    // Dupla sem receita: pool temático por insumo (fogo, água, Meg, San...)
    // Nunca "Mistura de...": sempre 1 emoji + 1 nome, até 70 caracteres.
    // Se nada existente fizer sentido, criarOriginal() inventa algo novo e plausível.
    const resultadoBruto = gerarIA(a, b, (nome) => descobertos.some((e) => e.nome === nome), modoAlucinatorio);
    // Defesa final +18: nunca deixa um nome bloqueado chegar à coleção.
    const resultado = conteudoProibido18(resultadoBruto.nome)
      ? { ...resultadoBruto, nome: "Invenção Segura", motivo: "O nome gerado foi bloqueado pelo filtro de segurança e trocado por uma alternativa segura." }
      : resultadoBruto;
    const novo: Elemento = {
      nome: limitarNomeIA(resultado.nome),
      emoji: resultado.emoji,
      dica: resultado.motivo,
      categoria: resultado.categoria,
      universo: resultado.universo,
      tags: resultado.tags,
      motivo: resultado.motivo,
      receita: k,
    };
    if (descobertos.some((e) => e.nome === novo.nome)) {
      const existente = todos.find((x) => x.nome === novo.nome);
      if (existente) { setMensagem(`${existente.emoji} ${existente.nome} já está na sua coleção.`); aoCriar?.(existente); celebrar(); }
      else setMensagem(`Você já tem ${novo.nome}. Tente outra dupla.`);
      return;
    }
    setUltimaIA(resultado);
    setDescobertos((antigo) => [...antigo, novo]);
    if (resultado.original) {
      adicionarLog(`✨ ${a.emoji} + ${b.emoji} = ${novo.emoji} ${novo.nome}! Criação Original — nunca visto, mas faz sentido.`);
      setMensagem(`Criação Original: ${novo.emoji} ${novo.nome}! Nunca visto, mas faz sentido.`);
    } else {
      adicionarLog(`🤖 ${a.emoji} + ${b.emoji} = ${novo.emoji} ${novo.nome}! Universo: ${resultado.universo}. Categoria: ${resultado.categoria}.`);
      setMensagem(`A IA inventou: ${novo.emoji} ${novo.nome}! Universo: ${resultado.universo}. Categoria: ${resultado.categoria}.`);
    }
    aoCriar?.(novo);
    celebrar();
  }
  function posicaoNaLousa(clientX: number, clientY: number) {
    const rect = lousaRef.current?.getBoundingClientRect();
    if (!rect) return { x: 50, y: 50 };
    return { x: Math.min(92, Math.max(8, ((clientX - rect.left) / rect.width) * 100)), y: Math.min(90, Math.max(10, ((clientY - rect.top) / rect.height) * 100)) };
  }
  // Alvo generoso: a até 60px do centro de outro item já conta como fusão.
  function alvoProximo(pos: { x: number; y: number }, excluirId: string): ItemLousa | null {
    const rect = lousaRef.current?.getBoundingClientRect();
    if (!rect) return null;
    const px = (pos.x / 100) * rect.width;
    const py = (pos.y / 100) * rect.height;
    let melhor: ItemLousa | null = null;
    let menor = Infinity;
    for (const item of itensLousaRef.current) {
      if (item.id === excluirId) continue;
      const dx = (item.x / 100) * rect.width - px;
      const dy = (item.y / 100) * rect.height - py;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist <= 60 && dist < menor) { menor = dist; melhor = item; }
    }
    return melhor;
  }
  function adicionarNaLousa(elemento: Elemento, pos?: { x: number; y: number }) {
    const p = pos || { x: 20 + Math.random() * 55, y: 20 + Math.random() * 55 };
    setItensLousa((antigo) => [...antigo, { id: `lousa-${Date.now()}-${Math.floor(Math.random() * 10000)}`, nome: elemento.nome, emoji: elemento.emoji, x: p.x, y: p.y }]);
  }
  function combinarNaLousa(idA: string, idB: string, pos: { x: number; y: number }) {
    const itemA = itensLousaRef.current.find((i) => i.id === idA);
    const itemB = itensLousaRef.current.find((i) => i.id === idB);
    if (!itemA || !itemB || idA === idB) return;
    const meio = { x: (itemA.x + itemB.x) / 2, y: (itemA.y + itemB.y) / 2 };
    const destino = pos || meio;
    combinarNomes(itemA.nome, itemB.nome, (novo) => {
      // Toast da fusão: nome + emoji, sem banner.
      setMensagem(`${novo.emoji} ${novo.nome} na lousa.`);
      setItensLousa((antigo) => [...antigo.filter((i) => i.id !== idA && i.id !== idB), { id: `lousa-${Date.now()}`, nome: novo.nome, emoji: novo.emoji, x: destino.x, y: destino.y }]);
    });
  }
  function combinarColecaoNaLousa(nomeColecao: string, idAlvo: string, pos: { x: number; y: number }) {
    const alvo = itensLousaRef.current.find((i) => i.id === idAlvo);
    if (!alvo || nomeColecao === alvo.nome) return;
    const meio = { x: (pos.x + alvo.x) / 2, y: (pos.y + alvo.y) / 2 };
    combinarNomes(nomeColecao, alvo.nome, (novo) => {
      setMensagem(`${novo.emoji} ${novo.nome} na lousa.`);
      setItensLousa((antigo) => [...antigo.filter((i) => i.id !== idAlvo), { id: `lousa-${Date.now()}`, nome: novo.nome, emoji: novo.emoji, x: meio.x, y: meio.y }]);
    });
  }
  // --- Arraste da lousa: Pointer (mouse/caneta) ---
  function iniciarArrasteLousa(item: ItemLousa, pointerId?: number, clientX = 0, clientY = 0) {
    arrasteRef.current = { id: item.id, nome: item.nome, emoji: item.emoji, pointerId, moveu: false, alvoId: null, inicioX: clientX, inicioY: clientY };
  }
  function estaForaDaLousa(clientX: number, clientY: number) {
    const rect = lousaRef.current?.getBoundingClientRect();
    if (!rect) return false;
    // Pequena tolerância para não apagar um item solto exatamente na borda.
    return clientX < rect.left - 4 || clientX > rect.right + 4 || clientY < rect.top - 4 || clientY > rect.bottom + 4;
  }
  function moverArrasteLousa(clientX: number, clientY: number) {
    const arraste = arrasteRef.current;
    if (!arraste) return;
    if (Math.hypot(clientX - arraste.inicioX, clientY - arraste.inicioY) > 6) arraste.moveu = true;
    if (!arraste.moveu) return;
    const fora = estaForaDaLousa(clientX, clientY);
    setForaLousa(fora ? arraste.id : null);
    if (fora) { setAlvoLousa(null); arraste.alvoId = null; return; }
    const pos = posicaoNaLousa(clientX, clientY);
    setItensLousa((antigo) => antigo.map((i) => i.id === arraste.id ? { ...i, x: pos.x, y: pos.y } : i));
    const alvo = alvoProximo(pos, arraste.id);
    arraste.alvoId = alvo ? alvo.id : null;
    setAlvoLousa(alvo ? alvo.id : null);
  }
  function terminarArrasteLousa(clientX: number, clientY: number) {
    const arraste = arrasteRef.current;
    arrasteRef.current = null;
    setAlvoLousa(null);
    setForaLousa(null);
    if (!arraste) return;
    // Clique sem arrastar = selecionar / desselecionar (atalhos Ctrl+C/V/D/Del).
    if (!arraste.moveu) {
      const jaSelecionado = itemSelecionadoRef.current === arraste.id;
      setItemSelecionado(jaSelecionado ? null : arraste.id);
      if (!jaSelecionado) setMensagem(`Selecionado: ${arraste.emoji} ${arraste.nome} — use Copiar, Duplicar ou Deletar.`);
      return;
    }
    // Soltou fora da lousa: o item some da lousa, sem confirmação.
    // A coleção não muda — o elemento continua em "Seus Elementos".
    if (estaForaDaLousa(clientX, clientY)) {
      setItensLousa((antigo) => antigo.filter((i) => i.id !== arraste.id));
      setMensagem(`${arraste.emoji} ${arraste.nome} saiu da lousa.`);
      return;
    }
    const pos = posicaoNaLousa(clientX, clientY);
    const alvo = alvoProximo(pos, arraste.id) || (arraste.alvoId ? itensLousaRef.current.find((i) => i.id === arraste.alvoId) || null : null);
    if (alvo) combinarNaLousa(arraste.id, alvo.id, { x: (pos.x + alvo.x) / 2, y: (pos.y + alvo.y) / 2 });
  }
  function limparLousa() { setItensLousa([]); setAlvoLousa(null); setForaLousa(null); setMensagem("Lousa limpa. Arraste elementos da coleção para começar de novo."); }

  function criarElementoSan() {
    const nome = nomeNovo.trim();
    if (!nome) { setMensagem("Dê um nome para o elemento secreto."); return; }
    if (conteudoProibido18(nome) || conteudoProibido18(dicaNova)) { setMensagem("Esse nome ou dica foi bloqueado pelo filtro de segurança. Escolha uma alternativa sem conteúdo +18."); return; }
    if (todos.some((e) => normalizar(e.nome) === normalizar(nome))) { setMensagem("Já existe um elemento com esse nome."); return; }
    const novo: Elemento = { nome, emoji: emojiNovo.trim() || "✨", dica: dicaNova.trim() || `Segredo: ${receitaA} + ${receitaB}.`, receita: chave(receitaA, receitaB) };
    setCustomizados((antigo) => [...antigo, novo]);
    // O elemento novo entra na coleção visível e conta no progresso.
    setDescobertos((antigo) => (antigo.some((e) => e.nome === novo.nome) ? antigo : [...antigo, novo]));
    setNomeNovo(""); setDicaNova(""); setEmojiNovo("✨");
    setMensagem(`Elemento adicionado: ${novo.emoji} ${novo.nome}! Ele já está em Seus Elementos.`);
    adicionarLog(`🧪 Criador criou um elemento secreto: ${novo.emoji} ${novo.nome}.`);
  }

  function removerCustomizado(nome: string) {
    setCustomizados((antigo) => antigo.filter((e) => e.nome !== nome));
    setDescobertos((antigo) => antigo.filter((e) => e.nome !== nome));
    setMensagem(`Elemento ${nome} removido.`);
  }

  function exportarPacote() {
    if (!customizados.length) { setMensagem("Crie pelo menos um elemento secreto antes de exportar."); return; }
    const codigo = JSON.stringify({ pacote: "San Craft", elementos: customizados }, null, 2);
    setCodigoPacote(codigo);
    setMensagem("Pacote pronto abaixo. Copie e mande para seus amigos.");
  }

  function copiarPacote() {
    const area = document.getElementById("codigo-pacote") as HTMLTextAreaElement | null;
    if (!area) return;
    area.select();
    document.execCommand("copy");
    setMensagem("Pacote copiado! Agora é só colar para outra pessoa.");
  }

  function carregarPacoteTexto() {
    try {
      const dados = JSON.parse(codigoParaColar);
      const lista = Array.isArray(dados) ? dados : dados.elementos;
      if (!Array.isArray(lista) || !lista.length) throw new Error("vazio");
      const validos = lista.filter((e) => e?.nome && e?.emoji && e?.receita && !conteudoProibido18(e.nome) && !conteudoProibido18(e.dica || "")) as Elemento[];
      if (!validos.length) throw new Error("inválido");
      const novos = validos.filter((e) => !customizados.some((c) => c.nome === e.nome));
      setCustomizados((antigo) => [...antigo, ...novos]);
      setCodigoParaColar("");
      setMensagem(`${novos.length} elemento(s) do Pacote do San carregados. Combine as receitas para revelar!`);
      adicionarLog(`📦 Pacote do San carregado com ${novos.length} elemento(s) secreto(s).`);
    } catch {
      setMensagem("Esse código não parece um Pacote do San. Confira e tente de novo.");
    }
  }

  function baixarSave() {
    const dados = { jogador: usuario, descobertos, customizados, log: log.slice(0, 10), itensLousa, salvoEm: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(dados, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "san-craft-save.json"; a.click();
    URL.revokeObjectURL(url);
    setMensagem("Save baixado. Ele fica no seu computador — nada vai para a internet.");
  }

  function carregarArquivoSave(arquivo: File | undefined, modo: "save" | "pacote") {
    if (!arquivo) return;
    const leitor = new FileReader();
    leitor.onload = () => {
      try {
        const dados = JSON.parse(String(leitor.result));
        if (modo === "save") {
          if (Array.isArray(dados.descobertos)) setDescobertos(dados.descobertos);
          if (Array.isArray(dados.customizados)) setCustomizados(dados.customizados);
          if (Array.isArray(dados.log)) setLog(dados.log);
          if (Array.isArray(dados.itensLousa)) setItensLousa(dados.itensLousa);
          // Um save nunca libera ADM. O ADM sempre entra com Nome + Senha.
          if (dados.jogador && dados.jogador !== NOME_ADM) { setUsuario(dados.jogador); setEhCriador(false); }
          setStatusLogin("Save carregado! Você já pode combinar.");
          setMensagem("Save carregado nesta aba. Lembre-se: ele não fica salvo no navegador depois de fechar.");
        } else {
          const lista = Array.isArray(dados) ? dados : dados.elementos;
          setCustomizados((antigo) => [...antigo, ...lista.filter((e: Elemento) => e?.nome && e?.receita && !antigo.some((c) => c.nome === e.nome))]);
          setMensagem("Pacote carregado do arquivo.");
        }
      } catch {
        setStatusLogin("Não consegui ler esse arquivo. Confira se é um save do San Craft.");
        setMensagem("Não consegui ler esse arquivo. Confira se é um save do San Craft.");
      }
    };
    leitor.readAsText(arquivo);
  }

  function apagarSave() {
    if (!confirmarApagar) { setConfirmarApagar(true); setMensagem("Aperte Apagar Save de novo para confirmar."); return; }
    setDescobertos(INICIAIS); setCustomizados([]); setLog(["Save apagado nesta aba. Comece de novo!"]); setConfirmarApagar(false); setUltimaIA(null); setBusca(""); setAlvoLousa(null);
    setItensLousa([{ id: "lousa-agua", nome: "Água", emoji: "💧", x: 18, y: 28 }, { id: "lousa-fogo", nome: "Fogo", emoji: "🔥", x: 42, y: 28 }, { id: "lousa-vento", nome: "Vento", emoji: "💨", x: 18, y: 62 }, { id: "lousa-terra", nome: "Terra", emoji: "🌍", x: 42, y: 62 }]);
    setMensagem("Save apagado. Você voltou para os 6 elementos iniciais.");
  }

  // Buscar por emoji, palavra ou sílaba — sem mínimo de letras.
  // Ex.: "🌸" casa com o emoji; "tartaruga"/"tar" casa com a palavra;
  // "ta" casa com a sílaba de Tartaruga, Pata Molhada e Montanha;
  // "sa" casa com Sakura e San. Tudo sem acento e sem diferenciar maiúsculas.
  function silabasDe(nome: string): string[] {
    const junto = normalizarPalavra(nome).replace(/[^a-z0-9]+/g, "");
    const partes = junto.match(/[^aeiou0-9]*[aeiou]+[^aeiou0-9]*/g);
    return partes || (junto ? [junto] : []);
  }
  const buscaCrua = busca.trim();
  const buscaNormalizada = normalizarPalavra(buscaCrua);
  const elementosFiltrados = descobertos.filter((e) => {
    if (!buscaCrua) return true;
    // Emoji: o texto digitado aparece no emoji do elemento (ex.: 🌸, 🐶).
    if (e.emoji && e.emoji.includes(buscaCrua)) return true;
    if (!buscaNormalizada) return true;
    const nomeNormalizado = normalizarPalavra(e.nome);
    // Palavra / substring: "tartaruga", "tar", "sakura" e "sa" já casam aqui.
    if (nomeNormalizado.includes(buscaNormalizada)) return true;
    if ((e.tags || []).some((t) => normalizarPalavra(t).includes(buscaNormalizada))) return true;
    // Sílaba: divide o nome em sílabas (tar-tu-ru-ga, sa-ku-ra) e casa
    // quando a busca está dentro de uma sílaba ou é uma sílaba inteira.
    if (silabasDe(e.nome).some((s) => s.includes(buscaNormalizada) || (buscaNormalizada.length >= 2 && buscaNormalizada.includes(s)))) return true;
    return false;
  });

  return (
    <div data-safe-area-inset-root className="shell" style={{boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)'}}>
      <header className="topo">
        <div>
          <h1>🧪 San Craft</h1>
          <p>Combine, descubra e invente seu próprio universo de elementos! ❤️</p>
        </div>
        <div className="badge">Dicionário PT-BR primeiro • {DICIONARIO_PT_BR.length + DICIONARIO_MUNDO.length} palavras</div>
      </header>

      <div className="toast" role="status" aria-live="polite" style={{ visibility: mensagem ? "visible" : "hidden" }}>{mensagem ? `✨ ${mensagem}` : " "}</div>

      {confete && <div className="confete" aria-hidden="true">{Array.from({ length: 28 }).map((_, i) => <span key={i} style={{ left: `${(i * 37) % 100}%`, background: ["#00f0ff", "#ff00ff", "#ffff00", "#00ff88"][i % 4], animationDelay: `${(i % 7) * 0.08}s` }}>•</span>)}</div>}

      <main className="layout">
        <div className="linha-criacao">
        <section className="lousa-topo" aria-label="Lousa">
          <div className="combinar lousa-wrap">
            <div className="lousa-cabecalho">
              <div><h2>Lousa</h2><p className="lousa-sub">Arraste um sobre o outro pra fundir</p><p className="mini">Modo Alucinatório ON: símbolos, números e palavras do mundo (ex.: 龍 Dragão, 7 Mares, Área 51). OFF: dicionário primeiro e mesma dupla = mesmo resultado. Filtro +18 sempre ligado.</p></div>
              <div className="zoom-controles" aria-label="Controles de zoom da Lousa">
                <button type="button" onClick={() => ajustarZoom(zoomLousa - 0.25)} disabled={zoomLousa <= 0.5} aria-label="Diminuir zoom da Lousa">−</button>
                <span className="zoom-valor" aria-live="polite">{Math.round(zoomLousa * 100)}%</span>
                <button type="button" onClick={() => ajustarZoom(zoomLousa + 0.25)} disabled={zoomLousa >= 2} aria-label="Aumentar zoom da Lousa">+</button>
                <button type="button" onClick={() => ajustarZoom(1)}>Reset</button>
                <button type="button" className="expandir-lousa" aria-expanded={lousaExpandida} onClick={() => setLousaExpandida((a) => !a)}>{lousaExpandida ? "Recolher Lousa" : "Expandir / Recolher Lousa"}</button>
              </div>
            </div>
            {itemSelecionado && (() => { const sel = itensLousa.find((i) => i.id === itemSelecionado); return sel ? (
              <div className="lousa-toolbar" role="toolbar" aria-label={`Selecionado: ${sel.emoji} ${sel.nome}`}>
                <strong>{sel.emoji} {sel.nome}</strong>
                <button type="button" onClick={copiarItemSelecionado}>📋 Copiar</button>
                <button type="button" onClick={colarItemCopiado} disabled={!clipboardLousaRef.current}>📌 Colar</button>
                <button type="button" onClick={duplicarItemSelecionado}>➕ Duplicar</button>
                <button type="button" className="perigo" onClick={deletarItemSelecionado}>🗑️ Deletar</button>
                <button type="button" onClick={() => setItemSelecionado(null)}>Fechar</button>
              </div>
            ) : null; })()}
            <div ref={lousaViewportRef} className={`lousa-viewport${lousaExpandida ? " expandida" : ""}`} style={{ height: `${(lousaExpandida ? 900 : 700) * zoomLousa}px` }}>
            <div ref={lousaRef} className={itensLousa.length ? "lousa" : "lousa vazia"} style={{ transform: `scale(${zoomLousa})`, minHeight: lousaExpandida ? 900 : 700 }} role="region" aria-label="Lousa - arraste dois elementos um sobre o outro pra combinar"
              onMouseMove={(e) => { posMouseLousaRef.current = posicaoNaLousa(e.clientX, e.clientY); }}
              onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = "copy"; }}
              onDrop={(e) => {
                e.preventDefault(); setAlvoLousa(null);
                const nome = e.dataTransfer.getData("san-craft/elemento") || e.dataTransfer.getData("text/plain");
                const pos = posicaoNaLousa(e.clientX, e.clientY);
                const elemento = todos.find((x) => x.nome === nome);
                if (!elemento) return;
                const alvo = alvoProximo(pos, "");
                if (alvo && alvo.nome !== nome) { combinarColecaoNaLousa(nome, alvo.id, pos); return; }
                adicionarNaLousa(elemento, pos);
              }}>
              {itensLousa.map((item) => (
                <div key={item.id} role="button" tabIndex={0} aria-pressed={itemSelecionado === item.id} className={`lousa-item${itemSelecionado === item.id ? " selecionado" : ""}${alvoLousa === item.id ? " alvo" : ""}${foraLousa === item.id ? " fora" : ""}`} style={{ left: `${item.x}%`, top: `${item.y}%` }}
                  title={`${item.emoji} ${item.nome} — arraste para fundir com outro, ou arraste para fora da lousa para remover.`}
                  onPointerDown={(e) => { if (e.pointerType === "touch") return; if (e.button !== 0) return; e.preventDefault(); iniciarArrasteLousa(item, e.pointerId, e.clientX, e.clientY); try { e.currentTarget.setPointerCapture(e.pointerId); } catch {} }}
                  onPointerMove={(e) => { if (e.pointerType === "touch") return; if (arrasteRef.current?.pointerId === e.pointerId) moverArrasteLousa(e.clientX, e.clientY); }}
                  onPointerUp={(e) => { if (e.pointerType === "touch") return; if (arrasteRef.current?.pointerId === e.pointerId) { try { e.currentTarget.releasePointerCapture(e.pointerId); } catch {} terminarArrasteLousa(e.clientX, e.clientY); } }}
                  onPointerCancel={() => { arrasteRef.current = null; setAlvoLousa(null); setForaLousa(null); }}
                  onTouchStart={(e) => { const t = e.touches[0]; if (!t) return; arrasteRef.current = { id: item.id, nome: item.nome, emoji: item.emoji, touchId: t.identifier, moveu: false, alvoId: null, inicioX: t.clientX, inicioY: t.clientY }; }}
                  onTouchMove={(e) => { const t = Array.from(e.touches).find((x) => x.identifier === arrasteRef.current?.touchId); if (t) moverArrasteLousa(t.clientX, t.clientY); }}
                  onTouchEnd={(e) => { const t = Array.from(e.changedTouches).find((x) => x.identifier === arrasteRef.current?.touchId); if (t) terminarArrasteLousa(t.clientX, t.clientY); }}>
                  <span className="emoji" aria-hidden="true">{item.emoji}</span><span className="nome">{item.nome}</span>
                </div>
              ))}
              <button type="button" className="lixeira-lousa" title="Limpar lousa" aria-label="Limpar lousa" onClick={limparLousa}>🗑️</button>
            </div>
            </div>
            <div className="lousa-rodape">
              <p className="mini">
                {itensLousa.length} item(ns) na lousa • Arraste da coleção, solte um sobre o outro pra fundir. Toque em um item para selecionar • Ctrl+C copiar • Ctrl+V colar • Ctrl+D duplicar • Delete apagar • Ctrl + rodinha = zoom.
              </p>
            </div>
          </div>
        </section>
        <aside className="colecao-direita" aria-label="Coleção de elementos">
          <div className="colecao">
            <div className="colecao-topo"><h2>Seus Elementos - {progressoBase} elementos</h2></div>
            <label className="busca-elemento"><span className="sr">Buscar elemento por emoji, palavra ou sílaba</span><input type="search" value={busca} onChange={(e) => { setBusca(e.target.value); setConfirmarExcluir(null); }} placeholder="Buscar por emoji, palavra ou sílaba... Ex.: 🌸, ta, sakura" aria-label="Buscar elemento por emoji, palavra ou sílaba" /></label>
            <p className="mini busca-contador" role="status">Mostrando {elementosFiltrados.length} de {progressoBase}{busca ? ` para “${busca}”` : ""}</p>
            <p className="mini">Emoji 🌸 • palavra tartaruga • sílaba ta — vale 1 letra também.</p>
            <p className="mini dica-arrastar">Arraste pra lousa — ou toque num elemento para colocar ele na lousa.</p>
            <div className="colecao-lista"><div className="grade">
              {elementosFiltrados.map((e) => (
                <span key={e.nome} className="elemento-wrap">
                  <button draggable className="elemento" title={`${e.dica} — Arraste pra lousa`}
                    onDragStart={(ev) => { ev.dataTransfer.setData("san-craft/elemento", e.nome); ev.dataTransfer.setData("text/plain", e.nome); ev.dataTransfer.effectAllowed = "copy"; }}
                    onClick={() => { adicionarNaLousa(e); setMensagem(`${e.emoji} ${e.nome} na lousa: ${e.dica}`); }}><span aria-hidden="true">{e.emoji}</span><small>{e.nome}</small></button>
                  <button type="button" className={confirmarExcluir === e.nome ? "excluir-elemento confirmar" : "excluir-elemento"} title={confirmarExcluir === e.nome ? `Aperte de novo para confirmar que quer deletar ${e.nome}` : `Deletar ${e.nome} da coleção`} aria-label={confirmarExcluir === e.nome ? `Confirmar deletar ${e.nome}` : `Deletar ${e.nome}`}
                    onClick={() => {
                      if (confirmarExcluir === e.nome) { excluirElemento(e.nome); return; }
                      setConfirmarExcluir(e.nome);
                      setMensagem(`Aperte ✕ de novo para confirmar que quer deletar ${e.emoji} ${e.nome}.`);
                    }}>{confirmarExcluir === e.nome ? "?" : "✕"}</button>
                </span>
              ))}
              {!elementosFiltrados.length && <p className="mini">Nenhum elemento com “{busca}”. Apague a busca para ver todos.</p>}
            </div></div>
            <div className="botoes"><button type="button" onClick={restaurarBase}>↩ Restaurar base</button></div>
            <p className="mini">✕ apaga da coleção e da lousa. Restaurar base traz de volta Água, Fogo, Vento, Terra, San e Meg se faltar algum.</p>
          </div>
        </aside>
        </div>
        <div className="linha-baixo">
        <aside className="sidebar">
          <div className="login">
            <h2>Entrar</h2>
            {usuario ? (
              <>
                <p className="jogador">Jogando como <strong>{usuario}</strong></p>
                <span className="tag">🎮 Jogando</span>
                <button className="sair" onClick={sair}>Sair</button>
              </>
            ) : (
              <>
                <div className="abas" role="tablist" aria-label="Tipo de login">
                  <button type="button" role="tab" aria-selected={abaLogin === "entrar"} className={abaLogin === "entrar" ? "aba ativa" : "aba"} onClick={() => setAbaLogin("entrar")}>Entrar</button>
                  <button type="button" role="tab" aria-selected={abaLogin === "registrar"} className={abaLogin === "registrar" ? "aba ativa" : "aba"} onClick={() => setAbaLogin("registrar")}>Registrar</button>
                </div>
                <label>Nome<input ref={nomeRef} value={nomeDigitado} onChange={(e) => setNomeDigitado(e.target.value)} placeholder="Ex.: Ana" autoComplete="username" onKeyDown={(e) => e.key === "Enter" && (abaLogin === "entrar" ? entrar() : registrar())} /></label>
                <label>Senha
                  <span className="senha-campo">
                    <input type={mostrarSenha ? "text" : "password"} autoComplete="current-password" value={senhaDigitada} onChange={(e) => setSenhaDigitada(e.target.value)} placeholder="Sua senha" onKeyDown={(e) => e.key === "Enter" && (abaLogin === "entrar" ? entrar() : registrar())} />
                    <button type="button" className="olho" aria-label={mostrarSenha ? "Ocultar senha" : "Mostrar senha"} aria-pressed={mostrarSenha} onClick={() => setMostrarSenha((atual) => !atual)}>{mostrarSenha ? "🙈" : "👁️"}</button>
                  </span>
                </label>
                <div className="botoes">
                  <button type="button" className="primario" onClick={abaLogin === "entrar" ? entrar : registrar} data-tentativas={tentativasEntrar}>{abaLogin === "entrar" ? (tentativasEntrar ? `Entrar (tentativa ${tentativasEntrar})` : "Entrar") : "Criar conta"}</button>
                </div>
                <button type="button" className="visitante-link" onClick={entrarComoVisitante}>Jogar como Visitante</button>
              </>
            )}
          </div>

        </aside>

        <section className="principal">
          <div className="status">
            <div><span>Coleção</span><strong>{progressoBase} elementos</strong><span className="infinito">∞ infinitos para descobrir</span></div>
            <label className="interruptor"><input type="checkbox" checked={iaLigada} onChange={(e) => setIaLigada(e.target.checked)} /><span>IA criadora {iaLigada ? "ligada" : "desligada"}</span></label>
            <label className="interruptor"><input type="checkbox" checked={modoAlucinatorio} onChange={(e) => setModoAlucinatorio(e.target.checked)} /><span>Modo Alucinatório 🌌 {modoAlucinatorio ? "ligado (0.9)" : "desligado (dicionário)"}</span></label>
          </div>

          <div className="duas-colunas">
            <div className="caixa diario-caixa">
              <div className="diario-cabecalho">
                <h3>📜 Diário de descobertas ({log.length})</h3>
                <button type="button" aria-expanded={!diarioMinimizado} aria-controls="diario-lista" onClick={() => setDiarioMinimizado((atual) => !atual)}>{diarioMinimizado ? "+ Expandir" : "— Minimizar"}</button>
              </div>
              {diarioMinimizado ? (
                <button type="button" className="diario-minimizado" aria-expanded="false" onClick={() => setDiarioMinimizado(false)}>{log.length} descobertas - clique para expandir</button>
              ) : (
                <ul id="diario-lista" className="diario-lista">{log.map((l, i) => <li key={i}>{l}</li>)}</ul>
              )}
            </div>
            <div className="caixa"><h3>💾 Seu save é local</h3><p>Este jogo não usa banco nem conta. Baixe o save para guardar, carregue quando quiser.</p><div className="botoes"><button className="primario" onClick={baixarSave}>Baixar Save (JSON)</button><button aria-pressed={mostrarEscolhaSaveCaixa} onClick={abrirCarregarSaveCaixa} data-aberturas={aberturasSaveCaixa}>{mostrarEscolhaSaveCaixa ? "Escolha o arquivo abaixo ↓" : "Carregar Save"}</button><button className="perigo" onClick={apagarSave}>{confirmarApagar ? "Confirmar: Apagar Save" : "Apagar Save"}</button></div>{avisoSaveCaixa && <p className="mini" role="status">{avisoSaveCaixa}</p>}{mostrarEscolhaSaveCaixa && <label>Escolha o arquivo do save<input ref={arquivoRef} type="file" accept=".json,application/json" onChange={(e) => { carregarArquivoSave(e.target.files?.[0], "save"); setMostrarEscolhaSaveCaixa(false); }} /></label>}<p className="mini">Se fechar a aba sem baixar, o progresso desta sessão é perdido.</p>
              <div className="slots-save">
                <h3>💾 3 Slots de Save</h3>
                <p className="mini">Os slots ficam só nesta sessão — feche a aba e eles somem. Use Baixar Save (JSON) para guardar para sempre.</p>
                {slotsSave.map((slot, indice) => (
                  <div className="slot-save" key={`slot-${indice}`}>
                    <div className="slot-save-topo"><span className="slot-numero">Slot {indice + 1}</span><label className="slot-nome"><span className="sr">Nome do Slot {indice + 1}</span><input value={slot.nome} onChange={(e) => renomearSlot(indice, e.target.value)} placeholder="Nome do save ex: Meu mundo, Teste, ..." aria-label={`Nome do Slot ${indice + 1}`} /></label></div>
                    <p className="mini slot-info" role="status">{slot.save ? `${slot.save.descobertos.length} elementos • salvo em ${formatarDataSlot(slot.save.salvoEm)}` : "Vazio"}</p>
                    <div className="botoes slot-botoes"><button type="button" className="primario" onClick={() => salvarSlot(indice)}>Salvar aqui</button><button type="button" onClick={() => carregarSlot(indice)} disabled={!slot.save}>Carregar</button><button type="button" className="perigo" onClick={() => apagarSlot(indice)} disabled={!slot.save}>Apagar</button></div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="caixa pacote-jogador">
            <h3>📦 Pacote do San — para jogadores</h3>
            <p>Cole o código que o San te mandou para liberar elementos secretos. Você também pode carregar por arquivo.</p>
            <textarea value={codigoParaColar} onChange={(e) => setCodigoParaColar(e.target.value)} placeholder='Cole aqui o código do Pacote do San...' rows={4} />
            <div className="botoes"><button className="primario" onClick={carregarPacoteTexto}>Carregar Pacote colado</button><button onClick={() => arquivoPacoteRef.current?.click()}>Carregar Pacote por arquivo</button></div>
            <input ref={arquivoPacoteRef} className="escondido" type="file" accept=".json,application/json" onChange={(e) => carregarArquivoSave(e.target.files?.[0], "pacote")} />
          </div>

          {ehCriador ? (
            <section className="lab">
              <div className="lab-topo"><h2>🧪 Laboratório do Criador</h2><span>Só para o Criador</span></div>
              <p className="mini">{DATABASE_ENABLED ? "Modo Banco: os elementos novos também vão para o banco quando ele estiver conectado." : "Modo Local: o elemento novo já aparece em Seus Elementos e conta no progresso desta sessão."}</p>
              <ol className="passos"><li>Preencha nome, emoji, Elemento A, Elemento B e dica</li><li>Aperte Adicionar Elemento</li><li>Confira o elemento novo em Seus Elementos e no contador</li><li>Use Export Pacote do San para compartilhar o elemento</li></ol>
              <div className="form-lab">
                <label>Nome do elemento<input value={nomeNovo} onChange={(e) => setNomeNovo(e.target.value)} placeholder="Ex.: Portal" /></label>
                <div className="campo-emoji">
                  <label>Emoji<input value={emojiNovo} onChange={(e) => setEmojiNovo(e.target.value)} placeholder="✨" aria-label="Emoji do novo elemento" /></label>
                  <button type="button" className="escolher-emoji" aria-expanded={mostrarPicker} aria-controls="painel-emoji" onClick={() => setMostrarPicker((atual) => !atual)}>😀 Escolher Emoji</button>
                  {mostrarPicker && (
                    <div className="painel-emoji" id="painel-emoji">
                      <div className="conversor">
                        <strong>Conversor palavra → emoji</strong>
                        <label className="sr" htmlFor="palavra-emoji">Digite uma palavra para converter em emoji</label>
                        <div className="conversor-linha">
                          <input id="palavra-emoji" value={palavraEmoji} onChange={(e) => setPalavraEmoji(e.target.value)} onKeyDown={(e) => e.key === "Enter" && converterPalavra()} placeholder="Digite uma palavra ex: fogo, portal, dragão, água" />
                          <button type="button" className="primario" onClick={converterPalavra}>Converter</button>
                        </div>
                        {avisoConversor && <p className="mini" role="status">{avisoConversor}</p>}
                        {sugestoesEmoji.length > 0 && (
                          <div className="sugestoes" aria-label="Sugestões de emoji">
                            {sugestoesEmoji.map((emoji, indice) => (
                              <button key={`${emoji}-${indice}`} type="button" className="chip-emoji" title={`Usar ${emoji} no campo Emoji`} onClick={() => escolherEmoji(emoji)}>{emoji}</button>
                            ))}
                          </div>
                        )}
                      </div>
                      <p className="mini">Teclado igual ao do celular: escolha um tópico em cima ou embaixo, passe as páginas e toque em um emoji para preencher o campo Emoji.</p>
                      <nav className="teclado-barra teclado-topo" aria-label="Categorias de emoji — barra superior">
                        {CATEGORIAS_EMOJI.map((categoria, indice) => (
                          <button key={categoria.titulo} type="button" className={indice === categoriaEmoji ? "aba-emoji ativa" : "aba-emoji"} aria-pressed={indice === categoriaEmoji} aria-label={`Mostrar ${categoria.titulo}`} title={categoria.titulo} onClick={() => trocarCategoriaEmoji(indice)}><span aria-hidden="true">{categoria.icone}</span><small>{categoria.titulo}</small></button>
                        ))}
                      </nav>
                      <div className="teclado-cabecalho"><strong>{categoriaAtualEmoji.icone} {categoriaAtualEmoji.titulo}</strong><span>{categoriaAtualEmoji.emojis.length} emojis</span></div>
                      <div className="teclado-grade" aria-label={`Emojis de ${categoriaAtualEmoji.titulo}, página ${paginaSeguraEmoji + 1} de ${totalPaginasEmoji}`}>
                        {emojisPaginaAtual.map((emoji, indice) => (
                          <button key={`${categoriaAtualEmoji.titulo}-${paginaSeguraEmoji}-${emoji}-${indice}`} type="button" className="tecla-emoji" title={`${categoriaAtualEmoji.titulo}: ${emoji}`} aria-label={`Usar emoji ${emoji}`} onClick={() => escolherEmoji(emoji)}>{emoji}</button>
                        ))}
                      </div>
                      <div className="paginacao">
                        <button type="button" onClick={() => setPaginaEmoji((atual) => Math.max(0, atual - 1))} disabled={paginaSeguraEmoji === 0}>◀ Anterior</button>
                        <strong aria-live="polite">Página {paginaSeguraEmoji + 1} de {totalPaginasEmoji}</strong>
                        <button type="button" onClick={() => setPaginaEmoji((atual) => Math.min(totalPaginasEmoji - 1, atual + 1))} disabled={paginaSeguraEmoji >= totalPaginasEmoji - 1}>Próxima ▶</button>
                      </div>
                      <nav className="teclado-barra teclado-rodape" aria-label="Categorias de emoji — barra inferior">
                        {CATEGORIAS_EMOJI.map((categoria, indice) => (
                          <button key={categoria.titulo} type="button" className={indice === categoriaEmoji ? "aba-emoji ativa" : "aba-emoji"} aria-pressed={indice === categoriaEmoji} aria-label={`Mostrar ${categoria.titulo}`} title={categoria.titulo} onClick={() => trocarCategoriaEmoji(indice)}><span aria-hidden="true">{categoria.icone}</span><small>{categoria.titulo}</small></button>
                        ))}
                      </nav>
                      <button type="button" className="fechar-picker" onClick={() => setMostrarPicker(false)}>Fechar teclado de emojis</button>
                    </div>
                  )}
                </div>
                <label>Elemento A<select value={receitaA} onChange={(e) => setReceitaA(e.target.value)}>{todos.map((e) => <option key={e.nome} value={e.nome}>{e.emoji} {e.nome}</option>)}</select></label>
                <label>Elemento B<select value={receitaB} onChange={(e) => setReceitaB(e.target.value)}>{todos.map((e) => <option key={e.nome} value={e.nome}>{e.emoji} {e.nome}</option>)}</select></label>
                <label className="largo">Dica para quem joga<input value={dicaNova} onChange={(e) => setDicaNova(e.target.value)} placeholder="Ex.: Nasce quando dois mundos se encontram." /></label>
              </div>
              <button className="primario" onClick={criarElementoSan}>Adicionar Elemento</button>
              <h3>Elementos secretos criados ({customizados.length})</h3>
              {customizados.length === 0 ? <p className="mini">Nenhum ainda. Seu primeiro segredo aparece aqui.</p> : <ul className="lista-secreta">{customizados.map((e) => <li key={e.nome}><span>{e.emoji} <strong>{e.nome}</strong> — {e.dica}</span><button onClick={() => removerCustomizado(e.nome)}>Remover</button></li>)}</ul>}
              <div className="botoes"><button className="primario" onClick={exportarPacote}>Export Pacote do San</button><button onClick={copiarPacote} disabled={!codigoPacote}>Copiar código</button></div>
              <label className="sr" htmlFor="codigo-pacote">Código do pacote</label>
              <textarea id="codigo-pacote" value={codigoPacote} readOnly rows={6} placeholder="O código do pacote aparece aqui depois de exportar." />
            </section>
          ) : (
            <div className="caixa jogador-info"><h3>🎮 Você está no Modo Jogador</h3><p>Combine, descubra sem limite e peça o Pacote do San para revelar segredos novos. O Laboratório do Criador só abre para o Criador.</p></div>
          )}
        </section>
        </div>
      </main>
      <footer>
        <p>San Craft • Jogo local • 6 elementos iniciais • ∞ infinitos para descobrir</p>
        <p className="aviso-ia">A IA gera elementos pra você se divertir ✨ Nem todo elemento gerado existe desse jeitinho na vida real, tá? Alguns são invenções da IA pra continuar a brincadeira. Se fizer sentido, aproveita. Se não fizer, combina de novo! ksks</p>
      </footer>
    </div>
  );
}
